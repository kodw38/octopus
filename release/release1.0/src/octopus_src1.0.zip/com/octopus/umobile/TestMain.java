package com.octopus.umobile;

import com.octopus.utils.alone.ObjectUtils;
import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.exception.ISPException;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.XMLUtil;
import com.octopus.utils.xml.auto.XMLParameter;
import org.apache.poi.util.StringUtil;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.util.Date;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TestMain {

	public static void main(String[] args){
		try{
			//XMLObject.loadXML("classpath:binlog/BinlogRelateTables.fun", null);

			XMLObject.loadApplication("classpath:tb_web.app", null,true,true);

            /*String s = StringUtils.encodeURL("http://xxx.xxx.xxx.xxx:5601");
            System.out.println(s);
            System.out.println(StringUtils.decodeURL(s));
            Pattern p= Pattern.compile("^/download\\?file\\S*(.png|.jpg)");
            Matcher m = p.matcher("/download?file=c:/logs/fff.jpsg");
            System.out.println(m.matches());*/
            /*System.out.println(new String("COSWAY (SG) K36A TEOH KAH THAI".getBytes(),"GBK"));
            System.out.println(new String("COSWAY (SG) K36A TEOH KAH THAI".replaceAll("\\u00A0"," ").getBytes(),"GBK"));*/
            //XMLMakeup xml = XMLUtil.getDataFromString("<his name=\"zipAndClearFile\" isenable=\"#{(${env}.os.name)=Linux}\" date=\"2018-05-22 12:08:57\" opType=\"sec\" author=\"WangFeng\" redo=\"\" xmlid=\"Logic\" package=\"system.log.update\" key=\"zipAndClearFile\" createby=\"WangFeng\" worktime=\"{crons:['0 0/5 * ? * *']}\" path=\"file:../data/sv/\"><do input=\"{type:'exec',data:'find (${env}.logDir) -type f -name \\'*.out\\' '}\" key=\"fs\" action=\"command\"><do input=\"{op:'split',data:'${fs}',splitChar:''}\" key=\"ffs\" action=\"utils\"><do input=\"{value:'(${yyyyMMdd-3})'}\" key=\"compareBegin\" action=\"var\"/><for collection=\"${ffs}\"><if cond=\"#{substr((${ffs}.item),#{indexof((${ffs}.item),/,-1)+1})<tb_log.(${compareBegin}).out}\"><do input=\"{type:'exec',data:'mv (${ffs}.item) (${env}.logDir)his '}\" key=\"fs\" action=\"command\"/></if></for></do></do><do input=\"{value:'2000'}\" key=\"remainSize\" action=\"var\" remark=\"unit M\"/><do input=\"{value:'(${env}.logDir)his'}\" key=\"path\" action=\"var\"/><do input=\"{type:'exec',data:'find (${path}) -type f |grep -v \\'gz$\\'|while read line;do tar -czvf $line.tar.gz $line --remove-files;done'}\" key=\"execmd\" action=\"command\"><do input=\"{type:'exec',data:'du -sm (${path})|awk \\'{print $1}\\''}\" key=\"dirUsedSize\" action=\"command\"/><do input=\"{type:'exec',data:'ls (${path}) |wc -l'}\" key=\"hisFileCount\" action=\"command\"/><while cond=\"#{((${dirUsedSize})>(${remainSize}))&((${hisFileCount})>2)}\"><do input=\"{type:'exec',data:'find (${path}) -name \\'*.gz\\' |xargs ls -rlt|awk \\'{print $9}\\'|head -n 1'}\" key=\"minDateFile\" action=\"command\"/><do input=\"{type:'exec',data:'rm -f (${minDateFile})'}\" key=\"removeFile\" action=\"command\"/><do input=\"{type:'exec',data:'ls (${path})|wc -l'}\" key=\"hisFileCount\" action=\"command\"/><do input=\"{type:'exec',data:'du -sm (${path})|awk \\'{print $1}\\''}\" key=\"dirUsedSize\" action=\"command\"/></while></do><do input=\"{value:'(${env}.logDir)backup'}\" key=\"path\" action=\"var\"/><do input=\"{type:'exec',data:'find (${path}) -type f |grep -v \\'gz$\\'|while read line;do tar -czvf $line.tar.gz $line --remove-files;done'}\" key=\"execmd\" action=\"command\"><do input=\"{type:'exec',data:'du -sm (${path})|awk \\'{print $1}\\''}\" key=\"dirUsedSize\" action=\"command\"/><do input=\"{type:'exec',data:'ls (${path}) |wc -l'}\" key=\"hisFileCount\" action=\"command\"/><while cond=\"#{((${dirUsedSize})>(${remainSize}))&((${hisFileCount})>2)}\"><do input=\"{type:'exec',data:'find (${path}) -name \\'*.gz\\' |xargs ls -rlt|awk \\'{print $9}\\'|head -n 1'}\" key=\"minDateFile\" action=\"command\"/><do input=\"{type:'exec',data:'rm -f (${minDateFile})'}\" key=\"removeFile\" action=\"command\"/><do input=\"{type:'exec',data:'ls (${path})|wc -l'}\" key=\"hisFileCount\" action=\"command\"/><do input=\"{type:'exec',data:'du -sm (${path})|awk \\'{print $1}\\''}\" key=\"dirUsedSize\" action=\"command\"/></while></do></his>");
            //XMLObject o = XMLObject.loadApplication(xml,null,true,true);
            //System.out.println(o);
            //XMLParameter x = new XMLParameter();
            //x.put("${ffs}.item","../logs/tb_log.20181117.out");
            //Object o = x.getExpressValueFromMap("substr((${ffs}.item),#{indexof((${ffs}.item),/,-1)+1})",null);
            /*String[] ss = StringUtils.split("../logs/tb_log.20181118.out\n" +
                    "../logs/tb_log.20181115.out\n" +
                    "../logs/tb_log.20181117.out\n" +
                    "../logs/tb_log.20181121.out\n" +
                    "../logs/tb_log.20181116.out\n" +
                    "../logs/tb_log.20181120.out\n" +
                    "../logs/tb_log.20181119.out","\n");
            System.out.println(ss.length);*/
            //System.out.println(new Date(1543979367545l));
            /*ISPException e = new ISPException("20","howare");
            HashMap m = new HashMap();
            m.put("CODE","code");
            m.put("RSP_MSG","msg");

            System.out.println(ObjectUtils.getObjectMapping2Map(e,m));

            System.out.println(Exception.class.isAssignableFrom(ISPException.class));*/
            /*HashMap m = new HashMap();
            m.put("mm","11");
            String s = ObjectUtils.convertMap2String(m);
System.out.println(s);*/
        }catch(Exception e){
			e.printStackTrace();
		}
	}
}
