package com.octopus.umobile;

import java.util.HashMap;
import java.util.Map;

import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.XMLUtil;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;

public class LongDescParseAction extends XMLDoObject{

    public LongDescParseAction(XMLMakeup xml,XMLObject parent,Object[] containers) throws Exception {
        super(xml, parent,containers);
        // TODO Auto-generated constructor stub
    }

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    @Override
    public void doInitial() throws Exception {

    }

    @Override
    public boolean checkInput(String arg0, XMLParameter arg1, Map arg2,
                              Map arg3, Map arg4) throws Exception {
        // TODO Auto-generated method stub
        return true;
    }

    @Override
    public ResultCheck checkReturn(String arg0, XMLParameter arg1, Map arg2,
                                   Map arg3, Map arg4, Object arg5) throws Exception {
        // TODO Auto-generated method stub
        return new ResultCheck(true,arg5);
    }

    @Override
    public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception {
        return false;
    }

    @Override
    public Object doSomeThing(String arg0, XMLParameter arg1, Map arg2,
                              Map arg3, Map arg4) throws Exception {
        // TODO Auto-generated method stub
        if(null != arg2){
            Object xml=arg2.get("data");
            if(null != xml){
                XMLMakeup root = XMLUtil.getDataFromString(xml.toString());
                Map<String,String> ret=new HashMap<String,String>();
                ret.put("Attachment", "");
                ret.put("sec1", "");
                ret.put("sec2", "");
                ret.put("sec3", "");
                ret.put("sec4", "");

                XMLMakeup[] ps = root.getByProperty("Name", "SETPartnerSalesRel");

                XMLMakeup[] psAttch = root.getByProperty("Name", "SETPartnerAttachment");

                String acct="";
                if(psAttch!=null&&psAttch.length>0){
                    XMLMakeup[] psAtt=psAttch[0].getByProperty("Sts", "D");
                    XMLMakeup[] psAtt2=psAttch[0].getByProperty("Sts", "N");

                    if((psAtt!=null&&psAtt.length>0)||(psAtt2!=null&&psAtt2.length>0)){
                        acct=";Attachment:X";
                        ret.put("Attachment", acct);
                    }
                }

                if(ps!=null){

                    if(ps.length>1){
                        XMLMakeup sec=ps[1];//secondary pic
                        XMLMakeup[] psD=sec.getByProperty("Sts", "D");
                        if(psD!=null){//删除的不为空
                            if(psD.length>0&&psD.length<2){//删除一条
                                XMLMakeup[] pscode=	psD[0].getByProperty("Name", "SALES_POSITION_CODE");
                                String oldid="";
                                if(pscode!=null&&pscode.length>0){
                                    oldid= pscode[0].getProperties().getProperty("OldID");
                                    if(oldid==null){
                                        oldid="";
                                    }
                                }


                                XMLMakeup[]  psUMId=psD[0].getByProperty("Name", "SALES_UM_ID");
                                String umid="";
                                if(psUMId!=null&&psUMId.length>0){
                                    umid=psUMId[0].getProperties().getProperty("OldID");
                                    if(umid==null){
                                        umid="";
                                    }
                                }


                                XMLMakeup[]  pstaff=psD[0].getByProperty("Name", "SALES_STAFF_NAME");
                                String staffna="";
                                if(pstaff!=null&&pstaff.length>0){
                                    staffna=pstaff[0].getProperties().getProperty("OldID");
                                    if(staffna==null){
                                        staffna="";
                                    }
                                }

                                String str1=";Secondary Staff PIC:"+oldid+";Secondary Staff ID:"+umid+";Secondary Sales PIC POSITION:"+staffna;
                                ret.put("sec1", str1);

                            }else if(psD.length>1){//删除大于一条
                                XMLMakeup[] pscode=	psD[0].getByProperty("Name", "SALES_POSITION_CODE");
                                String oldid="";
                                if(pscode!=null&&pscode.length>0){
                                    oldid= pscode[0].getProperties().getProperty("OldID");
                                    if(oldid==null){
                                        oldid="";
                                    }
                                }

                                XMLMakeup[]  psUMId=psD[0].getByProperty("Name", "SALES_UM_ID");
                                String umid="";
                                if(psUMId!=null&&psUMId.length>0){
                                    umid=psUMId[0].getProperties().getProperty("OldID");
                                    if(umid==null){
                                        umid="";
                                    }
                                }

                                XMLMakeup[]  pstaff=psD[0].getByProperty("Name", "SALES_STAFF_NAME");
                                String staffna="";
                                if(pstaff!=null&&pstaff.length>0){
                                    staffna=pstaff[0].getProperties().getProperty("OldID");
                                    if(staffna==null){
                                        staffna="";
                                    }
                                }

                                String str1=";Secondary Staff PIC:"+oldid+";Secondary Staff ID:"+umid+";Secondary Sales PIC POSITION:"+staffna;
                                ret.put("sec1", str1);

                                XMLMakeup[] pscode1=psD[1].getByProperty("Name", "SALES_POSITION_CODE");
                                String oldid1="";
                                if(pscode1!=null&&pscode1.length>0){
                                    oldid1= pscode1[0].getProperties().getProperty("OldID");
                                    if(oldid1==null){
                                        oldid1="";
                                    }
                                }

                                XMLMakeup[]  psUMId1=psD[1].getByProperty("Name", "SALES_UM_ID");
                                String umid1="";
                                if(psUMId1!=null&&psUMId1.length>0){
                                    umid1=psUMId1[0].getProperties().getProperty("OldID");
                                    if(umid1==null){
                                        umid1="";
                                    }
                                }

                                XMLMakeup[]  pstaff1=psD[1].getByProperty("Name", "SALES_STAFF_NAME");
                                String staffna1="";
                                if(pstaff1!=null&&pstaff1.length>0){
                                    staffna1=pstaff1[0].getProperties().getProperty("OldID");
                                    if(staffna1==null){
                                        staffna1="";
                                    }
                                }

                                String str2=";Secondary Staff PIC2:"+oldid1+";Secondary Staff ID2:"+umid1+";Secondary Sales PIC POSITION2:"+staffna1;
                                ret.put("sec2", str2);
                            }

                        }


                        XMLMakeup[] psN=sec.getByProperty("Sts", "N");
                        int a=0;
                        if(psN!=null&&psN.length>0){
                            for(int j=0;j<psN.length;j++){
                                XMLMakeup[] row=psN[j].find("Row");
                                if(row!=null&&row.length>0){
                                    a++;
                                    XMLMakeup[] pscode=	row[0].getByProperty("Name", "SALES_POSITION_CODE");
                                    String oldid="";
                                    if(pscode!=null&&pscode.length>0){
                                        oldid= pscode[0].getProperties().getProperty("ID");
                                        if(oldid==null){
                                            oldid="";
                                        }
                                    }

                                    XMLMakeup[]  psUMId=row[0].getByProperty("Name", "SALES_UM_ID");
                                    String umid="";
                                    if(psUMId!=null&&psUMId.length>0){
                                        umid=psUMId[0].getProperties().getProperty("ID");
                                        if(umid==null){
                                            umid="";
                                        }
                                    }

                                    XMLMakeup[]  pstaff=row[0].getByProperty("Name", "SALES_STAFF_NAME");
                                    String staffna="";
                                    if(pstaff!=null&&pstaff.length>0){
                                        staffna=pstaff[0].getProperties().getProperty("ID");
                                        if(staffna==null){
                                            staffna="";
                                        }
                                    }

                                    if(a==1){
                                        String str3=";Secondary Staff PIC:"+oldid+";Secondary Staff ID:"+umid+";Secondary Sales PIC POSITION:"+staffna;
                                        ret.put("sec3", str3);
                                    }else if(a==2){
                                        String str4=";Secondary Staff PIC2:"+oldid+";Secondary Staff ID2:"+umid+";Secondary Sales PIC POSITION2:"+staffna;
                                        ret.put("sec4", str4);
                                    }
                                }

                            }
                        }

                    }

                }


                return ret;
            }
        }
        return null;
    }

    @Override
    public boolean rollback(String arg0, XMLParameter arg1, Map arg2, Map arg3,
                            Map arg4,Object ret,Exception e) throws Exception {
        // TODO Auto-generated method stub
        return false;
    }

}
