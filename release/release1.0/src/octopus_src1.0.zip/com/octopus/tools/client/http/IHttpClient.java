package com.octopus.tools.client.http;

public abstract interface IHttpClient
{
  public abstract void httpInvoke(HttpDS paramHttpDS)
    throws Exception;
}