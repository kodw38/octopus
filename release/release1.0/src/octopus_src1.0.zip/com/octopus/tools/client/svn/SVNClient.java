package com.octopus.tools.client.svn;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.commons.lang.CharSet;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.log4j.Logger;
import org.tmatesoft.svn.core.ISVNLogEntryHandler;
import org.tmatesoft.svn.core.SVNDepth;
import org.tmatesoft.svn.core.SVNDirEntry;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNLogEntry;
import org.tmatesoft.svn.core.SVNURL;
import org.tmatesoft.svn.core.auth.ISVNAuthenticationManager;
import org.tmatesoft.svn.core.internal.io.dav.DAVRepositoryFactory;
import org.tmatesoft.svn.core.internal.io.svn.SVNRepositoryFactoryImpl;
import org.tmatesoft.svn.core.internal.wc.DefaultSVNOptions;
import org.tmatesoft.svn.core.io.SVNRepository;
import org.tmatesoft.svn.core.wc.SVNClientManager;
import org.tmatesoft.svn.core.wc.SVNRevision;
import org.tmatesoft.svn.core.wc.SVNWCUtil;

import com.google.common.collect.Lists;
import com.octopus.tb.SystemInfoUtils;
import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;

import net.sf.json.JSONObject;

/**
 * 
 * @ClassName: SVNClient 
 * @Description: svn客户端
 * @author: ligs
 * @date: 2017年12月22日 下午4:36:35
 */
public class SVNClient extends XMLDoObject {
	/**
	 * @fieldName: serialVersionUID
	 * @fieldType: long
	 * @Description: svn客户端
	 */
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(SVNClient.class);  

	private transient SVNClientManager clientManager;
	private transient SVNRepository repository;
	private static volatile Map<String,SVNClientManager> clientManagerMap = new HashMap<String, SVNClientManager>();
	private static volatile Map<String,SVNRepository> repositoryMap = new HashMap<String, SVNRepository>();
	private String svnFileName;
	private List<File> localWorkSpace;
	private transient SVNRevision svnRevision;
	private static final SVNRevision DEFAULT_SVN_VISION = SVNRevision.HEAD;
	private static final Integer LOCKTIME = 20;
    private transient volatile Map<String,List> history = new HashMap<String, List>();
    private String svnURL;
    private String userInfo;
    private transient Lock lock = new ReentrantLock();    

	
    public SVNClient(XMLMakeup xml,XMLObject parent,Object[] containers) throws Exception {
        super(xml, parent,containers);
    }

    @Override
    public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception {
        if(null != input){
            String op = (String)input.get("op");
            //svn访问目录地址
            String path = (String) input.get("path");
            //本地保存路径
            Object localPath =  input.get("localPath");
            //目标版本号
            String versionNumber = (String) input.get("versionNumber");
            URL url = new URL(path);
            //初始化类变量
            init(url,localPath,versionNumber);
            //判断操作类型
            try {
	            if("getFiles".equals(op)) {
	                if (StringUtils.isNotBlank(path)) {
	                    return getAllFile(url);
	                }
	            }else if("createBranch".equals(op)){
	            	String a = null;
	            	a.contains("s");
	            }else if("removeBranch".equals(op)){
	
	            }else if("add".equals(op)){
	            	//更新指定文件或者指定目录下所有文件到svn最新版本
	            	Long ret = export(this.svnRevision);
	            	if(null == ret || ret == 0)
	            		closeConn();
	            	return ret;
	            }else if("update".equals(op)){
	            	//更新指定文件或者指定目录下所有文件到svn最新版本
	            	Long[] ret = update(this.svnRevision, SVNDepth.INFINITY);
	            	if(null == ret || ret.length == 0)
	            		closeConn();
	            	return ret;
	            }else if("checkout".equals(op)){
	            	//检出svn文件夹到本地目录(可检出整个文件夹或者指定文件,同时本地文件名也可指定)
	            	SVNURL repositoryURL = repository.getLocation();
	            	Long ret = checkOut(repositoryURL, localWorkSpace.get(0),this.svnRevision);
	            	if(null == ret || ret == 0)
	            		closeConn();
	            	return ret;
	            }else if("cleanup".equals(op)){
	            	cleanUp();
	            }else if("diff".equals(op)){
	
	            }else if("getLog".equals(op)){
	            	String beginDate = (String) input.get("beginDate");
	            	String endDate = (String) input.get("endDate");
	            	String author = (String) input.get("author");
	            	//String pathsStr = (String) input.get("paths");
	            	String startV = (String)input.get("startVersion");
	            	startV = StringUtils.isEmpty(startV)?null:startV;
	            	String endV = (String)input.get("endVersion");
	            	endV = StringUtils.isEmpty(endV)?null:endV;
	            	List<String> files = new ArrayList<String>();
	            	if(null != input.get("files") && List.class.isAssignableFrom(input.get("files").getClass())) {
	            		files.addAll((List<String>) input.get("files"));
	            	}
	            	//List<String> paths = null == pathsStr?new ArrayList<String>():Arrays.asList(pathsStr.split(","));
	            	if(StringUtils.isNotEmpty(beginDate)) {
	            		return JSONObject.fromObject(getLog(startV,endV,beginDate, endDate, author, files));
	            	}
	            }else if("merge".equals(op)){
	
	            }else if("afterVersion".equals(op)){
	
	            }else if("beforeVersion".equals(op)){
	
	            }
            }catch (Exception e) {
				closeConn();
				throw e;
			}
        }
        return null;
    }
    public void doInitial() throws Exception {

    }

    @Override
    public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception {
    	 if(StringUtils.isEmpty((String)input.get("op"))
    			 || StringUtils.isEmpty((String)input.get("path"))) {
    					 return false;
    	 }
    	 if("getLog".equalsIgnoreCase((String)input.get("op"))) {
	    	 if(StringUtils.isNotEmpty((String)input.get("startVersion"))  && StringUtils.isNotEmpty((String)input.get("endVersion"))) {
	    		 try {
	    			 if(Long.valueOf((String)input.get("startVersion"))
	    					 > Long.valueOf((String)input.get("endVersion"))) {
	    				 return false;
	    			 }
	    		 }catch (Exception e) {
					logger.error("please check startVersion and endVersion",e);
					throw new Exception("please check startVersion and endVersion");
				}
	    	 }
    	 }
    	return true;
    }

    @Override
    public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception {
        return new ResultCheck(true,ret);
    }

    @Override
    public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception {
        return false;
    }

    @Override
    public boolean rollback(String xmlid, XMLParameter env, Map input, Map output, Map config,Object ret,Exception e) throws Exception {
        return false;
    }

    private void init(URL url,Object localWorkPath,String visionNumber) throws Exception{
    	/**初始化参数**/
    	
    	//初始化版本
    	this.svnRevision = (StringUtils.isEmpty(visionNumber)
    			||!SVNRevision.isValidRevisionNumber(Long.parseLong(visionNumber)))?
    					DEFAULT_SVN_VISION:SVNRevision.create(Long.parseLong(visionNumber));
    	//初始化本地目录,使用数组支持同时更新多个文件
    	if(null != localWorkPath) {
	    	List<String> localWorkPathList;
	    	if(List.class.isAssignableFrom(localWorkPath.getClass()))
	    		localWorkPathList = (List) localWorkPath;
	    	else{
	    		localWorkPathList = new ArrayList<String>();
	    		localWorkPathList.add((String)localWorkPath);
	    	}
	    	this.localWorkSpace = new ArrayList<File>();
	    	for(String path : localWorkPathList){
		    	File newFile = new File(path);
//		    	if(!SVNUtils.isFile(path)){
//		    		try{
//		    			if(!localWorkSpace.exists()){
//		    				localWorkSpace.mkdirs();
//		    			}
//		    		}catch (Exception e) {
//						throw new Exception(e);
//					}
//		    	}
//		    	else{
//		    		//本地路径是文件
//		    		this.localFile = localWorkSpace;
//		    	}
		    	this.localWorkSpace.add(newFile);
		    }
    	}
    	//获取svn目录
        this.svnURL = getSvnUrl(url);
        userInfo = url.getUserInfo();
        this.clientManager = getClient(url.getUserInfo());
        this.repository = getRepository(svnURL, url.getUserInfo());
        
    }
    private String getSvnUrl(URL url) {
    	StringBuilder u = new StringBuilder("http://").append(url.getHost());
        if(url.getPort()>0) {
            u.append(":").append(url.getPort());
        }
        DAVRepositoryFactory.setup();
        String file = url.getPath();
        if(SVNUtils.isFile(file)){
            u.append(file.substring(0, file.lastIndexOf('/')));
            //若操作对象为文件，初始化文件名
            this.svnFileName = file.substring(file.lastIndexOf('/')+1);
        }else{
            u.append(file);
        }
        return u.toString();
    }
    private SVNRepository getRepository(String url,String userInfo) {
    	String[] us = userInfo.split("\\:");
    	SVNRepository newRepository;
    	if(null == (newRepository = repositoryMap.get(url))) {
        	try {
        		newRepository = SVNRepositoryFactoryImpl.create(SVNURL.parseURIEncoded(StringUtils.decodeURL(url)));
        		ISVNAuthenticationManager authManager = SVNWCUtil.createDefaultAuthenticationManager(us[0], us[1]);
                newRepository.setAuthenticationManager(authManager);
                repositoryMap.put(url, newRepository);
        	} catch (SVNException e) {
    			e.printStackTrace();
    		} catch (Exception e) {
    			e.printStackTrace();
    		}
    	}
    	return newRepository;
    }
    private SVNClientManager getClient(String userInfo) {
    	String[] us = userInfo.split("\\:");
    	SVNClientManager newClientManager;
    	if(null == (newClientManager = clientManagerMap.get(userInfo))) {
        	DefaultSVNOptions options = SVNWCUtil.createDefaultOptions(true);  
        	ISVNAuthenticationManager authManager = SVNWCUtil.createDefaultAuthenticationManager(us[0], us[1]);
        	newClientManager = SVNClientManager.newInstance(options,  
                authManager);
        	clientManagerMap.put(userInfo, newClientManager);
        }
    	return newClientManager;
    }
//    Map getSVNPath(URL url)throws Exception{
//        String[] us = url.getUserInfo().split("\\:");
//        StringBuffer u = new StringBuffer("http://").append(url.getHost());
//        if(url.getPort()>0)
//            u.append(":").append(url.getPort());
//        DAVRepositoryFactory.setup();
//        String file = url.getPath();
//        String fileName="";
//        if(SVNUtils.isFile(url.getPath())){
//            u.append(file.substring(0, file.lastIndexOf("/")));
//            fileName = file.substring(file.lastIndexOf("/")+1);
//        }else{
//            u.append(file);
//        }
//        SVNRepository repository = SVNRepositoryFactoryImpl.create(SVNURL.parseURIEncoded(StringUtils.decodeURL(u.toString())));
//        ISVNAuthenticationManager authManager = SVNWCUtil.createDefaultAuthenticationManager(us[0], us[1]);
//        repository.setAuthenticationManager(authManager);
//        
//        DefaultSVNOptions options = SVNWCUtil.createDefaultOptions(true);  
//        SVNClientManager clientManager = SVNClientManager.newInstance(options,  
//                authManager);
//        
//        HashMap map = new HashMap();
//        map.put("svn",repository);
//        map.put("fileName",fileName);
//        map.put("clientManager", clientManager);
//        return map;
//    }
    /**
     * 
     * @Title: checkOut 
     * @Description: 检出文件
     * @param repositoryURL
     * @param localWorkSpace
     * @param revision
     * @return
     * @throws SVNException
     * @throws FileNotFoundException
     * @return: long
     */
    long checkOut(SVNURL repositoryURL, File localWorkSpace, SVNRevision revision) throws SVNException, FileNotFoundException{
    	try{
    		//只取一个指定文件
//    		if(null != svnFileName){
//    			return SVNUtils.getSVNFile(repository, svnFileName, localFile, localWorkSpace);
//    		}
    		//取svn指定文件夹下所有文件
//    		else{
    			//如果不是检出目录则checkOut
	    		if(!SVNUtils.isWorkingCopy(localWorkSpace)){
	    			//if(SVNUtils.isFile(repositoryURL.appendPath(svnFileName, true).getPath())){
	    			if(StringUtils.isNotEmpty(svnFileName)){
	    				SVNUtils.checkout(clientManager, repositoryURL, revision, localWorkSpace, SVNDepth.EMPTY);
	    				return SVNUtils.exportSVNFile(clientManager, repositoryURL, svnFileName, localWorkSpace, revision, SVNDepth.INFINITY);
	    			}
	    			return SVNUtils.checkout(clientManager, repositoryURL, revision, localWorkSpace, SVNDepth.INFINITY);  
	    		}
	    		//如果已经是检出目录则update
	    		//如果已经是检出目录就不执行操作
	    		else{
	    			return 1;
	    			//File[] localFile = {localWorkSpace};
	    			//return SVNUtils.update(clientManager, localFile, revision, SVNDepth.INFINITY)[0];  
	    		}
//    		}
    	}finally{
    		closeConn();
        }
    }
    public void closeConn() {
    	if(null != repositoryMap && !repositoryMap.isEmpty()) {
	    	synchronized(repositoryMap) {
	    		repositoryMap.remove(svnURL);
	        	repository.closeSession(); 
	    	}
    	}
    	if(null != clientManagerMap && !clientManagerMap.isEmpty()) {
    		synchronized(clientManagerMap) {
    			clientManagerMap.remove(userInfo);
    	    	clientManager.dispose();
	    	}
    	}
    }
    private void cleanUp() throws SVNException {
    	for(File local : localWorkSpace) {
    		SVNUtils.cleanUp(clientManager, local);
    	}
    }
    private Long[] update(SVNRevision revision,SVNDepth depth)throws Exception{
        //Map m = getSVNPath(url);
        //SVNRepository repository = (SVNRepository)m.get("svn");
    	List<Long> result = new LinkedList<Long>();
        if(null != clientManager){
            long[] visions = SVNUtils.update(clientManager, localWorkSpace.toArray(new File[0]), revision, depth);
            if(null != visions && visions.length > 0) {
            	for(long vision : visions) {
            		result.add(Long.valueOf(vision));
            	}
            	return result.toArray(new Long[0]);
            }
        }
        return new Long[0];
    }
    private Map<String,List> getLog(String startVersion,String endVersion,String begin,String end,final String author,final List<String> paths) throws Exception {
    	Map<String,List> logs = new HashMap<String,List>(86);
    	final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		try {
		    final Date beginD = format.parse(begin);
		    final Date endD;
		    if(StringUtils.isEmpty(end)) {
		    	Calendar nextDay = Calendar.getInstance();
		    	nextDay.add(Calendar.DAY_OF_YEAR, 1);
		    	endD = format.parse(format.format(nextDay.getTime()));
		    }
		    else {
		    	endD = format.parse(end);
		    }
		    SVNURL repositoryURL = repository.getLocation();
		    //处理日志规则
		    ISVNLogEntryHandler handler = new ISVNLogEntryHandler() {
				@Override
				public void handleLogEntry(SVNLogEntry paramSVNLogEntry) throws SVNException {
					if(paramSVNLogEntry.getDate().after(beginD)
							&& paramSVNLogEntry.getDate().before(endD)) {
						if(StringUtils.isNotEmpty(author)) {
							if(author.equals(paramSVNLogEntry.getAuthor())) {
								add(paramSVNLogEntry);
							}
						}
						else {
							add(paramSVNLogEntry);
						}
					}
				}
				public void add(SVNLogEntry svnLogEntry) {
					for(Object path : svnLogEntry.getChangedPaths().keySet()) {
						String[] h = new String[] {svnLogEntry.getAuthor(),format.format(svnLogEntry.getDate())
								,handleString(svnLogEntry.getMessage())};
						//
						if(!paths.isEmpty()
								&& !paths.contains(path)) {
							continue;
						}
						if(null != history.get(path)) {
							history.get(path).add(h);
						}
						else {
							List<String[]> v = new ArrayList<String[]>();
							v.add(h);
							history.put((String)path, v);
						}
					}
				}
		    };
		    if(lock.tryLock(LOCKTIME, TimeUnit.SECONDS)) {
		    	try {
		    		if(null != startVersion || null != endVersion) {
		    			Long startV = (startVersion==null||Long.parseLong(startVersion)<=0)?0:Long.parseLong(startVersion);
		    			Long endV = (endVersion==null||Long.parseLong(endVersion)<=0)?Long.MAX_VALUE:Long.parseLong(endVersion);
		    			SVNUtils.getLog(clientManager,repositoryURL, paths.toArray(new String[paths.size()]), startV, endV,handler);
					    logs.putAll(history);
		    		}
		    		else {
						SVNUtils.getLog(clientManager,repositoryURL, paths.toArray(new String[paths.size()]), beginD, endD,handler);
					    logs.putAll(history);
		    		}
		    	}finally {
		    		history.clear();
					lock.unlock();
				}
		    }
		} catch (ParseException e1) {
			logger.error("Get svn log failed",e1);
			throw new Exception("Get svn log failed",e1);
		} catch (SVNException e2) {
			logger.error("Get svn log failed",e2);
			throw new Exception("Get svn log failed",e2);
		}
    	return logs;
    }
    /**
     * 
     * @Title: handleString 
     * @Description: 处理字符串
     * @param str
     * @return
     * @return: String
     */
    private String handleString(String str) {
    	if(StringUtils.isEmpty(str)) {
    		return null;
    	}
    	try {
			return URLEncoder.encode(str.replaceAll("\\n", ";"), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
    	return null;
    }
    long export(SVNRevision revision) throws SVNException{
    	return SVNUtils.exportSVNFile(clientManager, repository.getLocation(), svnFileName, localWorkSpace.get(0), revision, SVNDepth.INFINITY);
    }
    /**
     * 
     * @Title: getAllFile 
     * @Description: 获取文件夹下的所有文件
     * @param url
     * @return
     * @throws Exception
     * @return: Map<String,InputStream>
     */
    Map<String, InputStream> getAllFile(URL url) throws Exception {
        Map map = new HashMap(16);
        String[] us = url.getUserInfo().split("\\:");
        StringBuffer u = new StringBuffer("http://").append(url.getHost());
        if (url.getPort() > 0) {
            u.append(":").append(url.getPort());
        }
        DAVRepositoryFactory.setup();
        if (SVNUtils.isFile(url.getPath())){
            String file = url.getPath();
            u.append(file.substring(0, file.lastIndexOf("/")));
            SVNRepository repository = SVNRepositoryFactoryImpl.create(SVNURL.parseURIEncoded(StringUtils.decodeURL(u.toString())));
            ISVNAuthenticationManager authManager = SVNWCUtil.createDefaultAuthenticationManager(us[0], us[1]);
            repository.setAuthenticationManager(authManager);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            //FileOutputStream out = new FileOutputStream(new File("d:\\txt.xlsx"));
            repository.getFile(file.substring(file.lastIndexOf("/")+1),-1,null,out);
            ByteArrayInputStream in = new ByteArrayInputStream(out.toByteArray());
            out.close();
            map.put(url.getFile(),in);
        }else{
            SVNRepository repository = SVNRepositoryFactoryImpl.create(SVNURL.parseURIEncoded(StringUtils.decodeURL(u.toString() + url.getPath())));
            ISVNAuthenticationManager authManager = SVNWCUtil.createDefaultAuthenticationManager(us[0], us[1]);
            repository.setAuthenticationManager(authManager);
            List<String> li = new ArrayList<String>();
            getFilepath(repository,"",li);
            for(String s:li){
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                repository.getFile(s,-1,null,out);
                ByteArrayInputStream in = new ByteArrayInputStream(out.toByteArray());
                out.close();
                map.put(s.substring(s.lastIndexOf("/")+1),in);
            }
        }

        return map;
    }


    void getFilepath(SVNRepository repository,String dir,List li) throws SVNException {
        Collection<SVNDirEntry> entries = repository.getDir(dir, -1, null, (Collection) null);
        for (SVNDirEntry entry : entries) {
            if(SVNUtils.isFile(entry.getRelativePath())){
                li.add((dir.equals("")?"":(dir+"/"))+entry.getRelativePath());

            }else{
                getFilepath(repository,(dir.equals("")?"":(dir+"/"))+entry.getRelativePath(),li);
            }
        }
    }
    public static long getLatestVersion(SVNRepository repository) {
    	long latestRevision = -1;
    	try {
            latestRevision = repository.getLatestRevision();
        } catch (SVNException svne) {
            System.err.println("获取最新版本号时出错: " + svne.getMessage());
            System.exit(1);
        }
    	return latestRevision;
    }
   
    public static void main(String[] args) throws Exception {
    	String[] aa = {"1","2"};
    	System.out.println(aa.getClass());
    	String svn = "http://ligs:123456@119.28.66.159/svn/umobile/code/CRM_R328_PN/integration";
		URL url = new URL(svn);
		//String local = "C:\\Users\\Peter\\Documents\\workDoc\\马来项目\\local";
		final SVNClient svnClient = new SVNClient(null, null,null);
//		List<String> localList = new ArrayList();
//		localList.add("C:\\Users\\Peter\\Documents\\workDoc\\马来项目\\local\\CR+For+All+Report+Updates.docx");
//		localList.add("C:\\Users\\Peter\\Documents\\workDoc\\马来项目\\local\\Report+Required+to+Change.xlsx");
		svnClient.init(url, "C:\\Users\\Peter\\Documents\\workDoc\\MaLai\\code\\CRM_R328_PN\\integration",null);
		svnClient.checkOut(svnClient.repository.getLocation(), svnClient.localWorkSpace.get(0), svnClient.svnRevision);
		//svnClient.export(DEFAULT_SVN_VISION);
		//svnClient.update(svnClient.svnRevision, SVNDepth.INFINITY);
//		final List<String> files = new ArrayList<String>();
//		files.add("/code/CRM_R318/treasurebag/config/funs/svn.fun");
//    	files.add("/code/CRM_R318/treasurebag/src/com/octopus/tools/client/svn/SVNUtils.java");
//		ExecutorService ex = new ThreadPoolExecutor(5, 10, 20, TimeUnit.SECONDS, new ArrayBlockingQueue<Runnable>(5));
//    	Runnable r = new Runnable() {
//			@Override
//			public void run() {
//				try {
//					System.out.println(JSONObject.fromObject(svnClient.getLog("18999","-1","2017-11-10", "","ligs", files)));
//				} catch (InterruptedException e) {
//					e.printStackTrace();
//				} catch (Exception e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}					
//			}
//		};
//		ex.submit(r);
//		ex.submit(r);
	}
}
