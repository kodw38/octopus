/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: DFSResourceAction.java 
 * @Prject: treasurebag
 * @Package: com.octopus.tools.client.fastdfs 
 * @Description: TODO
 * @author: ligs   
 * @date: 2019年1月17日 上午11:40:48 
 * @version: V1.0   
 */
package com.octopus.tools.client.fastdfs;

import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;

import com.octopus.isp.ds.RequestParameters;
import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.cachebatch.DateTimeUtil;
import com.octopus.utils.common.TBUtils;
import com.octopus.utils.common.WebUtils;
import com.octopus.utils.file.FileUtils;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;

/** 
 * @ClassName: DFSResourceAction 
 * @Description: TODO
 * @author: ligs
 * @date: 2019年1月17日 上午11:40:48  
 */
public class FastDFSResAction extends XMLDoObject {

	public FastDFSResAction(XMLMakeup xml, XMLObject parent, Object[] containers) throws Exception {
		super(xml, parent, containers);
	}

	@Override
	public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception {
		return true;
	}

	@Override
	public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret)
			throws Exception {
		return new ResultCheck(true, ret);
	}

	@Override
	public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception {
		return false;
	}

	@Override
	public void doInitial() throws Exception {
		
	}

	@Override
	public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception {
		String op = (String) input.get("op");
		Map header = (Map) input.get("header");
		String name = (String) input.get("fileName");
		String charset = (String) input.get("charset");
		String docPath = (String) input.get("path");

		if("get".equalsIgnoreCase(op)) {
			XMLDoObject dfsClient = (XMLDoObject) getObjectById("fastDFSClient");
			Map dfsInput = new HashMap();
			dfsInput.put("op", "downloadBytes");
			dfsInput.put("path", docPath);
			byte[] content = null;
			try {
				content = (byte[]) dfsClient.doSomeThing(xmlid, env, dfsInput, null, config);
				if(null == content || content.length == 0) {
					throw new Exception("Cannot get document by Path:" + docPath);
				}
			}catch (Exception e) {
				throw new Exception("Cannot get document by Path:" + docPath);
			}
			RequestParameters requestParam = (RequestParameters) env;
			HttpServletResponse response = (HttpServletResponse) requestParam.get("${response}");
			String docType = FileUtils.getExtension(docPath);
			docType = docType.isEmpty()?FileUtils.getExtension(name):docType;
			
			String tempReceiptName = new StringBuffer(FilenameUtils.getBaseName(name)).append("_")
					.append(DateTimeUtil.getCurrDateTime_yyyymmddhhmmss()).append(docType.isEmpty()?"":"."+docType).toString();
			
			String contentType = WebUtils.getContentTypeByFileName(docPath);
			if (null == contentType) {
				throw new Exception("UnSupport docType:" + docPath);
			}
			response.setHeader("Content-disposition", "inline; filename=" + tempReceiptName);
			setAttribute(response,header,charset,contentType);
			write(response,content);
			requestParam.setStop();
		}else if("download".equalsIgnoreCase(op)) {
			XMLDoObject dfsClient = (XMLDoObject) getObjectById("fastDFSClient");
			Map dfsInput = new HashMap();
			dfsInput.put("op", "downloadBytes");
			dfsInput.put("path", docPath);
			byte[] content = null;
			try {
				content = (byte[]) dfsClient.doSomeThing(xmlid, env, dfsInput, null, config);
				if(null == content || content.length == 0) {
					throw new Exception("Cannot get document by Path:" + docPath);
				}
			}catch (Exception e) {
				throw new Exception("Cannot get document by Path:" + docPath);
			}
			RequestParameters requestParam = (RequestParameters) env;
			HttpServletResponse response = (HttpServletResponse) requestParam.get("${response}");
			String docType = FileUtils.getExtension(docPath);
			docType = docType.isEmpty()?FileUtils.getExtension(name):docType;
			String tempReceiptName = new StringBuffer(FilenameUtils.getBaseName(name)).append("_")
					.append(DateTimeUtil.getCurrDateTime_yyyymmddhhmmss()).append(docType.isEmpty()?"":"."+docType).toString();
			
			response.setHeader("Content-disposition", "attachment; filename=" + tempReceiptName);
			setAttribute(response,header,charset,WebUtils.getContentTypeByFileName(docPath));
			write(response,content);
			requestParam.setStop();
		}else if("delete".equalsIgnoreCase(op)) {
			XMLDoObject dfsClient = (XMLDoObject) getObjectById("fastDFSClient");
			Map dfsInput = new HashMap();
			dfsInput.put("op", "delete");
			dfsInput.put("path", docPath);
			try {
				return dfsClient.doSomeThing(xmlid, env, dfsInput, null, config);
			}catch (Exception e) {
				throw new Exception("Delete document failed, path:" + docPath,e);
			}
		}else {
			throw new Exception("Unsupport OP type:" + op);
		}
		return null;
	}
	private void write(HttpServletResponse response,byte[] content) throws IOException {
		try {
			// 打开输出流
			OutputStream os = response.getOutputStream();
//			os.write(content);
			int len = 1024;
			int i = 0;
			for(;i + len < content.length;) {
				os.write(content, i, len);
				i = i + len;
			}
			os.write(content, i, content.length-i);
		} finally {
			//pdfFile.delete();
		}
		// 关闭
		response.flushBuffer();
	}
	private void setAttribute(HttpServletResponse response,Map header,String charset,String contentType) throws Exception {
		response.setContentType(contentType);
		response.setCharacterEncoding(StringUtils.isNotEmpty(charset) ? charset : "UTF-8");
		if (null != header) {
			Set<Entry> es = header.entrySet();
			for (Entry e : es) {
				String k = (String) e.getKey();
				String v = (String) e.getValue();
				if (null != k) {
					response.setHeader(k, v);
				}
			}
		}
	}
	@Override
	public boolean rollback(String arg0, XMLParameter arg1, Map arg2, Map arg3, Map arg4, Object arg5, Exception arg6)
			throws Exception {
		return false;
	}

}
