/**   
 * Copyright © 2017 公司名. All rights reserved.
 * 
 * @Title: ReleaseFilesCompare.java 
 * @Prject: treasurebag
 * @Package: com.octopus.tools.client.svn 
 * @Description: TODO
 * @author: ligs   
 * @date: 2017年11月28日 下午8:03:45 
 * @version: V1.0   
 */
package com.octopus.tools.client.svn;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.octopus.tb.SystemInfoUtils;
import com.octopus.tools.utils.ExcelReader;
import com.octopus.utils.file.FileUtils;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;

/** 
 * @ClassName: ReleaseFilesCompare 
 * @Description: 比对两个分支releasenote提交的文件
 * @author: ligs
 * @date: 2017年11月28日 下午8:03:45  
 */
public class ReleaseFilesCompare extends XMLDoObject{

	/**
	 * @fieldName: serialVersionUID
	 * @fieldType: long
	 * @Description: svn版本比对
	 */
	private static final long serialVersionUID = 6552375286109114610L;
	
	private XMLDoObject excelReader;
	private XMLDoObject svnClient;
	private XMLDoObject dataSource;
	private List<String> compareRules;
	private static final String SPLIT = ",";
	/** 
	 * @Title:ReleaseFilesCompare
	 * @Description:定义比较规则
	 * @param xml
	 * @param parent
	 * @throws Exception 
	 */
	public ReleaseFilesCompare(XMLMakeup xml,XMLObject parent,Object[] containers) throws Exception {
		super(xml, parent, containers);
		Properties props = xml.getChild("properties")[0].getPropertiesByChildNameAndText("property");
		String compareRuleStr = props.getProperty("compareRules");
		if(StringUtils.isEmpty(compareRuleStr))
			throw new Exception("Please config Compare Rules");
		compareRules = SystemInfoUtils.splitToList(compareRuleStr, SPLIT);
	}

    @Override
    public void doInitial() throws Exception {

    }

    /* (non Javadoc)
         * @Title: checkInput
         * @Description: TODO
         * @param arg0
         * @param arg1
         * @param arg2
         * @param arg3
         * @param arg4
         * @return
         * @throws Exception
         * @see com.octopus.utils.xml.auto.IXMLDoObject#checkInput(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map)
         */
	public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception {
		if(null == input.get("from") || null == input.get("to"))
			return false;
		return true;
	}

	/* (non Javadoc) 
	 * @Title: checkReturn
	 * @Description: TODO
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @param arg3
	 * @param arg4
	 * @param arg5
	 * @return
	 * @throws Exception 
	 * @see com.octopus.utils.xml.auto.IXMLDoObject#checkReturn(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map, java.lang.Object) 
	 */
	public ResultCheck checkReturn(String arg0, XMLParameter arg1, Map arg2, Map arg3, Map arg4, Object arg5)
			throws Exception {
		return new ResultCheck(true, arg5);
	}

    @Override
    public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception {
        return false;
    }

	public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception {
		Map<String,Object> ret = new HashMap<String, Object>();
		Boolean result = false;
		List<Object> message = new LinkedList<Object>();
		
		if(null != input){
			String from = (String) input.get("from");
			String to = (String) input.get("to");
			if(from.equalsIgnoreCase(to)) {
				result = true;
			}
			if(null == dataSource) {
				dataSource = (XMLDoObject) getObjectById("getSvnConfig");
			}
			if(null == dataSource) {
				svnClient = (XMLDoObject) getObjectById("svnClient");
			}
			if(null == dataSource) {
				excelReader = (XMLDoObject) getObjectById("readExcel");
			}
			else {
				//获取两个版本releaseNote本地地址和svn地址
				String releaseNotelocal_f = null;
				String releaseNotelocal_t = null;
				String releaseNotePath_f = null;
				String releaseNotePath_t = null;
				//获取配置文件
				//List<Map<String, String>> deployExcel = readExcel((String)((Map)env.get("${env}")).get(SVNConsts.DEPLOY_EXCEL_PATH),SVNConsts.DEPLOY_SHEET_NAME);
				List<Map<String, String>> deployExcel = readExcel();

				//List<Map<String, String>> deployExcel = readExcel("C:/Users/Peter/Downloads/AI-UMobile-ServerEnvironment-online.xlsx",DEPLOY_SHEET_NAME);
				if(null != deployExcel && !deployExcel.isEmpty()) {
					for(Map<String, String> svnConfig : deployExcel) {
						if(from.equalsIgnoreCase(svnConfig.get(SVNConsts.RELEASE_VISION))) {
							StringBuilder sb = new StringBuilder();  
							releaseNotelocal_f = svnConfig.get(SVNConsts.RELEASE_LOCATION);
							releaseNotePath_f = sb.append(svnConfig.get(SVNConsts.SVN_PATH)).append("/").append(svnConfig.get(SVNConsts.RELEASE_NOTE_PATH))
									.append("/").append(svnConfig.get(SVNConsts.RELEASE_VISION)).toString();
						}
						else if(to.equalsIgnoreCase(svnConfig.get(SVNConsts.RELEASE_VISION))) {
							StringBuilder sb = new StringBuilder();
							releaseNotelocal_t = svnConfig.get(SVNConsts.RELEASE_LOCATION);
							releaseNotePath_t = sb.append(svnConfig.get(SVNConsts.SVN_PATH)).append("/").append(svnConfig.get(SVNConsts.RELEASE_NOTE_PATH))
									.append("/").append(svnConfig.get(SVNConsts.RELEASE_VISION)).toString();
						}
					}
				}
				if(StringUtils.isEmpty(releaseNotelocal_f) || StringUtils.isEmpty(releaseNotePath_f)
						|| StringUtils.isEmpty(releaseNotelocal_t) || StringUtils.isEmpty(releaseNotePath_t)) {
					message.add("Failed,please check releaseNote Path in deployExcel");
				}else {
					//update releaseNote from
					updateFile(releaseNotePath_f,releaseNotelocal_f);
					//update releaseNote to
					updateFile(releaseNotePath_t,releaseNotelocal_t);
					//update done,start read releaseNote
					//read from all files
					Set<String> fromSet = getReleaseFiles(releaseNotelocal_f);
					//read to all files
					Set<String> toSet = getReleaseFiles(releaseNotelocal_t);
					//List<String> fromList = sort(fromSet);
					//List<String> toList = sort(toSet);
					//compare
					compareDiffFiles(fromSet,toSet);
					message.add(convertMessage(fromSet));
					message.add(convertMessage(toSet));
					result = true;
				}
			}
		}
		ret.put("result", result);
		ret.put("message", message);
		return ret;
	}
	private List convertMessage(Set<String> set) {
		List<List<String>> list = new LinkedList<List<String>>();
		for(String s : set) {
			list.add(SystemInfoUtils.splitToList(s, SPLIT));
		}
		return list;
	}
//	private List<String> sort(Collection<String> set){
//		List<String> fromList = new LinkedList<String>(set);
//		Collections.sort(fromList);
//		if(!fromList.isEmpty() && StringUtils.isEmpty(fromList.get(0)))
//			fromList.remove(0);
//		return fromList;
//	}
//	private Set<String> trimSet(Collection<String> set) {
//		Set<String> newSet = new LinkedHashSet<String>();
//		for(String e : set) {
//			newSet.add(e.trim());
//		}
//		return newSet;
//	}
	private List<String> trimList(Collection<String> List) {
		List<String> newList = new ArrayList<String>();
		for(String e : List) {
			newList.add(e.trim());
		}
		return newList;
	}
	/**
	 * 
	 * @Title: compareDiffFiles 
	 * @Description: 比较
	 * @param list1
	 * @param list2
	 * @return: void
	 */
	private void compareDiffFiles(Collection<?> list1,Collection<?> list2){
		Collection<?> max = list1.size()>=list2.size()?list1:list2;
		Collection<?> min = list1.size()>=list2.size()?list2:list1;;
		
		Iterator<?> it = min.iterator();
		while(it.hasNext()) {
			Object o = it.next();
			if(max.contains(o)) {
				it.remove();
				max.remove(o);
			}
		}
	}
	/**
	 * 
	 * @Title: getReleaseFiles 
	 * @Description: 根据releaseNote的根目录获取所有日期文件中提交的file
	 * @param releaseDirectory
	 * @return
	 * @return: Set<String>
	 * @throws Exception 
	 */
	private Set<String> getReleaseFiles(String releaseDirectory) throws Exception{
		Set<String> files = new LinkedHashSet<String>();
		List<String> directories = FileUtils.getCurDirNames(releaseDirectory);
		directories.remove(".svn");
		for(String directory : directories) {
			StringBuilder sb = new StringBuilder();
			sb.append(releaseDirectory).append("/").append(directory).append("/")
				.append(directory).append(".xlsx");
			List<Map<String, String>> records = readExcel(sb.toString(),SVNConsts.RELEASE_SHEET_NAME,compareRules);
			//遍历行记录
			if(null != records && !records.isEmpty()) {
				if(records.get(0).containsKey(SVNConsts.FILE_LIST)) {
					for(Map<String, String> record : records) {
						StringBuilder sb1 = new StringBuilder();
						//拼接所有比较字段(fileList使用站位符预占)
						for(Entry<String, String> r : record.entrySet()) {
							
							if(SVNConsts.FILE_LIST.equals(r.getKey()))
								sb1.append(SVNConsts.FILE_LIST).append(SPLIT);
							else {
								try {
									sb1.append(r.getValue().replaceAll("\\n", "\\b")).append(SPLIT);
								}catch (Exception e) {
									sb1.append(r.getValue()).append(SPLIT);
								}
							}
						}
						//遍历FILEList,每个文件添加一个记录
						String fileListStr = record.get(SVNConsts.FILE_LIST);
						if(StringUtils.isNotEmpty(fileListStr)) {
							//按换行符拆分
							List<String> fileList= SystemInfoUtils.splitToList(fileListStr.trim(), "\\n");
							List<String> trimedList = trimList(fileList);
							for(String f : trimedList) {
								files.add(sb1.substring(0, sb1.length()-1).replace(SVNConsts.FILE_LIST, f));
							}
						}
						
					}
				}
				else {
					for(Map<String, String> record : records) {
						StringBuilder sb1 = new StringBuilder();
						for(String v : record.values()) {
							try {
								sb1.append(v.replaceAll("\\n", "\\b")).append(SPLIT);
							}catch (Exception e) {
								sb1.append(v).append(SPLIT);
							}
							
						}
						files.add(sb1.substring(0, sb1.length()-1));
					}
				}
			}
		}
		return files;
	}
	private Long[] updateFile(String path,String localPath) throws Exception{
		try {
			Map<String,String> scInput = new HashMap<String, String>();
			scInput.put("op", "update");
			scInput.put("path", path);
			scInput.put("localPath", localPath);
			return (Long[]) svnClient.doSomeThing(null, null, scInput, null, null);
		}catch (Exception e) {
			throw new Exception("update file "+localPath+" failed",e);
		}
	}
	private List<Map<String, String>> readExcel() throws Exception{
		Map<String,Object> input = new HashMap<String, Object>();
		input.put("fields", new ArrayList<String>());
		return (List<Map<String, String>>) dataSource.doSomeThing(null, null, input, null, null);
	}
	private List<Map<String, String>> readExcel(String fileName) throws Exception{
		return readExcel(fileName,SVNConsts.RELEASE_SHEET_NAME);
	}
	private List<Map<String, String>> readExcel(String fileName,String sheetName) throws Exception{
		Map<String,Object> input = new HashMap<String, Object>();
		input.put("file",fileName);
		input.put("sheetName", sheetName);
		return (List<Map<String, String>>) excelReader.doSomeThing(null, null, input, null, null);
	}
	private List<Map<String, String>> readExcel(String fileName,String sheetName,List<String> fields) throws Exception{
		
		Map<String,Object> input = new HashMap<String, Object>();
		input.put("file",fileName);
		input.put("sheetName", sheetName);
		
		List<Map<String, String>> datas = (List<Map<String, String>>) excelReader.doSomeThing(null, null, input, null, null);
		if(null == fields || fields.isEmpty())
			return datas;
		List<Map<String, String>> ret = new ArrayList<Map<String,String>>();
		for(Map data : datas) {
			Map m = getFieldValue(data, fields);
			if ((m != null) && (m.size() > 0))
				ret.add(m);
		}
		return ret;
	}
	public Map getFieldValue(Map m, List<String> fs) {
		if ((fs == null) || (fs.size() == 0))
			return m;
		LinkedHashMap map = new LinkedHashMap();
		for (String s : fs) {
			map.put(s, m.get(s));
		}

return map;
	}
	/* (non Javadoc) 
	 * @Title: rollback
	 * @Description: TODO
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @param arg3
	 * @param arg4
	 * @param arg5
	 * @param arg6
	 * @return
	 * @throws Exception 
	 * @see com.octopus.utils.xml.auto.IXMLDoObject#rollback(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map, java.lang.Object, java.lang.Exception) 
	 */
	public boolean rollback(String arg0, XMLParameter arg1, Map arg2, Map arg3, Map arg4, Object arg5, Exception arg6)
			throws Exception {
		return false;
	}
	public static void main(String[] args) throws Exception {
		Map m = new HashMap();
		m.put("from", "CRM_R327");
		m.put("to", "CRM_R326_PN");
		ReleaseFilesCompare com = new ReleaseFilesCompare(null,null,null);
		com.excelReader = new ExcelReader(null, null,null);
		com.svnClient = new SVNClient(null, null,null);
		com.doSomeThing(null, null, m, null, null);
	}
}
