/**   
 * Copyright © 2017 公司名. All rights reserved.
 * 
 * @Title: HttpsUtils.java 
 * @Prject: integration1
 * @Package: com.asiainfo.um.RESTful.common.util 
 * @Description: TODO
 * @author: ligs   
 * @date: 2017年11月23日 上午10:45:06 
 * @version: V1.0   
 */
package com.octopus.tools.client.https;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.Iterator;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;

import com.octopus.utils.alone.ObjectUtils;
import org.apache.commons.httpclient.params.HttpConnectionParams;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import sun.net.www.protocol.https.Handler;

/** 
 * @ClassName: HttpsUtils 
 * @Description:
 * @author: ligs
 * @date: 2017年11月23日 上午10:45:06  
 */
public class HttpsUtils {
    static transient Log logger = LogFactory.getLog(HttpsUtils.class);

	private static final int readTimeout = 40000;
	private static final int connectTimeout = 40000;
	
	public static HttpsURLConnection createConnection(String url,String method) throws Exception {
		return initConnection(url, method);
	}
	/**
	 * 
	 * @Title: doPost 
	 * @Description: POST
	 * @param url
	 * @param paramMap
	 * @param header
	 * @return
	 * @throws Exception
	 * @return: Object(String,JSONObject,JSONArray)
	 */
	public static Object doPost(String url,Map<String,String> paramMap,Map<String,String> header) throws Exception {
		HttpsURLConnection conn;
		BufferedWriter out = null;
		try {
			conn = initConnection(url, "POST");
			if(null != header && !header.isEmpty()) {
				Iterator<String> its = header.keySet().iterator();
		        while(its.hasNext()) {
			        String k = its.next();
			        String v = header.get(k);
			        conn.setRequestProperty(k,v);
		        }
			}
			if(null != paramMap && !paramMap.isEmpty()) {
				String data;
				data = ObjectUtils.convertMap2String(paramMap);//JSON.toString
				logger.info("----------start Send https requestData=  -----------"+data);
		        out = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream(), "UTF-8"));
		        out.write(data);
		        out.flush();
			}
			try{
	            return handleResponse(conn);
	        }catch (Exception e){
	            if(!(e instanceof SocketException || e instanceof SocketTimeoutException)){
	            	logger.error(url,e);
	            }
	            throw e;
	        }
		}catch (Exception e) {
			throw e;
		}finally {
			if(null != out)
				out.close();
		}
	}
	
	/**
	 * 
	 * @Title: doGet 
	 * @Description: 自定义connnection
	 * @param url
	 * @param conn
	 * @return
	 * @throws Exception
	 * @return: Object
	 */
	public static Object doGet(HttpsURLConnection conn) throws Exception {
		return doGet(null, null, null, null,conn);
	}
	/**
	 * 
	 * @Title: doGet 
	 * @Description: TODO
	 * @param url
	 * @param paramMap
	 * @return
	 * @throws Exception
	 * @return: Object
	 */
	public static Object doGet(String url,Map<String,String> paramMap) throws Exception {
		return doGet(url, paramMap, null, null, null);
	}
	/**
	 * 
	 * @Title: doGet 
	 * @Description: TODO
	 * @param url
	 * @param paramMap 参数键值对
	 * @param header 报文头键值对
	 * @param connProperties 连接属性键值对
	 * @return
	 * @throws Exception
	 * @return: Object
	 */
	public static Object doGet(String url,Map<String,String> paramMap,Map<String,String> header,Map<String,Object> connProperties) throws Exception {
		return doGet(url, paramMap, header, connProperties, null);
	}

	/**
	 * 
	 * @Title: doGet 
	 * @Description: TODO
	 * @param url
	 * @param paramMap
	 * @param header
	 * @param connProperties
	 * @param _conn
	 * @return
	 * @throws Exception
	 * @return: Object(String,JSONObject,JSONArray)
	 */
	public static Object doGet(String url,Map<String,String> paramMap,Map<String,String> header,Map<String,Object> connProperties,HttpsURLConnection _conn) throws Exception {
		HttpsURLConnection conn;
		try {
			//构造请求参数
			String mPath = url;
			if(null != paramMap && !paramMap.isEmpty()) {
				mPath = url + "?";
	            for(String key:paramMap.keySet()){
	                mPath += key + "=" + paramMap.get(key) + "&";
	            }
	            mPath =  mPath.substring(0, mPath.length()-1);
			}
			//初始化连接
			conn = null==_conn?initConnection(mPath, "GET"):_conn;
			//初始化连接属性
			if(null != connProperties && !connProperties.isEmpty())
				conn = null==_conn?setConnProperties(conn,connProperties):_conn;
			if(null != header && !header.isEmpty()) {
				Iterator<String> its = header.keySet().iterator();
		        while(its.hasNext()) {
			        String k = (String)its.next();
			        String v = (String)header.get(k);
			        conn.setRequestProperty(k,v);
		        }
			}
			conn.connect();
			try{
	            return handleResponse(conn);
	        }catch (Exception e){
	            if(!(e instanceof SocketException || e instanceof SocketTimeoutException)){
	            	logger.error(url,e);
	            }
	            throw e;
	        }
		}catch (Exception e) {
			throw e;
		}
	}
	private static HttpsURLConnection setConnProperties(HttpsURLConnection conn,Map<String,Object> properties) {
		if(properties.containsKey(HttpConnectionParams.CONNECTION_TIMEOUT))
			conn.setConnectTimeout(Integer.parseInt(String.valueOf(properties.get(HttpConnectionParams.CONNECTION_TIMEOUT))));
		if(properties.containsKey(HttpConnectionParams.SO_TIMEOUT))
			conn.setReadTimeout(Integer.parseInt(String.valueOf(properties.get(HttpConnectionParams.SO_TIMEOUT))));
		return conn; 

	}
	private static HttpsURLConnection initConnection(String path,String method) throws Exception{
   	 URL url = new URL(null, path, new Handler());
   	 HttpsURLConnection conn = (HttpsURLConnection)url.openConnection(); 
   	 SSLSocketFactory  sslFac = UMBX509TrustManager.getSSLFactory(); 
   	 
   	 if(StringUtils.isNotEmpty(method)){
   		 if(method.equalsIgnoreCase("GET")){
   			 conn.setRequestMethod("GET");
   			 //Get请求不需要DoOutPut
   			 conn.setDoOutput(false);
   		 }
   		 else if (method.equalsIgnoreCase("POST")){
   			 conn.setRequestMethod("POST");
   			 conn.setDoOutput(true);
   			 conn.setUseCaches(false);
   		 }
   	 }
   	 //设置SSLSocketFactory对象
   	 conn.setSSLSocketFactory(sslFac);
     conn.setDoInput(true);
     //设置连接超时时间和读取超时时间
     conn.setConnectTimeout(connectTimeout);
     conn.setReadTimeout(readTimeout);
     conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
     return conn;
   }
	 /**
     * 
     * @Title: checkResponse 
     * @Description: 检查响应
     * @param conn
     * @return
     * @return: Object(Map,JSONObject,JSONArray,String)
     */
    public static Object handleResponse(HttpsURLConnection conn){
    	BufferedReader reader = null;
		try {
	    		int responseCode;
	    		responseCode = conn.getResponseCode();
				StringBuilder sb  = new StringBuilder();
		    	if (responseCode == HttpsURLConnection.HTTP_OK) {
		            InputStream in = conn.getInputStream();
		            reader = new BufferedReader(new InputStreamReader(in, "UTF-8"));
		            String line = null;
		            while ((line = reader.readLine()) != null) {
		                if(logger.isDebugEnabled())
		                	logger.error(line);
		                sb.append(line);
		            }
		            String r = sb.toString();
		            if(null != r && !"".equals(r)) {
		                if (r.startsWith("[")
		                		|| r.startsWith("{")){
		                	  logger.error("----------Https return JSON-----------"+r);
		                    return com.octopus.utils.alone.StringUtils.convert2MapJSONObject(r);//JSON.parse(r);
		                }else{
		                	logger.error("----------Https return String----------"+r);
		                    return r;
		                }
		            }else{
		                return null;
		            }
		        }
		    	else{
					logger.error("------------Https failed,url:"+conn.getURL()+",requestMethod:"+conn.getRequestMethod()+",response_code:"+conn.getResponseCode()+"------------");
		    	}
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally {
			//关闭连接
			try{
                if(reader!=null){
                	reader.close();
                }
                conn.disconnect();
            }
            catch(IOException ex){
                logger.error(" Handle response Message failed ", ex);;
            }
        }
       return null;
    }
}
