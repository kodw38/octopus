package com.octopus.tools.client.svn;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.tmatesoft.svn.core.ISVNLogEntryHandler;
import org.tmatesoft.svn.core.SVNCommitInfo;
import org.tmatesoft.svn.core.SVNDepth;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNNodeKind;
import org.tmatesoft.svn.core.SVNProperties;
import org.tmatesoft.svn.core.SVNURL;
import org.tmatesoft.svn.core.auth.ISVNAuthenticationManager;
import org.tmatesoft.svn.core.internal.io.dav.DAVRepositoryFactory;
import org.tmatesoft.svn.core.internal.io.fs.FSRepositoryFactory;
import org.tmatesoft.svn.core.internal.io.svn.SVNRepositoryFactoryImpl;
import org.tmatesoft.svn.core.internal.wc.DefaultSVNOptions;
import org.tmatesoft.svn.core.io.SVNRepository;
import org.tmatesoft.svn.core.io.SVNRepositoryFactory;
import org.tmatesoft.svn.core.wc.SVNClientManager;
import org.tmatesoft.svn.core.wc.SVNCommitClient;
import org.tmatesoft.svn.core.wc.SVNLogClient;
import org.tmatesoft.svn.core.wc.SVNRevision;
import org.tmatesoft.svn.core.wc.SVNStatus;
import org.tmatesoft.svn.core.wc.SVNStatusClient;
import org.tmatesoft.svn.core.wc.SVNUpdateClient;
import org.tmatesoft.svn.core.wc.SVNWCClient;
import org.tmatesoft.svn.core.wc.SVNWCUtil;

public class SVNUtils
{
  private static Logger logger = Logger.getLogger(SVNUtils.class);
  private static Map<String, String> history = new HashMap();
  private static Lock lock = new ReentrantLock();

  public static void setupLibrary()
  {
    DAVRepositoryFactory.setup();
    SVNRepositoryFactoryImpl.setup();
    FSRepositoryFactory.setup();
  }

  public static SVNClientManager authSvn(String svnRoot, String username, String password)
  {
    setupLibrary();

    SVNRepository repository = null;
    try {
      repository = SVNRepositoryFactory.create(SVNURL.parseURIEncoded(svnRoot));
    }
    catch (SVNException e) {
      logger.error(e.getErrorMessage(), e);
      return null;
    }

    ISVNAuthenticationManager authManager = SVNWCUtil.createDefaultAuthenticationManager(username, password);

    repository.setAuthenticationManager(authManager);

    DefaultSVNOptions options = SVNWCUtil.createDefaultOptions(true);
    SVNClientManager clientManager = SVNClientManager.newInstance(options, authManager);

    return clientManager;
  }

  public static SVNCommitInfo makeDirectory(SVNClientManager clientManager, SVNURL url, String commitMessage)
  {
    try
    {
      return clientManager.getCommitClient().doMkDir(new SVNURL[] { url }, commitMessage);
    }
    catch (SVNException e) {
      logger.error(e.getErrorMessage(), e);

      return null;
    }
  }

  public static SVNCommitInfo importDirectory(SVNClientManager clientManager, File localPath, SVNURL dstURL, String commitMessage, boolean isRecursive)
  {
    try
    {
      return clientManager.getCommitClient().doImport(localPath, dstURL, commitMessage, null, true, true, SVNDepth.fromRecurse(isRecursive));
    }
    catch (SVNException e)
    {
      logger.error(e.getErrorMessage(), e);

      return null;
    }
  }

  public static void addEntry(SVNClientManager clientManager, File wcPath)
  {
    try
    {
      clientManager.getWCClient().doAdd(new File[] { wcPath }, true, false, false, SVNDepth.INFINITY, false, false, true);
    }
    catch (SVNException e)
    {
      logger.error(e.getErrorMessage(), e);
    }
  }

  public static SVNStatus showStatus(SVNClientManager clientManager, File wcPath, boolean remote)
  {
    SVNStatus status = null;
    try {
      status = clientManager.getStatusClient().doStatus(wcPath, remote);
    } catch (SVNException e) {
      logger.error(e.getErrorMessage(), e);
    }
    return status;
  }

  public static SVNCommitInfo commit(SVNClientManager clientManager, File wcPath, boolean keepLocks, String commitMessage)
  {
    try
    {
      return clientManager.getCommitClient().doCommit(new File[] { wcPath }, keepLocks, commitMessage, null, null, false, false, SVNDepth.INFINITY);
    }
    catch (SVNException e)
    {
      logger.error(e.getErrorMessage(), e);

      return null;
    }
  }

  public static long[] update(SVNClientManager clientManager, File[] wcPath, SVNRevision updateToRevision, SVNDepth depth)
  {
    SVNUpdateClient updateClient = clientManager.getUpdateClient();

    updateClient.setIgnoreExternals(false);
    try
    {
      return updateClient.doUpdate(wcPath, updateToRevision, depth, false, false);
    } catch (SVNException e) {
      logger.error(e.getErrorMessage(), e);

      return new long[0];
    }
  }

  public static long checkout(SVNClientManager clientManager, SVNURL url, SVNRevision revision, File destPath, SVNDepth depth)
  {
    SVNUpdateClient updateClient = clientManager.getUpdateClient();

    updateClient.setIgnoreExternals(false);
    try
    {
      return updateClient.doCheckout(url, destPath, revision, revision, depth, false);
    }
    catch (SVNException e)
    {
      logger.error(e.getErrorMessage(), e);

      return 0L; } }

  public static boolean isFile(String s) {
    s = s.replace("\\\\", "/");
    s = s.substring(s.lastIndexOf("/") + 1);

    return (s.indexOf(".") > 0);
  }

  public static long exportSVNFile(SVNClientManager clientManager, SVNURL url, String svnFileName, File localWorkSpace, SVNRevision revision, SVNDepth depth)
    throws SVNException
  {
    return clientManager.getUpdateClient().doExport(url.appendPath(svnFileName, true), localWorkSpace, revision, revision, null, true, depth);
  }

  public static boolean isWorkingCopy(File path)
  {
    if (!(path.exists())) {
      logger.warn("'" + path + "' not exist!");
      return false;
    }
    try {
      if (null == SVNWCUtil.getWorkingCopyRoot(path, false))
        return false;
    }
    catch (SVNException e) {
      logger.error(e.getErrorMessage(), e);
    }
    return true;
  }

  public static long getSVNFile(SVNRepository svnRepository, String svnFileName, File localFile, File localWorkSpace) throws SVNException, FileNotFoundException {
    if (!(StringUtils.isEmpty(svnFileName))) {
      SVNProperties fileProperties = new SVNProperties();
      if (null != localFile) {
        return svnRepository.getFile(svnFileName, -1L, fileProperties, new BufferedOutputStream(new FileOutputStream(localFile)));
      }

      return svnRepository.getFile(svnFileName, -1L, fileProperties, new BufferedOutputStream(new FileOutputStream(localWorkSpace.getPath() + "\\" + svnFileName)));
    }

    return 0L;
  }

  public static boolean isURLExist(SVNURL url, String username, String password)
  {
    SVNRepository svnRepository;
    try
    {
      svnRepository = SVNRepositoryFactory.create(url);
      ISVNAuthenticationManager authManager = SVNWCUtil.createDefaultAuthenticationManager(username, password);
      svnRepository.setAuthenticationManager(authManager);
      SVNNodeKind nodeKind = svnRepository.checkPath("", -1L);
      return (nodeKind != SVNNodeKind.NONE);
    } catch (SVNException e) {
      e.printStackTrace();

      return false; }
  }

  public static void getStatus(SVNClientManager clientManager, File path, boolean remote) throws SVNException {
    SVNStatusClient status = clientManager.getStatusClient();
    status.doStatus(path, remote);
  }

  public static void cleanUp(SVNClientManager clientManager, File path) throws SVNException {
    SVNWCClient wcClient = clientManager.getWCClient();
    wcClient.doCleanup(path);
  }

  public static void getLog(SVNClientManager clientManager, SVNURL svnUrl, String[] paths, Date begin, Date end, ISVNLogEntryHandler handler)
    throws SVNException
  {
    clientManager.getLogClient().doLog(svnUrl, paths, SVNRevision.create(begin), SVNRevision.create(begin), SVNRevision.create(end), false, true, 999L, handler);
  }

  public static void getLog(SVNClientManager clientManager, SVNURL svnUrl, String[] paths, Long begin, Long end, ISVNLogEntryHandler handler)
    throws SVNException
  {
    clientManager.getLogClient().doLog(svnUrl, paths, SVNRevision.create(begin.longValue()), SVNRevision.create(begin.longValue()), SVNRevision.create(end.longValue()), false, true, 999L, handler);
  }
}