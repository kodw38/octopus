package com.octopus.tools.client.ssh;

import com.jcraft.jsch.Session;
import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.file.FileUtils;
import com.octopus.utils.net.NetUtils;
import com.octopus.utils.net.ssh.SSHClient;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class SSHClientObject extends XMLDoObject
{
  static transient Log log = LogFactory.getLog(SSHClientObject.class);
  SSHClient ssh;

  public SSHClientObject(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers); }

  public void doInitial() throws Exception {
    Map map;
    try {
      map = getXML().getProperties();
      map = XMLParameter.getMapValueFromParameter(getEmptyParameter(), map, this);
      this.ssh = getClient(map);
    } catch (Exception e) {
      log.error("", e); } }

  SSHClient getClient(Map map) throws Exception {
    String host;
    try {
      host = (String)map.get("host");
      int port = 22;
      if (StringUtils.isNotBlank(map.get("port")))
        port = Integer.parseInt((String)map.get("port"));
      String username = (String)map.get("username");
      String password = (String)map.get("password");
      log.info("ssh login with " + username);
      if ((StringUtils.isNotBlank(host)) && (StringUtils.isNotBlank(username)) && (StringUtils.isNotBlank(password)))
        return NetUtils.getSSHClient(host, port, username, password);
    }
    catch (Exception e) {
      log.error("can not connect ssh [" + map + "]");
    }

    return null;
  }

  public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    String cm;
    SSHClient client = this.ssh;
    if ((null != input) && (input.containsKey("host")))
      client = getClient(input);

    if ((null != config) && (config.size() > 0)) {
      client = getClient(config);
      if (null == client)
        client = this.ssh;
    }

    if (null == client)
      getClient(getXML().getProperties());
    if ((null != client) && (!(client.getSession().isConnected()))) {
      client = getClient(getXML().getProperties());
    }

    String type = (String)input.get("type");
    Object command = input.get("data");
    String remotepath = (String)input.get("rpath");
    if ("command".equals(type)) {
      cm = ((String)command).replaceAll("\\\\'", "'");
      log.debug(cm);
      StringBuffer sb = client.exec(cm);
      log.debug(sb.toString());
      if (null != sb)
        return sb.toString();
    }
    else if ("shell".equals(type)) {
      StringBuilder sb = client.shell((String)command);
      if (null != sb)
        return sb.toString();
    }
    else if ("copy".equals(type)) {
      if (command instanceof InputStream)
        return Boolean.valueOf(client.copyFileToRemote((InputStream)command, remotepath));
      if (command instanceof String) {
        File f = new File((String)command);
        if (f.isFile()) {
          if (remotepath.endsWith("/"))
            remotepath = remotepath + f.getName();

          FileInputStream fin = new FileInputStream((String)command);
          boolean ret = client.copyFileToRemote(fin, remotepath);
          fin.close();
          return Boolean.valueOf(ret); }
        if (f.isDirectory()) {
          List fs = FileUtils.getAllFile((String)command, null);
          int n = 0;
          for (Iterator i$ = fs.iterator(); i$.hasNext(); ) { File t = (File)i$.next();
            FileInputStream fin = new FileInputStream(t);
            client.copyFileToRemote(fin, remotepath + "/" + t.getName());
            ++n;
            fin.close();
          }
          return Integer.valueOf(n);
        }
      }
    } else if ("exec".equals(type));
    try {
      cm = ((String)command).replaceAll("\\\\'", "'");
      String[] cmds = { "/bin/sh", "-c", cm };
      Process pro = Runtime.getRuntime().exec(cmds);
      InputStream in = pro.getErrorStream();
      Scanner s = new Scanner(in).useDelimiter("\\A");
      String result = (s.hasNext()) ? s.next() : "";
      if (log.isDebugEnabled())
        log.debug("exec shell:\n" + result);

      in = pro.getInputStream();
      s = new Scanner(in).useDelimiter("\\A");
      result = (s.hasNext()) ? s.next() : "";
      if (log.isDebugEnabled())
        log.debug("exec shell:\n" + result);

      pro.waitFor();
      return result;
    } catch (Exception e) {
      log.error("exec shell error:" + command, e);

      return null;
    }
  }

  public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    return true;
  }

  public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return new ResultCheck(true, ret);
  }

  public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return false;
  }

  public boolean rollback(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret, Exception e) throws Exception
  {
    return false;
  }
}