package com.octopus.tools.client.http.impl;

public class UrlDS
{
  String url;
  String proxyName;
  String proxyPwd;
  String proxyUrl;
  int proxyPort;
  String[] removeRequestCookies;
  String[] saveResponseCookies;
  int connectionTimeout;
  int readTimeout;
  boolean redirect;

  public boolean isRedirect()
  {
    return this.redirect;
  }

  public void setRedirect(boolean redirect) {
    this.redirect = redirect;
  }

  public String getUrl() {
    return this.url;
  }

  public String getProxyUrl() {
    return this.proxyUrl;
  }

  public void setProxyUrl(String proxyUrl) {
    this.proxyUrl = proxyUrl;
  }

  public int getProxyPort() {
    return this.proxyPort;
  }

  public void setProxyPort(int proxyPort) {
    this.proxyPort = proxyPort;
  }

  public int getConnectionTimeout() {
    return this.connectionTimeout;
  }

  public void setConnectionTimeout(int connectionTimeout) {
    this.connectionTimeout = connectionTimeout;
  }

  public int getReadTimeout() {
    return this.readTimeout;
  }

  public void setReadTimeout(int readTimeout) {
    this.readTimeout = readTimeout;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getProxyName() {
    return this.proxyName;
  }

  public void setProxyName(String proxyName) {
    this.proxyName = proxyName;
  }

  public String getProxyPwd() {
    return this.proxyPwd;
  }

  public void setProxyPwd(String proxyPwd) {
    this.proxyPwd = proxyPwd;
  }

  public String[] getRemoveRequestCookies() {
    return this.removeRequestCookies;
  }

  public void setRemoveRequestCookies(String[] removeRequestCookies) {
    this.removeRequestCookies = removeRequestCookies;
  }

  public String[] getSaveResponseCookies() {
    return this.saveResponseCookies;
  }

  public void setSaveResponseCookies(String[] saveResponseCookies) {
    this.saveResponseCookies = saveResponseCookies;
  }
}