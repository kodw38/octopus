/**   
 * Copyright © 2017 公司名. All rights reserved.
 * 
 * @Title: UMBX509TrustManager.java 
 * @Prject: integration1
 * @Package: com.asiainfo.um.RESTful.common.util 
 * @Description: 信任证书校验
 * @author: ligs   
 * @date: 2017年11月23日 上午10:42:14 
 * @version: V1.0   
 */
package com.octopus.tools.client.https;

import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import net.sf.json.JSONArray;

/** 
 * @ClassName: UMBX509TrustManager 
 * @Description: 自定义信任管理器，用于证书校验
 * @author: ligs
 * @date: 2017年11月23日 上午10:42:14  
 */
public class UMBX509TrustManager implements X509TrustManager{
    static transient Log logger = LogFactory.getLog(UMBX509TrustManager.class);

	private static final String trustStorePath = "crmAdapter/ssl/umobile.truststore.jks";
	private static final String trustStorePwd = "umobile";
	
    private X509TrustManager x509TrustManager;
    /**
     * 
     * @Title:UMBX509TrustManager
     * @Description:使用信任库文件实例化x509TrustManager
     * @throws Exception
     */
    UMBX509TrustManager() throws Exception { 
    	try {
	        //使用config文件作为受信任证书库
	        KeyStore ks = KeyStore.getInstance("JKS");
	        logger.info("use "+trustStorePath+" as trustStore");
	        ks.load(read(trustStorePath), 
	        	trustStorePwd.toCharArray());
	        //获取证书库的trustManager
	        x509TrustManager = initX509TrustManager(ks);
	        return;
    	}catch (Exception e) {
    		throw new Exception("Couldn't initialize X509TrustManager",e); 
		}
    } 
    /**
     * 校验客户端证书
     */
	public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
		 try{ 
			logger.info("checkClientTrusted:"+JSONArray.fromObject(chain).toString());
			x509TrustManager.checkClientTrusted(chain, authType); 
         }catch (CertificateException excep) { 
            initX509TrustManager(null).checkClientTrusted(chain, authType); 
         } 
	}
	/**
	 * 校验服务端证书
	 */
	public void checkServerTrusted(X509Certificate[] chains, String authType) throws CertificateException {
		try {
			logger.error("checkServerTrusted:"+JSONArray.fromObject(chains).toString());
			x509TrustManager.checkServerTrusted(chains, authType); 
        } catch (CertificateException excep) { 
        	//使用jdk默认证书校验
        	initX509TrustManager(null).checkServerTrusted(chains, authType);
        } 
	}
	/**
	 * 返回受信任的X509证书数组
	 */
	public X509Certificate[] getAcceptedIssuers() {
		 return x509TrustManager.getAcceptedIssuers(); 
	}
	public static SSLSocketFactory getSSLFactory() throws Exception {
		TrustManager[] trust = {new UMBX509TrustManager()};
		SSLContext sslContext = SSLContext.getInstance("SSl", "SunJSSE");
		//使用自定义信任管理器和随机数初始化
		sslContext.init(null, trust, new SecureRandom());
		return sslContext.getSocketFactory();
	}
	private InputStream read(String path) throws IOException {
		return Thread.currentThread().getContextClassLoader().getResource(path).openStream() ;
	}
	private X509TrustManager initX509TrustManager(KeyStore ks) {
		X509TrustManager x509TrustManager;
		try {
			TrustManagerFactory factory = 
	        		TrustManagerFactory.getInstance("SunX509", "SunJSSE"); 
	        factory.init(ks); 
	        TrustManager managers [] = factory.getTrustManagers(); 
	        /**
	         * 遍历管理器，获取X509TrustManager的实现
	         */
	        for (TrustManager manager : managers) { 
	            if (manager instanceof X509TrustManager) { 
	            	x509TrustManager = (X509TrustManager) manager; 
	                return x509TrustManager; 
	            } 
	        } 
		}catch (Exception e) {
			logger.error("initX509TrustManager Failed",e);
		}
		return null;
	}
	public static void main(String[] args) throws Exception {
		new UMBX509TrustManager();
	}
}
