package com.octopus.tools.client.http;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Hashtable;

public class HttpDS
{
  Hashtable<String, String> requestHeaders;
  Hashtable<String, String> responseHeaders;
  String methodName;
  InputStream requestInputStream;
  int requestInputStreamLength;
  OutputStream responseOutputStream;
  String contentType;
  long contentLength;
  int statusCode;
  String base;
  boolean isSendCookie;
  HashMap<String, String> properties;
  String proxyName;
  String proxyPwd;
  String proxyUrl;
  int proxyPort;
  String[] removeRequestCookies;
  String[] saveResponseCookies;
  int connectionTimeout;
  int readTimeout;
  Boolean redirect;
  String url;

  public HttpDS()
  {
    this.properties = new HashMap();

    this.proxyUrl = null;
    this.proxyPort = 0;
    this.removeRequestCookies = null;
    this.saveResponseCookies = null;
    this.connectionTimeout = 0; this.readTimeout = 0;
  }

  public boolean isSendCookie()
  {
    return this.isSendCookie;
  }

  public void setSendCookie(boolean isSendCookie) {
    this.isSendCookie = isSendCookie;
  }

  public String getUrl() {
    return this.url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getProxyName() {
    return this.proxyName;
  }

  public void setProxyName(String proxyName) {
    this.proxyName = proxyName;
  }

  public String getProxyPwd() {
    return this.proxyPwd;
  }

  public void setProxyPwd(String proxyPwd) {
    this.proxyPwd = proxyPwd;
  }

  public String getProxyUrl() {
    return this.proxyUrl;
  }

  public void setProxyUrl(String proxyUrl) {
    this.proxyUrl = proxyUrl;
  }

  public int getProxyPort() {
    return this.proxyPort;
  }

  public void setProxyPort(int proxyPort) {
    this.proxyPort = proxyPort;
  }

  public String[] getRemoveRequestCookies() {
    return this.removeRequestCookies;
  }

  public void setRemoveRequestCookies(String[] removeRequestCookies) {
    this.removeRequestCookies = removeRequestCookies;
  }

  public String[] getSaveResponseCookies() {
    return this.saveResponseCookies;
  }

  public void setSaveResponseCookies(String[] saveResponseCookies) {
    this.saveResponseCookies = saveResponseCookies;
  }

  public int getConnectionTimeout() {
    return this.connectionTimeout;
  }

  public void setConnectionTimeout(int connectionTimeout) {
    this.connectionTimeout = connectionTimeout;
  }

  public int getReadTimeout() {
    return this.readTimeout;
  }

  public void setReadTimeout(int readTimeout) {
    this.readTimeout = readTimeout;
  }

  public Boolean isRedirect() {
    return this.redirect;
  }

  public void setRedirect(boolean redirect) {
    this.redirect = Boolean.valueOf(redirect);
  }

  public HashMap<String, String> getProperties() {
    return this.properties;
  }

  public void setProperties(HashMap<String, String> properties) {
    this.properties = properties;
  }

  public int getRequestInputStreamLength() {
    return this.requestInputStreamLength;
  }

  public void setRequestInputStreamLength(int requestInputStreamLength) {
    this.requestInputStreamLength = requestInputStreamLength;
  }

  public Hashtable<String, String> getRequestHeaders() {
    if (null == this.requestHeaders) this.requestHeaders = new Hashtable();
    return this.requestHeaders;
  }

  public void setRequestHeaders(Hashtable<String, String> requestHeaders) {
    this.requestHeaders = requestHeaders;
  }

  public Hashtable<String, String> getResponseHeaders() {
    return this.responseHeaders;
  }

  public void setResponseHeaders(Hashtable<String, String> responseHeaders) {
    this.responseHeaders = responseHeaders;
  }

  public String getMethodName() {
    return this.methodName;
  }

  public void setMethodName(String methodName) {
    this.methodName = methodName;
  }

  public InputStream getRequestInputStream() {
    return this.requestInputStream;
  }

  public void setRequestInputStream(InputStream requestInputStream) {
    this.requestInputStream = requestInputStream;
  }

  public OutputStream getResponseOutputStream() {
    return this.responseOutputStream;
  }

  public void setResponseOutputStream(OutputStream responseOutputStream) {
    this.responseOutputStream = responseOutputStream;
  }

  public String getContentType() {
    return this.contentType;
  }

  public void setContentType(String contentType) {
    this.contentType = contentType;
  }

  public long getContentLength() {
    return this.contentLength;
  }

  public void setContentLength(long contentLength) {
    this.contentLength = contentLength;
  }

  public int getStatusCode() {
    return this.statusCode;
  }

  public void setStatusCode(int statusCode) {
    this.statusCode = statusCode;
  }

  public String getBase() {
    return this.base;
  }

  public void setBase(String base) {
    this.base = base;
  }
}