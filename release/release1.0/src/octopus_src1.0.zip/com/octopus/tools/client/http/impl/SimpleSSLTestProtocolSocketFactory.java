package com.octopus.tools.client.http.impl;

import com.octopus.utils.alone.StringUtils;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.rmi.UnknownHostException;
import java.security.KeyStore;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import org.apache.commons.httpclient.ConnectTimeoutException;
import org.apache.commons.httpclient.params.HttpConnectionParams;
import org.apache.commons.httpclient.protocol.ControllerThreadSocketFactory;
import org.apache.commons.httpclient.protocol.SecureProtocolSocketFactory;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class SimpleSSLTestProtocolSocketFactory
  implements SecureProtocolSocketFactory
{
  private static final Log LOG = LogFactory.getLog(SimpleSSLTestProtocolSocketFactory.class);
  private static SSLContext SSLCONTEXT = null;
  String keyStoreType = "PKCS12";
  String keyStroeFile;
  String password;
  String managePassword;

  public SimpleSSLTestProtocolSocketFactory(String keyStoreType, String keyStoreFile, String password, String managePassword)
  {
    if (StringUtils.isNotBlank(keyStoreType))
      this.keyStoreType = keyStoreType;

    this.keyStroeFile = keyStoreFile;
    this.password = password;
    this.managePassword = managePassword; }

  private SSLContext createSSLContext() {
    KeyStore keystore;
    try {
      keystore = KeyStore.getInstance(this.keyStoreType);
      FileInputStream ksInstream = new FileInputStream(new File(this.keyStroeFile));
      try
      {
        keystore.load(ksInstream, this.password.toCharArray());
      }
      finally {
        if (ksInstream != null)
          ksInstream.close();

      }

      KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());

      keyManagerFactory.init(keystore, this.password.toCharArray());

      KeyManager[] keymanagers = keyManagerFactory.getKeyManagers();

      SSLContext sslcontext = SSLContext.getInstance("TLS");

      sslcontext.init(keymanagers, null, null);
      return sslcontext;
    } catch (Exception ex) {
      LOG.error(ex.getMessage(), ex);
      throw new IllegalStateException(ex.getMessage());
    }
  }

  private SSLContext getSSLContext()
  {
    if (SSLCONTEXT == null)
      SSLCONTEXT = createSSLContext();

    return SSLCONTEXT;
  }

  public Socket createSocket(String host, int port, InetAddress localAddress, int localPort, HttpConnectionParams params)
    throws IOException, UnknownHostException, ConnectTimeoutException
  {
    if (params == null)
      throw new IllegalArgumentException("Parameters may not be null");

    int timeout = params.getConnectionTimeout();
    if (timeout == 0) {
      return createSocket(host, port, localAddress, localPort);
    }

    return ControllerThreadSocketFactory.createSocket(this, host, port, localAddress, localPort, timeout);
  }

  public Socket createSocket(String host, int port, InetAddress clientHost, int clientPort)
    throws IOException, UnknownHostException
  {
    return getSSLContext().getSocketFactory().createSocket(host, port, clientHost, clientPort);
  }

  public Socket createSocket(String host, int port)
    throws IOException, UnknownHostException
  {
    return getSSLContext().getSocketFactory().createSocket(host, port);
  }

  public Socket createSocket(Socket socket, String host, int port, boolean autoClose) throws IOException, UnknownHostException
  {
    return getSSLContext().getSocketFactory().createSocket(socket, host, port, autoClose);
  }
}