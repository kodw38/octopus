package com.octopus.tools.client.http.impl;

import com.octopus.tools.client.http.HttpDS;

public abstract interface IHttpParse
{
  public abstract UrlDS getUrl(HttpDS paramHttpDS)
    throws Exception;
}