package com.octopus.tools.client.svn;

public final class SVNConsts
{
  public static final String DEPLOY_EXCEL_PATH = "deployExcel";
  public static final String DEPLOY_SHEET_NAME = "SVN";
  public static final String RELEASE_VISION = "Release_Vision";
  public static final String SVN_PATH = "Svn_Path";
  public static final String RELEASE_NOTE_PATH = "Release_Note_Path";
  public static final String RELEASE_LOCATION = "Release_Location";
  public static final String RELEASE_SHEET_NAME = "Release Note";
  public static final String FILE_LIST = "Filelist";
}