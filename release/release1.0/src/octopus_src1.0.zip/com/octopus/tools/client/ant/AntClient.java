/**   
 * Copyright © 2017 公司名. All rights reserved.
 * 
 * @Title: AntClient.java 
 * @Prject: treasurebag
 * @Package: com.octopus.tools.client.ant
 * @Description: TODO
 * @author: ligs   
 * @date: 2017年9月15日 下午4:48:05 
 * @version: V1.0   
 */
package com.octopus.tools.client.ant;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.DefaultLogger;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.ProjectHelper;

import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.file.FileUtils;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;

/** 
 * @ClassName: AntClient 
 * @Description: TODO
 * @author: ligs
 * @date: 2017年9月15日 下午4:48:05  
 */
public class AntClient extends XMLDoObject {

	/** 
	 * @Title:AntClient
	 * @Description:TODO 
	 * @param xml
	 * @param parent
	 * @throws Exception 
	 */
	public AntClient(XMLMakeup xml, XMLObject parent,Object[] containers) throws Exception {
		super(xml, parent,containers);
		// TODO Auto-generated constructor stub
	}

    @Override
    public void doInitial() throws Exception {

    }

    /* (non Javadoc)
         * @Title: checkInput
         * @Description: TODO
         * @param arg0
         * @param arg1
         * @param arg2
         * @param arg3
         * @param arg4
         * @return
         * @throws Exception
         * @see com.octopus.utils.xml.auto.IXMLDoObject#checkInput(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map)
         */
	@Override
    public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception {
		if(StringUtils.isEmpty((String)input.get("buildfile")))
			return false;
		return true;
	}

	/* (non Javadoc) 
	 * @Title: checkReturn
	 * @Description: TODO
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @param arg3
	 * @param arg4
	 * @param arg5
	 * @return
	 * @throws Exception 
	 * @see com.octopus.utils.xml.auto.IXMLDoObject#checkReturn(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map, java.lang.Object)
	 */
	@Override
    public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception {
		 return new ResultCheck(true,ret);
	}

    @Override
    public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception {
        return false;
    }

    /* (non Javadoc)
     * @Title: doSomeThing
     * @Description: ant脚本执行
     * @param arg0
     * @param arg1
     * @param arg2
     * @param arg3
     * @param arg4
     * @return
     * @throws Exception
     * @see com.octopus.utils.xml.auto.IXMLDoObject#doSomeThing(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map)
     */
	@Override
    public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception {
		//xml中的变量
		Map<String,String> propertiesMap = (Map<String, String>) input.get("properties");
		String buildfile = (String) input.get("buildfile");
		byte[] xmlContent = (byte[]) input.get("xmlContent");
		File readFile = null;
		File buildFile = null;
		if(StringUtils.isNotEmpty(buildfile)) {
		buildFile=new File(buildfile);
		if(!buildFile.exists()
				|| !buildFile.isFile())
			throw new Exception("buildfile not exist");
		}
		
		
		if(null != propertiesMap && !propertiesMap.isEmpty()) {
			//获取xml内容
			String fileContent = StringUtils.isEmpty(buildfile)
					?((null != xmlContent && xmlContent.length > 0)?new String(xmlContent,"UTF-8"):null)
				:FileUtils.getFileContentByFile(buildFile);
			if(StringUtils.isEmpty(fileContent))
				throw new Exception("read source fail,check buildfile path or xmlContent");
			//创建一个ANT项目
			//替换build.xml中的每个变量
			
			for(Entry<String, String> property : propertiesMap.entrySet()) {
				if(StringUtils.isNotEmpty(property.getKey())) 
					fileContent = fileContent.replaceAll("\\$\\{"+property.getKey()+"\\}", property.getValue());
			}
			
			//创建替换变量后的临时文件
			String suffix = buildFile.getName().substring(buildFile.getName().lastIndexOf(".")+1);
			String filePath = buildfile.substring(0,buildfile.lastIndexOf("/")+1);
			OutputStream newFileOut = new BufferedOutputStream(new FileOutputStream(filePath+"antclient_Test_file."+suffix));
			newFileOut.write(fileContent.getBytes("UTF-8"));
			newFileOut.flush();
			newFileOut.close();
			readFile = new File(filePath+"./antclient_Test_file."+suffix);
		}
		Project p=new Project();
        //创建一个默认的监听器,监听项目构建过程中的日志操作

        DefaultLogger consoleLogger = new DefaultLogger();

        consoleLogger.setErrorPrintStream(System.err);

        consoleLogger.setOutputPrintStream(System.out);

        consoleLogger.setMessageOutputLevel(Project.MSG_INFO);

        p.addBuildListener(consoleLogger);

        try{
                 p.fireBuildStarted();

                 //初始化该项目

                 p.init();

                 ProjectHelper helper=ProjectHelper.getProjectHelper();

                 //解析项目的构建文件

                 helper.parse(p, readFile);

                 //执行项目的某一个目标

                 p.executeTarget(p.getDefaultTarget());

                 p.fireBuildFinished(null);

        }catch(BuildException be){
                 p.fireBuildFinished(be);
        }
        finally {
				readFile.deleteOnExit();
		}
		return "SUCCESS";
	}

	/* (non Javadoc) 
	 * @Title: rollback
	 * @Description: TODO
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @param arg3
	 * @param arg4
	 * @param arg5
	 * @param arg6
	 * @return
	 * @throws Exception 
	 * @see com.octopus.utils.xml.auto.IXMLDoObject#rollback(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map, java.lang.Object, java.lang.Exception)
	 */
	@Override
	public boolean rollback(String arg0, XMLParameter arg1, Map arg2, Map arg3, Map arg4, Object arg5, Exception arg6)
			throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

	public static void main(String[] args) throws Exception {
		AntClient client = new AntClient(null, null,null);
		Map input1 = new HashMap();
		Map input = new HashMap();
		input.put("build.svn.dir", "../../../svntest_int_code");
		input.put("build.lib.dir", "../../../svntest_lib_inte");
		input.put("build.tmp.dir", "../../../svntest_tmp_inte");
		input.put("build.dist.dir", "../../../svntest_dist_inte");
		input.put("build.config.dir", "../../../svntest_config_inte");
		input.put("build.tmp.classes", "../../../svntest_tmp_inte/classes");
		input1.put("properties", input);
		input1.put("buildfile", "C:/Users/Peter/Downloads/build_inte.xml");
		client.doSomeThing(null, null, input1, null, null);
	}
}
