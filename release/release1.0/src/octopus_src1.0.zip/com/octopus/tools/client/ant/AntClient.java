package com.octopus.tools.client.ant;

import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.file.FileUtils;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.DefaultLogger;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.ProjectHelper;

public class AntClient extends XMLDoObject
{
  public AntClient(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void doInitial()
    throws Exception
  {
  }

  public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config)
    throws Exception
  {
    return (!(StringUtils.isEmpty((String)input.get("buildfile"))));
  }

  public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret)
    throws Exception
  {
    return new ResultCheck(true, ret);
  }

  public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return false;
  }

  public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config)
    throws Exception
  {
    Map propertiesMap = (Map)input.get("properties");
    String buildfile = (String)input.get("buildfile");
    byte[] xmlContent = (byte[])(byte[])input.get("xmlContent");
    File readFile = null;
    File buildFile = null;
    if (StringUtils.isNotEmpty(buildfile)) {
      buildFile = new File(buildfile);
      if ((!(buildFile.exists())) || (!(buildFile.isFile())))
      {
        throw new Exception("buildfile not exist");
      }
    }

    if ((null != propertiesMap) && (!(propertiesMap.isEmpty())))
    {
      String fileContent = (StringUtils.isEmpty(buildfile)) ? null : ((null != xmlContent) && (xmlContent.length > 0)) ? new String(xmlContent, "UTF-8") : FileUtils.getFileContentByFile(buildFile);

      if (StringUtils.isEmpty(fileContent)) {
        throw new Exception("read source fail,check buildfile path or xmlContent");
      }

      for (Iterator i$ = propertiesMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry property = (Map.Entry)i$.next();
        if (StringUtils.isNotEmpty((String)property.getKey()))
          fileContent = fileContent.replaceAll("\\$\\{" + ((String)property.getKey()) + "\\}", (String)property.getValue());

      }

      String suffix = buildFile.getName().substring(buildFile.getName().lastIndexOf(".") + 1);
      String filePath = buildfile.substring(0, buildfile.lastIndexOf("/") + 1);
      OutputStream newFileOut = new BufferedOutputStream(new FileOutputStream(filePath + "antclient_Test_file." + suffix));
      newFileOut.write(fileContent.getBytes("UTF-8"));
      newFileOut.flush();
      newFileOut.close();
      readFile = new File(filePath + "./antclient_Test_file." + suffix);
    }
    Project p = new Project();

    DefaultLogger consoleLogger = new DefaultLogger();

    consoleLogger.setErrorPrintStream(System.err);

    consoleLogger.setOutputPrintStream(System.out);

    consoleLogger.setMessageOutputLevel(2);

    p.addBuildListener(consoleLogger);
    try
    {
      p.fireBuildStarted();

      p.init();

      ProjectHelper helper = ProjectHelper.getProjectHelper();

      helper.parse(p, readFile);

      p.executeTarget(p.getDefaultTarget());

      p.fireBuildFinished(null);
    }
    catch (BuildException be) {
      p.fireBuildFinished(be);
    }
    finally {
      readFile.deleteOnExit();
    }
    return "SUCCESS";
  }

  public boolean rollback(String arg0, XMLParameter arg1, Map arg2, Map arg3, Map arg4, Object arg5, Exception arg6)
    throws Exception
  {
    return false;
  }

  public static void main(String[] args) throws Exception {
    AntClient client = new AntClient(null, null, null);
    Map input1 = new HashMap();
    Map input = new HashMap();
    input.put("build.svn.dir", "../../../svntest_int_code");
    input.put("build.lib.dir", "../../../svntest_lib_inte");
    input.put("build.tmp.dir", "../../../svntest_tmp_inte");
    input.put("build.dist.dir", "../../../svntest_dist_inte");
    input.put("build.config.dir", "../../../svntest_config_inte");
    input.put("build.tmp.classes", "../../../svntest_tmp_inte/classes");
    input1.put("properties", input);
    input1.put("buildfile", "C:/Users/Peter/Downloads/build_inte.xml");
    client.doSomeThing(null, null, input1, null, null);
  }
}