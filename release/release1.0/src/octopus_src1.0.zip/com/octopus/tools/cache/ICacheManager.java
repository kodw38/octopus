package com.octopus.tools.cache;

public abstract interface ICacheManager
{
  public abstract boolean addCache(ICache paramICache);

  public abstract ICache getCache(String paramString);

  public abstract void addListener(ICacheListener paramICacheListener);
}