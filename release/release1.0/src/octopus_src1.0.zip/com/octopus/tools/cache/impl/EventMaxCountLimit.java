package com.octopus.tools.cache.impl;

import com.octopus.tools.alarm.IAlarm;
import com.octopus.tools.cache.ICacheEvent;
import com.octopus.utils.alone.ObjectUtils;
import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.cls.ClassUtils;
import com.octopus.utils.thread.ExecutorUtils;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class EventMaxCountLimit extends XMLDoObject
  implements ICacheEvent
{
  IAlarm alarm;

  public EventMaxCountLimit(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public boolean doCacheEvent(String method, String key, Object value)
  {
    String mc = getXML().getProperties().getProperty("maxcount");
    String alarmtype = getXML().getProperties().getProperty("alarmtype");
    if (StringUtils.isNotBlank(mc)) {
      int max = Integer.parseInt(mc);
      if (null != getParent())
        try {
          Object f = ClassUtils.getFieldValue(getParent(), "size", false);
          if (null != f) {
            Number n = (Number)f;
            if (n.intValue() > max) {
              if ((null != this.alarm) && (StringUtils.isNotBlank(alarmtype))) {
                HashMap map = new HashMap();
                map.put("MaxCountLimit", mc);
                map.put("CurrentCount", Integer.valueOf(n.intValue()));
                ExecutorUtils.work(this.alarm, "addAlarm", new Class[] { List.class, List.class, String.class, String.class, Date.class, Integer.TYPE }, new Object[] { alarmtype, map });
              }
              return false;
            }
          }
        } catch (Exception e) {
          throw new RuntimeException(e);
        }
    }

    String mm = getXML().getProperties().getProperty("maxmemsize");
    if (StringUtils.isNotBlank(mm)) {
      int max = Integer.parseInt(mm);
      if (null != getParent())
        try {
          long m = ObjectUtils.getSizeOfJavaObject(getParent());
          if (m > max) {
            if ((null != this.alarm) && (StringUtils.isNotBlank(alarmtype))) {
              HashMap map = new HashMap();
              map.put("MaxMemLimit", mm);
              map.put("CurrentObjectMemSize", Long.valueOf(m));
              ExecutorUtils.work(this.alarm, "addAlarm", new Class[] { List.class, List.class, String.class, String.class, Date.class, Integer.TYPE }, new Object[] { alarmtype, map });
            }
            return false;
          }
        } catch (Exception e) {
          throw new RuntimeException(e);
        }
    }

    return true;
  }

  public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    doCacheEvent((String)input.get("op"), (String)input.get("key"), input.get("value"));
    return null;
  }

  public void doInitial()
    throws Exception
  {
  }

  public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    return true;
  }

  public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return new ResultCheck(true, ret);
  }

  public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return false;
  }

  public boolean rollback(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret, Exception e) throws Exception
  {
    return false;
  }
}