package com.octopus.tools.cache.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class QueryCondition
{
  static final int EQUAL = 1;
  static final int LIKE = 2;
  static final int START_WITH = 3;
  static final int END_WITH = 4;
  String key;
  int type;

  QueryCondition(int type, String key)
  {
    this.key = key;
    this.type = type;
  }

  public QueryCondition getLinkCondition(String key) {
    return new QueryCondition(2, key); }

  public QueryCondition getEqualCondition(String key) {
    return new QueryCondition(1, key); }

  public QueryCondition getStartWithCondition(String key) {
    return new QueryCondition(3, key); }

  public QueryCondition getEndWithCondition(String key) {
    return new QueryCondition(4, key);
  }

  public Object[] query(Map map) {
    Iterator its = map.keySet().iterator();
    List li = new ArrayList();
    while (its.hasNext()) {
      String k = (String)its.next();
      if ((this.type == 1) && 
        (k.equals(this.key))) {
        li.add(map.get(k));
      }

      if ((this.type == 2) && 
        (k.contains(this.key))) {
        li.add(map.get(k));
      }

      if ((this.type == 3) && 
        (k.startsWith(this.key))) {
        li.add(map.get(k));
      }

      if ((this.type == 4) && 
        (k.endsWith(this.key)))
        li.add(map.get(k));

    }

    if (li.size() > 0)
      return li.toArray();
    return null;
  }
}