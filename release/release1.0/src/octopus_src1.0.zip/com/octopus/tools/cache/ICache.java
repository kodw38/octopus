package com.octopus.tools.cache;

import com.octopus.tools.cache.impl.QueryCondition;
import java.util.Collection;
import java.util.Map;

public abstract interface ICache
{
  public static final String METHOD_NAME_ADD = "add";
  public static final String METHOD_NAME_ADDLIST = "addList";
  public static final String METHOD_NAME_UPDATE = "update";
  public static final String METHOD_NAME_DELETE = "delete";

  public abstract boolean init(String paramString, int paramInt1, int paramInt2);

  public abstract boolean add(boolean paramBoolean, String paramString, Object paramObject)
    throws InterruptedException;

  public abstract boolean addList(boolean paramBoolean1, String paramString, Object paramObject1, Object paramObject2, Map paramMap, int paramInt, boolean paramBoolean2)
    throws Exception;

  public abstract boolean initAdd(boolean paramBoolean, String paramString, Object paramObject)
    throws InterruptedException;

  public abstract Object get(boolean paramBoolean, String paramString);

  public abstract Collection getKeys(boolean paramBoolean);

  public abstract boolean switchStore();

  public abstract boolean update(boolean paramBoolean, String paramString, Object paramObject)
    throws InterruptedException;

  public abstract boolean delete(boolean paramBoolean, String paramString)
    throws InterruptedException;

  public abstract Object[] query(boolean paramBoolean, QueryCondition paramQueryCondition);

  public abstract boolean clear(boolean paramBoolean);

  public abstract void addListener(ICacheListener paramICacheListener);

  public abstract boolean existListObjectByUnique(String paramString, Object paramObject1, Object paramObject2);

  public abstract int getSize(boolean paramBoolean);

  public abstract String getId();
}