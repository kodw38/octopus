package com.octopus.tools.cache.impl;

import com.octopus.tools.cache.ICacheEvent;
import com.octopus.tools.dataclient.utils.IDataMapping;
import com.octopus.utils.alone.ArrayUtils;
import com.octopus.utils.cachebatch.AsynContainer;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class AmortizeStoreEvent extends XMLDoObject
  implements ICacheEvent
{
  static transient Log log = LogFactory.getLog(AmortizeStoreEvent.class);
  IDataMapping mapping;
  AsynContainer container = null;

  public AmortizeStoreEvent(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
    long intervalsecond = Long.parseLong(xml.getProperties().getProperty("intervalsecond"));
    long limitsize = Long.parseLong(xml.getProperties().getProperty("limitsize"));
    this.container = new AsynContainer(intervalsecond, limitsize, AmortizeTask.class);
    Object dataClient = getObjectById(xml.getProperties().getProperty("batchhandle"));
    this.container.setOther(dataClient);
  }

  public boolean doCacheEvent(String method, String key, Object value)
  {
    try
    {
      List tvs;
      if (method.equals("add"))
        if (null != this.mapping) {
          tvs = this.mapping.mapping(value);
          if (ArrayUtils.isNotEmpty(tvs)) {
            this.container.insert(tvs);
            return true;
          }
        } else {
          this.container.insert(value);
        }

      else if (method.equals("addList"))
        if (null != this.mapping) {
          tvs = this.mapping.mapping(value);
          if (ArrayUtils.isNotEmpty(tvs)) {
            this.container.insert(tvs);
            return true;
          }
        } else {
          this.container.insert(value);
        }
    }
    catch (Exception e) {
      log.error(e.getMessage(), e);
    }
    return false;
  }

  public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config)
    throws Exception
  {
    doCacheEvent((String)input.get("op"), (String)input.get("key"), input.get("value"));

    return null;
  }

  public void doInitial()
    throws Exception
  {
  }

  public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    return true;
  }

  public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return new ResultCheck(true, ret);
  }

  public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return false;
  }

  public boolean rollback(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret, Exception e) throws Exception
  {
    return false;
  }
}