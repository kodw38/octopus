package com.octopus.tools.cache;

public abstract interface ICacheListener
{
  public abstract void doListener(Object paramObject);
}