package com.octopus.tools.cache;

public abstract interface ICacheEvent
{
  public abstract boolean doCacheEvent(String paramString1, String paramString2, Object paramObject);
}