package com.octopus.tools.cache.impl;

import com.octopus.utils.cachebatch.FlushWorkTask;
import com.octopus.utils.xml.auto.XMLDoObject;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class AmortizeTask extends FlushWorkTask
{
  static transient Log log = LogFactory.getLog(AmortizeTask.class);

  public void work(Map paramMap)
    throws Exception
  {
    Iterator its = paramMap.values().iterator();
    List li = new ArrayList();
    while (its.hasNext()) {
      Object o = its.next();
      if (Collection.class.isAssignableFrom(o.getClass()))
        li.addAll((Collection)o);
      else
        li.add(o);
    }

    Map map = new HashMap();
    map.put("op", "add");
    map.put("datas", li);
    if (li.size() > 0) {
      log.debug("batch save size:" + li.size() + "\n about:\n" + li.get(0));
      ((XMLDoObject)getOther()).doSomeThing(null, null, map, null, null);
    }
  }
}