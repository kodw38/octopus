package com.octopus.tools.pubsub;

import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.cls.ClassUtils;
import com.octopus.utils.thread.ExecutorUtils;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.XMLParameter;
import com.octopus.utils.xml.auto.logic.XMLLogic;
import org.I0Itec.zkclient.IZkChildListener;
import org.I0Itec.zkclient.IZkDataListener;
import org.I0Itec.zkclient.IZkStateListener;
import org.I0Itec.zkclient.ZkClient;
import org.I0Itec.zkclient.serialize.BytesPushThroughSerializer;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.zookeeper.Watcher;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * User: wfgao_000
 * Date: 2016/9/28
 * Time: 16:51
 */
public class ZkClientListen extends XMLLogic {
    static Log log = LogFactory.getLog(ZkClientListen.class);
    ZkClient zkClient;
    List<String> currentList = new ArrayList();
    public ZkClientListen(XMLMakeup xml, XMLObject parent,Object[] containers) throws Exception {
        super(xml, parent,containers);
    }
    class DataChangeListener implements IZkDataListener{
        public void handleDataDeleted(String dataPath) throws Exception {
            if (null != dataPath) {
                String name = dataPath.substring(dataPath.lastIndexOf(".") + 1);
                XMLParameter par = new XMLParameter();
                par.addParameter("${event_op}", "delete");
                par.addParameter("${name}", name);
                doThing(par, getXML());
            }
            log.info("happen delete event :"+dataPath);
        }

        public void handleDataChange(String dataPath, Object data) throws Exception {
            if (null != data) {
                String cmd = new String((byte[]) data);
                Object obj = null;
                if (cmd.startsWith("{")) {
                    obj = StringUtils.convert2MapJSONObject(cmd);
                }else{
                    obj = cmd;
                }
                XMLParameter par = new XMLParameter();
                par.addParameter("${event_path}",dataPath);
                par.addParameter("${event_op}", "update");
                par.addParameter("${input_data}", obj);
                //log.error("publish do "+obj);
                doThing(par, getXML());

                log.debug("happen data event :"+dataPath+" "+obj);

            }
        }
    }

    private void addChildrenDataListener(String dataPath){
        if(StringUtils.isNotBlank(dataPath)) {
            //add exist path event
            List<String> hasExistList = zkClient.getChildren(dataPath);
            if (null != hasExistList) {
                for (String s : hasExistList) {
                    zkClient.subscribeDataChanges(dataPath + "/" + s, new DataChangeListener());
                    log.info("append zk data listener:"+dataPath + "/" + s);
                }
            }
        }
    }

    private void addPathListener(String dataPath){
        log.info("append zk path listener:"+dataPath );
        //create delete node happened, add , reduce event
        zkClient.subscribeChildChanges(dataPath, new IZkChildListener() {
            //用于监听zookeeper中servers节点的子节点列表变化
            public void handleChildChange(String parentPath, List<String> currentChilds) throws Exception {
                //更新服务器列表
                if(null != currentChilds){
                    synchronized (currentList) {
                        for (String c : currentChilds) {
                            if (!currentList.contains(c)) {
                                //add
                                log.info(" zk add path [" + parentPath + "/" + c + "]");
                                currentList.add(c);
                                XMLParameter par = new XMLParameter();
                                par.put("${event_op}", "addPathEvent");
                                par.put("${path}", parentPath + "/" + c);
                                doThing(par, getXML());
                            }
                        }
                    }
                    synchronized (currentList) {
                        for (int i = currentList.size() - 1; i >= 0; i--) {
                            if (!currentChilds.contains(currentList.get(i))) {
                                //delete
                                log.info(" zk delete path [" + currentList.get(i) + "]");
                                XMLParameter par = new XMLParameter();
                                par.put("${event_op}", "removePathEvent");
                                par.put("${path}", parentPath + "/" + currentList.get(i));
                                doThing(par, getXML());
                                currentList.remove(i);
                            }
                        }
                    }

                }

            }
        });
    }
    class PathListener implements IZkChildListener{
        @Override
        public void handleChildChange(String parentPath, List<String> currentChilds) throws Exception {
            //更新服务器列表
            for(String s:currentChilds) {
                String pa = parentPath+"/"+s;
                addChildrenPathListener(pa);
                log.info("event append zk path listener:" + pa);
                zkClient.subscribeDataChanges(pa, new DataChangeListener());
                log.info("event append zk data listener:"+pa);
            }
        }
    }
    private void addChildrenPathListener(String dataPath){
        log.info("append zk path children listener:"+dataPath );
        //create delete node happened, add , reduce event
        zkClient.subscribeChildChanges(dataPath, new PathListener());
    }
    void addStatusListener(){
        zkClient.subscribeStateChanges(new IZkStateListener() {
            @Override
            public void handleStateChanged(Watcher.Event.KeeperState keeperState) throws Exception {
                log.warn("zk status changed"+keeperState.getIntValue()+"|"+keeperState.name());
                if(keeperState.getIntValue()==0 && "Disconnected".equals(keeperState.name())){
                    boolean b = zkClient.waitUntilConnected(5000, TimeUnit.MILLISECONDS);
                    if(!b) {
                        zkClient = null;
                        ExecutorUtils.work(new ReConn());
                        log.error("zkClient disconnectioned and wait 30 seconds will reconnect");
                    }
                }
            }

            @Override
            public void handleNewSession() throws Exception {
                System.out.println("zk status new Session");
            }

            @Override
            public void handleSessionEstablishmentError(Throwable throwable) throws Exception {
                log.error("handleSessionEstablishmentError",throwable);
            }
        });
    }
    private void connzk()throws Exception{
        log.info("connecting zk server......");
        String config = getXML().getProperties().getProperty("config");
        Map cof = StringUtils.convert2MapJSONObject(config);
        try {
            zkClient = new ZkClient((String) cof.get("hostPort"), (Integer)cof.get("sessionTimeout"), (Integer)cof.get("connectTimeout"), new BytesPushThroughSerializer());
            //zkClient = new ZkClient((String) cof.get("hostPort"), 30000, 30000, new BytesPushThroughSerializer());
            addStatusListener();
        }catch (Exception e){
            log.error(cof.get("hostPort"),e);
            throw e;
        }
    }

    public void doInitial(){
        try {
            connzk();
            //执行订阅command节点数据变化和servers节点的列表变化
        }catch (Exception e){
            log.error("zookeeper connect service error , will try again",e);
            ExecutorUtils.work(new ReConn());
        }
    }
    int getServerCount(String ip){
        int rt = 0;
        if(null != zkClient) {
            List<String> ls = zkClient.getChildren("/SERVERS");
            if (null != ls) {
                for (String s : ls) {
                    if (StringUtils.isNotBlank(s)) {
                        byte[] b = zkClient.readData("/SERVERS/"+s);
                        if(null != b) {
                            String c = new String(b);
                            if (StringUtils.isNotBlank(c)) {
                                Map m = StringUtils.convert2MapJSONObject(c);
                                if (null != m && null != m.get("ip") && m.get("ip").equals(ip)) {
                                    rt++;
                                }
                            }
                        }
                    }
                }
            }
        }
        return rt;
    }
    class ReConn implements Runnable{

        @Override
        public void run() {
            while(null == zkClient ) {
                try {
                    connzk();
                    notifyObjectByName("StatHandler",true, "init", null);
                    notifyObjectByName("LoadDefineActions",true,"reConZkInit",null);
                    notifyObjectByName("system",true,"init",null);
                } catch (Exception e) {

                }finally {
                    try {
                        Thread.sleep(30000);
                    }catch (Exception e){}
                }
            }
            log.info("runing zk reconn ...");
        }
    }
    void createParent(String p){
        int n = p.indexOf("/",1);
        while(n>0) {
            String t = p.substring(0, n);
            if(null != zkClient && !zkClient.exists(t)){
                zkClient.createPersistent(t);
            }
            n=p.indexOf("/",n+1);
        }
    }
    void createPath(String p){
        createParent(p);
        if(!zkClient.exists(p)){
            zkClient.createPersistent(p);
        }
    }
    void createParentAddListener(String p){
        try {
            int n = p.indexOf("/", 1);
            while (n > 0) {
                String t = p.substring(0, n);
                if (!zkClient.exists(t)) {
                    zkClient.createPersistent(t);
                    addChildrenPathListener(t);
                    log.info("create path listener "+t);
                }
                n = p.indexOf("/", n + 1);
                try {
                    Thread.sleep(500);
                }catch (Exception e){}
            }
        }catch (RuntimeException e){
            log.error("zk create path error ["+p+"]",e);
            throw e;
        }
    }
    public Object doSomeThing(String xmlid,XMLParameter env, Map input, Map output,Map config) throws Exception {
        String op = null;
        if(null != input) {
            op = (String) input.get("op");
        }
        log.info("zkClient op "+input);
        if("stop".equals(op)){
            if(null != zkClient){
                zkClient.close();
            }
        }
        try {
            if (null != input && null != zkClient && null != input && null != op && op.startsWith("publish")
                    && null != input.get("path") && null != input.get("data")) {
                String p = (String) input.get("path");
                createParentAddListener(p);
                if (!zkClient.exists(p)) {
                    zkClient.createPersistent(p);
                    addChildrenPathListener(p);
                    zkClient.subscribeDataChanges(p, new DataChangeListener());
                    Thread.sleep(500);
                }
                long l = System.currentTimeMillis();
                while (!zkClient.exists(p)) {
                    Thread.sleep(100);
                    if (System.currentTimeMillis() - l > 500) {
                        break;
                    }
                }
                if (zkClient.exists(p)) {
                    Boolean b = (Boolean) ClassUtils.invokeMethod(zkClient, "hasListeners", new Class[]{String.class}, new Object[]{p});
                    if (!b) {
                        zkClient.subscribeDataChanges(p, new DataChangeListener());
                        Thread.sleep(500);
                    }
                    if (((String) input.get("op")).contains("Delete")) {
                        zkClient.delete(p);
                    } else {
                        if(log.isInfoEnabled()) {
                            log.info("wirtedata " + ((String) input.get("data")));
                        }
                        zkClient.writeData(p, ((String) input.get("data")).getBytes(), -1);
                    }
                    return true;
                }
                return false;
            } else if ("delete".equals(op)) {
                String p = (String) input.get("path");
                if (StringUtils.isNotBlank(p) && zkClient.exists(p)) {
                    zkClient.delete(p);
                }
                return true;
            }else  if(null!= zkClient && "deleteChildren".equals(op)){
                String p = (String) input.get("path");
                List<String> ls = zkClient.getChildren(p);
                if(null != ls){
                    for(String s:ls){
                        zkClient.delete(p+"/"+s);
                    }
                }
            }else if (null != zkClient && null != input && "addChildrenDataListener".equals(op)) {
                String p = (String) input.get("path");
                if (!zkClient.exists(p)) {
                    createPath(p);
                }
                addChildrenDataListener(p);
                return true;

            } else if (null != zkClient && null != input && "addChildrenPathListener".equals(op)) {
                String p = (String) input.get("path");

                if (!zkClient.exists(p)) {
                    createPath(p);
                }
                addChildrenPathListener(p);
                return true;
            } else if (null != zkClient && null != input && "addPathDataListener".equals(op)) {
                String p = (String) input.get("path");

                if (!zkClient.exists(p)) {
                    createParent(p);
                    zkClient.createPersistent(p);

                }
                long l = System.currentTimeMillis();
                while (!zkClient.exists(p)) {
                    Thread.sleep(10);
                    if (System.currentTimeMillis() - l > 200) {
                        break;
                    }
                }
                zkClient.subscribeDataChanges(p, new DataChangeListener());
                log.info("append zk data listener " + p);
                return true;
            } else if (null != zkClient && null != input && "setData".equals(op)) {
                String p = (String) input.get("path");
                String data = (String) input.get("data");
                createParentAddListener(p);
                if (!zkClient.exists(p)) {
                    zkClient.createPersistent(p);
                }
                zkClient.writeData(p, data.getBytes(), -1);
                return true;
            } else if (null != zkClient && null != input && "onlySetData".equals(op)) {
                String p = (String) input.get("path");
                String data = (String) input.get("data");
                createParent(p);
                if (!zkClient.exists(p)) {
                    zkClient.createPersistent(p);
                }
                zkClient.writeData(p, data.getBytes(), -1);
                log.debug("onlySetData:" + p + "\n" + data);
                return true;
            }else if (null != zkClient && null != input && "onlyWriteData".equals(op)) {
                String p = (String) input.get("path");
                String data = (String) input.get("data");
                if(zkClient.exists(p)){
                    zkClient.writeData(p, data.getBytes(), -1);
                    log.debug("onlyWriteData:" + p + "\n" + data);
                    return true;
                }
            } else if (null != zkClient && null != input && "onlySetTempData".equals(op)) {
                String p = (String) input.get("path");
                String data = (String) input.get("data");
                createParent(p);
                if (!zkClient.exists(p)) {
                    zkClient.createEphemeral(p);
                }
                zkClient.writeData(p, data.getBytes(), -1);
                log.debug("onlySetTempData:" + p + "\n" + data);
                return true;
            } else if (null != zkClient && null != input && "getData".equals(op)) {
                String p = (String) input.get("path");
                if (zkClient.exists(p)) {
                    byte[] b = zkClient.readData(p);
                    if (null != b) {
                        return new String(b);
                    }
                }
                return null;
            } else if (null != zkClient && null != input && "getChildren".equals(op)) {
                String p = (String) input.get("path");
                if (zkClient.exists(p)) {
                    return zkClient.getChildren(p);
                }
                return null;
            } else if (null != zkClient && null != input && "isExist".equals(op)) {
                try {
                    String p = (String) input.get("path");
                    Object o = (zkClient.exists(p));
                    if (null != o && o instanceof Boolean && (Boolean) o) {
                        return Boolean.TRUE;
                    } else {
                        return Boolean.FALSE;
                    }
                }catch (Exception e){
                    return Boolean.FALSE;
                }
            } else if (null != zkClient && null != input && "addPathListener".equals(op)) {
                String p = (String) input.get("path");
                String type = (String) input.get("type");
                createParent(p);
                if (!zkClient.exists(p)) {
                    if (StringUtils.isNotBlank(type) && "temp".equals(type)) {
                        zkClient.createEphemeral(p);
                    } else {
                        zkClient.createPersistent(p);
                    }
                }
                addPathListener(p);
                return null;
            } else if (null != zkClient && null != input && "addPath".equals(op)) {
                String p = (String) input.get("path");
                String type = (String) input.get("type");
                createParent(p);
                if (!zkClient.exists(p)) {
                    if (StringUtils.isNotBlank(type) && "temp".equals(type)) {
                        zkClient.createEphemeral(p);
                    } else {
                        zkClient.createPersistent(p);
                    }
                }
                return null;
            } else if (null != zkClient && null != input && "getChildrenData".equals(op)) {
                HashMap m = new HashMap();
                String p = (String) input.get("path");
                if (zkClient.exists(p)) {
                    List<String> cl = zkClient.getChildren(p);
                    if (null != cl) {
                        for (String c : cl) {
                            if(zkClient.exists(p + "/" + c)) {
                                byte[] s = zkClient.readData(p + "/" + c);
                                if (null != s) {
                                    m.put(c, new String(s));
                                }
                            }
                        }
                    }
                }

                return m;
            } else if (null != env) {
                return super.doSomeThing(xmlid, env, input, output, config);
            } else {
                return null;
            }
        }catch (Exception e){
            log.error("zk client op error",e);
        }
        return null;
    }
}