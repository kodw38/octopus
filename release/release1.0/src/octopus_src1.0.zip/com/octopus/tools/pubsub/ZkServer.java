package com.octopus.tools.pubsub;

import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.thread.ExecutorUtils;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import java.io.PrintStream;
import java.util.LinkedList;
import java.util.Map;
import javax.management.JMException;
import org.I0Itec.zkclient.ZkClient;
import org.I0Itec.zkclient.exception.ZkNoNodeException;
import org.I0Itec.zkclient.exception.ZkNodeExistsException;
import org.I0Itec.zkclient.serialize.BytesPushThroughSerializer;
import org.apache.commons.logging.Log;
import org.apache.zookeeper.jmx.ManagedUtil;
import org.apache.zookeeper.server.ServerCnxnFactory;
import org.apache.zookeeper.server.ServerConfig;
import org.apache.zookeeper.server.ZooKeeperServerMain;

public class ZkServer extends XMLDoObject
{
  private static final String USAGE = "Usage: ZooKeeperServerMain configfile | port datadir [ticktime] [maxcnxns]";
  ZkClient zkClient;
  private ServerCnxnFactory cnxnFactory;

  public ZkServer(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    if ((null != input) && (input.containsKey("op")))
      if ("start".equals(input.get("op")))
        ExecutorUtils.work(this, "start", new Class[] { Map.class }, new Object[] { config });
      else if ("send".equals(input.get("op")))
        send(config, (String)input.get("path"), (String)input.get("data"));


    return null;
  }

  public void doInitial()
    throws Exception
  {
  }

  public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    return true;
  }

  public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return new ResultCheck(true, ret);
  }

  public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return false;
  }

  public boolean rollback(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret, Exception e) throws Exception
  {
    return false;
  }

  public void start(Map<String, String> properties) {
    ZooKeeperServerMain main = new ZooKeeperServerMain();
    try {
      try {
        ManagedUtil.registerLog4jMBeans();
      } catch (JMException e) {
        log.warn("Unable to register log4j JMX control", e);
      }

      ServerConfig config = new ServerConfig();
      LinkedList li = new LinkedList();
      li.add(properties.get("port"));
      li.add(properties.get("dataDir"));
      if (StringUtils.isNotBlank(properties.get("tickTime")))
        li.add(properties.get("tickTime"));
      if (StringUtils.isNotBlank(properties.get("maxClientCnxns")))
        li.add(properties.get("maxClientCnxns"));

      config.parse((String[])(String[])li.toArray(new String[0]));

      main.runFromConfig(config);
    }
    catch (IllegalArgumentException e)
    {
      log.error("Invalid arguments, exiting abnormally", e);
      log.info("Usage: ZooKeeperServerMain configfile | port datadir [ticktime] [maxcnxns]");
      System.err.println("Usage: ZooKeeperServerMain configfile | port datadir [ticktime] [maxcnxns]");
      System.exit(2);
    } catch (Exception e) {
      log.error("Unexpected exception, exiting abnormally", e);
      System.exit(1);
    }
    log.info("Exiting normally");
  }

  public void send(Map config, String path, String data)
  {
    String host = (String)config.get("host");
    String port = (String)config.get("port");
    if ((StringUtils.isNotBlank(host)) && (StringUtils.isNotBlank(port)))
      try
      {
        if (null == this.zkClient) {
          this.zkClient = new ZkClient(host + ":" + port, 50000, 50000, new BytesPushThroughSerializer());
        }

        this.zkClient.writeData(path, data.getBytes());
      } catch (ZkNoNodeException e) {
        try {
          this.zkClient.createPersistent(path, data.getBytes());
        }
        catch (ZkNodeExistsException xe) {
          this.zkClient.writeData(path, data.getBytes());
        }
      }
  }
}