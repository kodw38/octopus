package com.octopus.tools.statistic;

import com.octopus.utils.cls.proxy.IMethodAddition;
import java.util.List;

public class InvocationStatistic
  implements IMethodAddition
{
  public Object beforeAction(Object impl, String m, Object[] args)
    throws Exception
  {
    return null;
  }

  public Object afterAction(Object impl, String m, Object[] args, boolean isInvoke, boolean isSuccess, Throwable e, Object result)
  {
    return null;
  }

  public Object resultAction(Object impl, String m, Object[] args, Object result)
  {
    return null;
  }

  public int getLevel()
  {
    return 0;
  }

  public boolean isWaiteBefore()
  {
    return false;
  }

  public boolean isWaiteAfter()
  {
    return false;
  }

  public boolean isWaiteResult()
  {
    return false;
  }

  public boolean isNextInvoke()
  {
    return false;
  }

  public void setMethods(List<String> methods)
  {
  }

  public List<String> getMethods()
  {
    return null;
  }
}