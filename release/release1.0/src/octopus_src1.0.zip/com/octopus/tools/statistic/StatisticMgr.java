package com.octopus.tools.statistic;

public class StatisticMgr
{
}