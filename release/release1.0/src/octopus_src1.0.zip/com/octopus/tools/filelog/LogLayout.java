package com.octopus.tools.filelog;

import org.apache.log4j.PatternLayout;
import org.apache.log4j.spi.LoggingEvent;

public class LogLayout extends PatternLayout
{
  String header;

  public void setHeader(String header)
  {
    this.header = header; }

  public String getHeader() {
    return this.header;
  }

  public String format(LoggingEvent event) {
    String s;
    try {
      s = super.format(event);

      return s;
    } catch (Exception e) {
      e.printStackTrace();

      return null;
    }
  }
}