package com.octopus.tools.resource;

import java.util.Map;

public abstract interface IResource
{
  public abstract Object add(String paramString, Map[] paramArrayOfMap, Object paramObject)
    throws Exception;

  public abstract Object delete(String paramString, Map paramMap, Object paramObject)
    throws Exception;

  public abstract Object update(String paramString, Map paramMap1, Map paramMap2, Object paramObject)
    throws Exception;

  public abstract Object rollbackAdd(String paramString, Map[] paramArrayOfMap, Object paramObject)
    throws Exception;

  public abstract Object rollbackDelete(String paramString, Map paramMap, Object paramObject)
    throws Exception;

  public abstract Object rollbackUpdate(String paramString, Map paramMap1, Map paramMap2, Object paramObject)
    throws Exception;

  public abstract Object query(String paramString, Map paramMap, int paramInt1, int paramInt2, Object paramObject)
    throws Exception;

  public abstract Object getMetaData(String paramString, Map paramMap, Object paramObject)
    throws Exception;
}