package com.octopus.tools.resource;

public abstract interface IResourceFormate
{
}