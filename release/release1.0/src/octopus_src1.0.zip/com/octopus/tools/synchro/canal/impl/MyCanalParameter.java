package com.octopus.tools.synchro.canal.impl;

import com.alibaba.otter.canal.instance.manager.model.CanalParameter;
import java.util.HashMap;

public class MyCanalParameter extends CanalParameter
{
  HashMap addition;

  public MyCanalParameter()
  {
    this.addition = new HashMap(); }

  public void put(String k, Object o) {
    this.addition.put(k, o); }

  public Object get(String k) {
    return this.addition.get(k);
  }
}