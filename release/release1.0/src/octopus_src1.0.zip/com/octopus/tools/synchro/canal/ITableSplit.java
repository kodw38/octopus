package com.octopus.tools.synchro.canal;

import java.util.Map;

public abstract interface ITableSplit
{
  public abstract String split(String paramString);

  public abstract String split(String paramString, Map paramMap);
}