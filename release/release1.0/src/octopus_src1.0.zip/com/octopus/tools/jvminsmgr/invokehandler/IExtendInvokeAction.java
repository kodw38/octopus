package com.octopus.tools.jvminsmgr.invokehandler;

import com.octopus.utils.xml.XMLMakeup;

public abstract interface IExtendInvokeAction
{
  public abstract void setXml(XMLMakeup paramXMLMakeup);

  public abstract boolean isExecute(String paramString1, String paramString2, String paramString3);

  public abstract void doBeforeInvoke(Object paramObject, String paramString, Object[] paramArrayOfObject)
    throws Exception;

  public abstract void doAfterInvoke(Object paramObject1, String paramString, Object[] paramArrayOfObject, boolean paramBoolean, Throwable paramThrowable, Object paramObject2);

  public abstract Object doResult(Object paramObject);
}