package com.octopus.tools.jvminsmgr.ds;

public class WaitResults
{
  Object[] results;

  public Object[] getResults()
  {
    return this.results;
  }

  public void setResults(Object[] results) {
    this.results = results;
  }
}