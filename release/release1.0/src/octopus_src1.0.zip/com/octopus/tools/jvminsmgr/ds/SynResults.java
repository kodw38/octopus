package com.octopus.tools.jvminsmgr.ds;

public class SynResults
{
  Object[] results;

  public boolean waitAllFinished()
  {
    return true;
  }

  public Object[] getResults() {
    return this.results;
  }

  public void setResults(Object[] results) {
    this.results = results;
  }
}