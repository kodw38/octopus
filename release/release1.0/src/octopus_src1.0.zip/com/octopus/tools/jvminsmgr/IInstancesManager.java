package com.octopus.tools.jvminsmgr;

import com.octopus.tools.jvminsmgr.ds.SynResults;

public abstract interface IInstancesManager
{
  public abstract SynResults remoteSynInvokeAllInstances(String paramString, Object paramObject, Class[] paramArrayOfClass);
}