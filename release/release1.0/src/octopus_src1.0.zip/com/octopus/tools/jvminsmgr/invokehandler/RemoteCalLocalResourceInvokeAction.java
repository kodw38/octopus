package com.octopus.tools.jvminsmgr.invokehandler;

import com.octopus.tools.jvminsmgr.InstancesUtils;
import com.octopus.utils.alone.BooleanUtils;
import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.xml.XMLMakeup;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class RemoteCalLocalResourceInvokeAction
  implements IExtendInvokeAction
{
  List<String> ms = new ArrayList();
  Object ret = null;
  XMLMakeup xml;

  public RemoteCalLocalResourceInvokeAction()
  {
    String m = this.xml.getProperties().getProperty("targetmethods");
    if (StringUtils.isNotBlank(m)) {
      String[] ss = StringUtils.chomp(m).split(",");
      String[] arr$ = ss; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String s = arr$[i$];
        this.ms.add(s);
      }
    }
  }

  public void setXml(XMLMakeup xml) {
    this.xml = xml;
  }

  public boolean isExecute(String xmlid, String id, String mn)
  {
    if ((this.ms.size() > 0) && (((StringUtils.isNotBlank(xmlid)) || (StringUtils.isNotBlank(id))))) {
      if ((StringUtils.isNotBlank(xmlid)) && (this.ms.contains(xmlid + "#" + mn))) {
        return true;
      }

      return ((StringUtils.isNotBlank(id)) && (this.ms.contains(id + "#" + mn)));
    }

    return true;
  }

  public void doBeforeInvoke(Object impl, String m, Object[] args) throws Exception
  {
    this.ret = InstancesUtils.remoteWaitCalLocalResourceExtendInvoke(impl.getClass().getSuperclass().getName(), m, args, null);
    if (BooleanUtils.isTrue(this.ret))
      throw new SuccessfulException();
  }

  public void doAfterInvoke(Object impl, String m, Object[] args, boolean isSuccess, Throwable e, Object result)
  {
  }

  public Object doResult(Object result)
  {
    if (null != this.ret) return this.ret;
    return result;
  }
}