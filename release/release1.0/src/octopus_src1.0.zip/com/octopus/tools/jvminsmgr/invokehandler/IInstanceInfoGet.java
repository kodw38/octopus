package com.octopus.tools.jvminsmgr.invokehandler;

public abstract interface IInstanceInfoGet
{
}