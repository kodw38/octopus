package com.octopus.tools.jvminsmgr.invokehandler;

import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.cls.proxy.IMethodAddition;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class ExtendInstanceInvokeHandler extends XMLObject
  implements IMethodAddition
{
  List<Class> actions = new ArrayList();
  XMLMakeup[] as;

  public ExtendInstanceInvokeHandler(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
    this.as = getXML().getChild("action");
    if (null != this.as) {
      XMLMakeup[] arr$ = this.as; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { XMLMakeup a = arr$[i$];
        if (StringUtils.isNotBlank(a.getProperties().getProperty("path")))
          try {
            this.actions.add(Class.forName(a.getProperties().getProperty("path")));
          } catch (ClassNotFoundException e) {
            e.printStackTrace();
          }
      }
    }
  }

  public void notifyObject(String op, Object obj)
    throws Exception
  {
  }

  public void destroy()
    throws Exception
  {
  }

  public void initial()
    throws Exception
  {
  }

  public Object beforeAction(Object impl, String m, Object[] args)
    throws Exception
  {
    if (null != this.actions) {
      for (int i = 0; i < this.actions.size(); ) {
        try {
          IExtendInvokeAction an = (IExtendInvokeAction)((Class)this.actions.get(i)).newInstance();
          an.setXml(this.as[i]);
          if (an.isExecute(((XMLObject)impl).getXML().getProperties().getProperty("xmlid"), ((XMLObject)impl).getXML().getProperties().getProperty("id"), m))
            an.doBeforeInvoke(impl, m, args);
        }
        catch (Exception e) {
          e.printStackTrace();
        }
        ++i;
      }

    }

    return null;
  }

  public Object afterAction(Object impl, String m, Object[] args, boolean isInvoke, boolean isSuccess, Throwable e, Object result)
  {
    if (null != this.actions) {
      for (int i = 0; i < this.actions.size(); ) {
        try {
          IExtendInvokeAction an = (IExtendInvokeAction)((Class)this.actions.get(i)).newInstance();
          an.setXml(this.as[i]);
          if (an.isExecute(((XMLObject)impl).getXML().getProperties().getProperty("xmlid"), ((XMLObject)impl).getXML().getProperties().getProperty("id"), m))
            an.doAfterInvoke(impl, m, args, isSuccess, e, result);
        }
        catch (Exception ex) {
          ex.printStackTrace();
        }
        ++i;
      }

    }

    return null;
  }

  public int getLevel()
  {
    return 0;
  }

  public boolean isWaiteBefore()
  {
    return false;
  }

  public boolean isWaiteAfter()
  {
    return false;
  }

  public boolean isWaiteResult()
  {
    return false;
  }

  public boolean isNextInvoke()
  {
    return false;
  }

  public void setMethods(List<String> methods)
  {
  }

  public List<String> getMethods()
  {
    return null;
  }

  public Object resultAction(Object impl, String m, Object[] args, Object result)
  {
    if (null != this.actions) {
      for (int i = 0; i < this.actions.size(); ) {
        try {
          IExtendInvokeAction an = (IExtendInvokeAction)((Class)this.actions.get(i)).newInstance();
          an.setXml(this.as[i]);
          if (an.isExecute(((XMLObject)impl).getXML().getProperties().getProperty("xmlid"), ((XMLObject)impl).getXML().getProperties().getProperty("id"), m))
            result = an.doResult(result);
        }
        catch (Exception e) {
          e.printStackTrace();
        }
        ++i;
      }

      return result;
    }
    return result;
  }
}