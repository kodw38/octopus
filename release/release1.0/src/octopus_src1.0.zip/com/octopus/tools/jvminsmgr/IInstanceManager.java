package com.octopus.tools.jvminsmgr;

import com.octopus.tools.jvminsmgr.ds.InstanceInfo;
import com.octopus.tools.jvminsmgr.ds.InstanceUsedInfo;

public abstract interface IInstanceManager
{
  public abstract void start();

  public abstract void monitor();

  public abstract boolean extendInstance(InstanceInfo paramInstanceInfo);

  public abstract boolean reBack(InstanceInfo paramInstanceInfo);

  public abstract void logUsed(InstanceUsedInfo paramInstanceUsedInfo);

  public abstract boolean addInstanceInfo(String paramString1, String paramString2, InstanceInfo paramInstanceInfo);

  public abstract InstanceInfo[] router(String paramString1, String paramString2, Object[] paramArrayOfObject);

  public abstract InstanceUsedInfo[] getUsedInstanceInfo(String paramString1, String paramString2, Object[] paramArrayOfObject);

  public abstract Object invokeInstance(InstanceInfo paramInstanceInfo, String paramString1, String paramString2, Object[] paramArrayOfObject);
}