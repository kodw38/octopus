package com.octopus.tools.jvminsmgr.invokehandler;

import com.octopus.tools.jvminsmgr.InstancesUtils;
import com.octopus.tools.jvminsmgr.ds.SynResults;
import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.xml.XMLMakeup;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class MargeResultInvokeAction
  implements IExtendInvokeAction
{
  SynResults results;
  XMLMakeup xml;
  List<String> ms = new ArrayList();

  public MargeResultInvokeAction()
  {
    String m = this.xml.getProperties().getProperty("targetmethods");
    if (StringUtils.isNotBlank(m)) {
      String[] ss = StringUtils.chomp(m).split(",");
      String[] arr$ = ss; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String s = arr$[i$];
        this.ms.add(s);
      }
    }
  }

  public void setXml(XMLMakeup xml) {
    this.xml = xml;
  }

  public boolean isExecute(String xmlid, String id, String mn)
  {
    if ((this.ms.size() > 0) && (((StringUtils.isNotBlank(xmlid)) || (StringUtils.isNotBlank(id))))) {
      if ((StringUtils.isNotBlank(xmlid)) && (this.ms.contains(xmlid + "#" + mn))) {
        return true;
      }

      return ((StringUtils.isNotBlank(id)) && (this.ms.contains(id + "#" + mn)));
    }

    return true;
  }

  public void doBeforeInvoke(Object impl, String m, Object[] args) throws Exception
  {
    this.results = InstancesUtils.remoteSynInvokeAllInstances(impl.getClass().getSuperclass().getName(), m, args, null);
  }

  public void doAfterInvoke(Object impl, String m, Object[] args, boolean isSuccess, Throwable e, Object result)
  {
    this.results.waitAllFinished();
  }

  public Object doResult(Object result)
  {
    if (null != this.results) {
      Object ret = null;
      Object[] arr$ = this.results.getResults(); int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { Object c = arr$[i$];
        if ((null != c) && (c.getClass().equals(result.getClass()))) {
          if (result.getClass().isArray()) {
            if (null == ret)
              ret = result;

            int ol = Array.getLength(ret);
            int nl = Array.getLength(c);
            Object temp = Array.newInstance(result.getClass(), ol + nl);
            System.arraycopy(ret, 0, temp, 0, ol);
            System.arraycopy(c, 0, temp, ol - 1, nl);
            ret = temp;
          }
          if ((List.class.isAssignableFrom(result.getClass())) && (c.getClass().equals(result.getClass()))) {
            if (null == ret)
              ret = result;

            ((List)ret).addAll((List)c);
          }
          if ((Map.class.isAssignableFrom(result.getClass())) && (c.getClass().equals(result.getClass()))) {
            if (null == ret)
              ret = result;

            ((Map)ret).putAll((Map)c);
          }
        }
      }
      return ret;
    }
    return result;
  }
}