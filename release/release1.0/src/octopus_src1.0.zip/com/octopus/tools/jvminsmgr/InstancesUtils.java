package com.octopus.tools.jvminsmgr;

import com.octopus.tools.jvminsmgr.ds.SynResults;
import com.octopus.tools.jvminsmgr.ds.WaitResults;

public class InstancesUtils
{
  public static SynResults remoteSynInvokeAllInstances(String className, String methodName, Object parameters, Class[] parametersClass)
  {
    return null;
  }

  public static WaitResults remoteWaitInvokeAllInstances(String className, String methodName, Object parameters, Class[] parametersClass)
  {
    return null;
  }

  public static Object remoteWaitCalLocalResourceExtendInvoke(String className, String methodName, Object parameters, Class[] parametersClass)
  {
    return null;
  }

  public static String getCurrentInstance() {
    return "";
  }

  public static WaitResults remoteWaitInvokeInstances(String instance, String className, String methodName, Object parameters, Class[] parametersClass) {
    return null;
  }
}