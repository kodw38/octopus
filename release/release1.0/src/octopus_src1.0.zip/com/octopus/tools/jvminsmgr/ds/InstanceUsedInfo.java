package com.octopus.tools.jvminsmgr.ds;

public class InstanceUsedInfo
{
}