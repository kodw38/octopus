package com.octopus.tools.jvminsmgr.invokehandler;

public class SuccessfulException extends Exception
{
}