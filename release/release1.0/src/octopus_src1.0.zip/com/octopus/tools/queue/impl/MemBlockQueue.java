package com.octopus.tools.queue.impl;

import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;

public class MemBlockQueue extends XMLDoObject
{
  ArrayBlockingQueue queue = new ArrayBlockingQueue(1000);

  public MemBlockQueue(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void doInitial()
    throws Exception
  {
  }

  public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config)
    throws Exception
  {
    return true;
  }

  public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    if (null != input) {
      String op = (String)input.get("op");
      if (("add".equalsIgnoreCase(op)) && (null != input.get("data")))
        this.queue.put(input.get("data"));

      if ("get".equals(op)) {
        Object ret = this.queue.take();
        return ret;
      }
    }
    return null;
  }

  public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return new ResultCheck(true, ret);
  }

  public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return false;
  }

  public boolean rollback(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret, Exception e) throws Exception
  {
    return false;
  }
}