package com.octopus.tools.queue;

public abstract interface IQueue
{
  public abstract void put(Object paramObject)
    throws InterruptedException;

  public abstract void setThreadNum(int paramInt);

  public abstract void setQueueMax(int paramInt);

  public abstract Object take();

  public abstract void start();

  public abstract void suspend();

  public abstract void active();
}