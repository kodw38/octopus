package com.octopus.tools.i18n;

import java.util.Properties;

public abstract interface II18N
{
  public abstract Object getLocaleValue(String paramString, Properties paramProperties, Object paramObject);

  public abstract Object getLocaleValue(String paramString, Properties paramProperties);

  public abstract Object getSystemValue(String paramString, Properties paramProperties, Object paramObject);
}