package com.octopus.tools.i18n;

import java.util.Properties;

public abstract interface ITransport
{
  public abstract Object transport(Object paramObject, Properties paramProperties);

  public abstract Object transport2System(Object paramObject, Properties paramProperties);
}