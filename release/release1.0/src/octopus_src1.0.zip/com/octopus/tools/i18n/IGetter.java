package com.octopus.tools.i18n;

import java.util.Properties;

public abstract interface IGetter
{
  public abstract Object get(Properties paramProperties);
}