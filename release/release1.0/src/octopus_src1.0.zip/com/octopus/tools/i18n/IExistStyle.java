package com.octopus.tools.i18n;

public abstract interface IExistStyle
{
  public abstract Object export(Object paramObject);
}