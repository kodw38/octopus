package com.octopus.tools.i18n.impl.calendar;

public class CalendarDateTime
{
}