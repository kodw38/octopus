package com.octopus.tools.i18n;

import java.util.Properties;

public abstract interface ICache
{
  public abstract Object get(Properties paramProperties);

  public abstract void add(Object paramObject, Properties paramProperties);

  public abstract Object getAll();
}