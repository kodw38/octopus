package com.octopus.tools.i18n;

import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import java.io.PrintStream;
import java.util.Properties;

public class TestTrans extends XMLObject
  implements ITransport
{
  public TestTrans(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void notifyObject(String op, Object obj)
    throws Exception
  {
  }

  public void destroy()
    throws Exception
  {
  }

  public void initial()
    throws Exception
  {
  }

  public Object transport(Object o, Properties locale)
  {
    System.out.println(o);
    return "2014-08-18 00:00:00";
  }

  public Object transport2System(Object o, Properties locale)
  {
    return null;
  }
}