package com.octopus.tools.i18n;

import java.util.Properties;

public abstract interface II18NItem
{
  public abstract String getType();

  public abstract boolean matchLocaleString(String paramString);

  public abstract Object getLocaleValue(Object paramObject, Properties paramProperties);

  public abstract Object getLocaleValue(Properties paramProperties);

  public abstract Object getSystemValue(Object paramObject, Properties paramProperties);

  public abstract Object exportAll();
}