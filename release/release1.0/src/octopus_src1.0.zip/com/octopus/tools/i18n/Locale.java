package com.octopus.tools.i18n;

import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import java.util.Properties;

public class Locale extends XMLObject
{
  public Locale(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void notifyObject(String op, Object obj)
    throws Exception
  {
  }

  public void destroy()
    throws Exception
  {
  }

  public void initial()
    throws Exception
  {
  }

  public String getLocaleString(Properties properties)
  {
    String s = getXML().getProperties().getProperty("locale");
    String[] ks = s.split("\\.");
    StringBuffer sb = new StringBuffer();
    boolean first = true;
    String[] arr$ = ks; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String k = arr$[i$];
      if (StringUtils.isNotBlank(properties.getProperty(k)))
        if (!(first)) {
          sb.append(".").append(properties.getProperty(k));
        } else {
          sb.append(properties.getProperty(k));
          first = false;
        }
    }

    return sb.toString();
  }
}