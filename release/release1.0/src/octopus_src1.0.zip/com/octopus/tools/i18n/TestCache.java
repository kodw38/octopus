package com.octopus.tools.i18n;

import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class TestCache extends XMLObject
  implements ICache
{
  List li = new ArrayList();

  public TestCache(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void notifyObject(String op, Object obj)
    throws Exception
  {
  }

  public void destroy()
    throws Exception
  {
  }

  public void initial()
    throws Exception
  {
  }

  public Object get(Properties locale)
  {
    if (this.li.size() > 0)
      return this.li.get(0);
    return null;
  }

  public void add(Object o, Properties locale)
  {
    this.li.add(o);
  }

  public Object getAll()
  {
    return this.li;
  }
}