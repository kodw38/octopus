package com.octopus.tools.i18n;

public abstract interface IFormat
{
  public abstract Object formate(Object paramObject);

  public abstract Object formate2System(Object paramObject);
}