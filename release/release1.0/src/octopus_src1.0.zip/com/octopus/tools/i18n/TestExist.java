package com.octopus.tools.i18n;

import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import java.io.PrintStream;

public class TestExist extends XMLObject
  implements IExistStyle
{
  public TestExist(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void notifyObject(String op, Object obj)
    throws Exception
  {
  }

  public void destroy()
    throws Exception
  {
  }

  public void initial()
    throws Exception
  {
  }

  public Object export(Object all)
  {
    System.out.println(all);
    return null;
  }
}