package com.octopus.tools.deploy;

import com.octopus.tools.deploy.property.ExcelPropertiesGetter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class PropertiesMgr
{
  Map<String, List<Properties>> commands = new HashMap();

  public PropertiesMgr(String configExcel)
  {
    ExcelPropertiesGetter getter = new ExcelPropertiesGetter();
    this.commands = getter.getCommandProperties(configExcel);
  }

  public Map<String, List<Properties>> getCommands()
  {
    return this.commands;
  }

  public List<Properties> getCommandPropertyList(String commandName) {
    return ((List)this.commands.get(commandName));
  }
}