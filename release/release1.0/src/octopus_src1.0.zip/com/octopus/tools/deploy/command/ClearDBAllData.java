package com.octopus.tools.deploy.command;

import com.octopus.tools.deploy.CommandMgr;
import com.octopus.tools.deploy.ICommand;
import java.util.Properties;

public class ClearDBAllData
  implements ICommand
{
  public String exeCommand(CommandMgr commandMgr, Properties properties)
  {
    return null;
  }
}