package com.octopus.tools.deploy;

import java.util.Properties;

public abstract interface ICommand
{
  public abstract String exeCommand(CommandMgr paramCommandMgr, Properties paramProperties)
    throws Exception;
}