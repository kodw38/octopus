package com.octopus.tools.deploy;

import java.util.List;
import java.util.Map;
import java.util.Properties;

public abstract interface IPropertiesGetter
{
  public abstract Map<String, List<Properties>> getCommandProperties(String paramString);
}