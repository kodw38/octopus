package com.octopus.tools.deploy;

import com.octopus.tools.deploy.command.CopyCommand;
import com.octopus.tools.deploy.command.ExeRemoteCommand;
import com.octopus.tools.deploy.command.InitializeDBData;
import com.octopus.utils.alone.StringUtils;
import java.io.File;
import java.util.HashMap;

public class CommandMgr
{
  HashMap<String, ICommand> cmdMap = new HashMap();
  HashMap<String, String> ccMap = new HashMap();

  public CommandMgr(String configExcel, String scriptPath)
  {
    this.cmdMap.put("copy", new CopyCommand(configExcel));
    this.cmdMap.put("loadSqlFiles", new InitializeDBData());
    this.cmdMap.put("exeCmd", new ExeRemoteCommand());
    if (StringUtils.isNotBlank(scriptPath)) {
      File f = new File(scriptPath);
      String[] ss = f.list();
      if (null != ss) {
        String[] arr$ = ss; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String mi = arr$[i$];
          this.ccMap.put(mi.substring(mi.lastIndexOf("/") + 1, mi.lastIndexOf(".")), f.getPath().replaceAll("\\\\", "/") + "/" + mi); } }
    }
  }

  public ICommand getCommand(String commandName) {
    return ((ICommand)this.cmdMap.get(commandName));
  }

  public String getCommandContent(String comandName) {
    return ((String)this.ccMap.get(comandName));
  }
}