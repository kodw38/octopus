package com.octopus.tools.deploy;

import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.thread.ExecutorUtils;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import java.io.OutputStream;
import java.util.Map;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang.exception.ExceptionUtils;

public class AutoDeploy extends XMLDoObject
{
  Deploy deploy = new Deploy();
  CommandMgr commandMgr = null;
  PropertiesMgr propertiesMgr = null;

  public AutoDeploy(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    String command = (String)input.get("command");
    String range = (String)input.get("range");
    String param = (String)input.get("pars");
    String configExcel = (String)input.get("config");
    String script = (String)input.get("script");
    String op = (String)input.get("op");
    Object remote = env.getParameter("websocket-remote");
    if (StringUtils.isBlank(configExcel))
      configExcel = (String)config.get("config");

    if (StringUtils.isBlank(script)) {
      script = (String)config.get("script");
    }

    if (null != remote)
      ExecutorUtils.synWork(remote, "sendText", new Class[] { String.class }, new Object[] { "begin execute command [" + command + "] range [" + range + "]" });

    if (null == this.commandMgr)
      this.commandMgr = new CommandMgr(configExcel, script);

    if (null == this.propertiesMgr)
      this.propertiesMgr = new PropertiesMgr(configExcel);

    if ("getAllOps".equals(op))
      return this.propertiesMgr.getCommands();

    OutputStream out = null;
    if ((null != input) && (null != input.get("log")) && ("out".equals(input.get("log"))) && (null != env.getParameter("${response}")))
      out = ((HttpServletResponse)env.getParameter("${response}")).getOutputStream();
    try
    {
      String sb = this.deploy.executeScript(this.propertiesMgr, this.commandMgr, command, range, param, out, remote);
      if (null != sb)
        return sb;
    }
    catch (Exception e) {
      if (null != remote) {
        ExecutorUtils.synWork(remote, "sendText", new Class[] { String.class }, new Object[] { "execute command [" + command + "] error:" });
        String[] ss = ExceptionUtils.getRootCauseStackTrace(e);
        String[] arr$ = ss; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String s = arr$[i$];
          ExecutorUtils.synWork(remote, "sendText", new Class[] { String.class }, new Object[] { s });
        }
      } else {
        throw e;
      }
    }
    if (null != remote) {
      ExecutorUtils.synWork(remote, "sendText", new Class[] { String.class }, new Object[] { "finished execute command [" + command + "] range [" + range + "]" });
    }

    return "finished it";
  }

  public void doInitial()
    throws Exception
  {
  }

  public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config)
    throws Exception
  {
    return true;
  }

  public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return new ResultCheck(true, ret);
  }

  public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return false;
  }

  public boolean rollback(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret, Exception e) throws Exception
  {
    return false;
  }
}