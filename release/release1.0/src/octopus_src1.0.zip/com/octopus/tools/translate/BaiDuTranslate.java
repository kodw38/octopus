package com.octopus.tools.translate;

public class BaiDuTranslate
{
  private static final String APP_ID = "20180601000170645";
  private static final String SECURITY_KEY = "L9ZSNGxcI3BVLEif8Iny";

  public static String translate(String v, String language)
  {
    TransApi api = new TransApi("20180601000170645", "L9ZSNGxcI3BVLEif8Iny");
    return api.getTransResult(v, "auto", language); }

  public static String translate(String v, String old, String language) {
    TransApi api = new TransApi("20180601000170645", "L9ZSNGxcI3BVLEif8Iny");
    return api.getTransResult(v, old, language);
  }
}