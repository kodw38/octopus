package com.octopus.tools.utils;

import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class DataCollection extends XMLDoObject
{
  public DataCollection(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void doInitial()
    throws Exception
  {
  }

  public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    return true;
  }

  public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    if (null != input) {
      List datas = (List)input.get("datas");
      String parentField = (String)input.get("parentField");
      String parentTitle = (String)input.get("parentTitle");
      String childField = (String)input.get("childField");
      String childTitle = (String)input.get("childTitle");
      if ((null != datas) && (StringUtils.isNotBlank(parentField))) {
        Map ret = new LinkedHashMap();
        if (StringUtils.isNotBlank(parentField))
          for (Iterator i$ = datas.iterator(); i$.hasNext(); ) { Map m = (Map)i$.next();
            Object o = m.get(parentField);
            if (ret.containsKey(o)) {
              ((List)ret.get(o)).add(m);
            } else {
              ret.put(o, new LinkedList());
              ((List)ret.get(o)).add(m);
            }
          }

        return ret;
      }
    }
    return null;
  }

  public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return new ResultCheck(true, ret);
  }

  public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return false;
  }

  public boolean rollback(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret, Exception e) throws Exception
  {
    return false;
  }
}