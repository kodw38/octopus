package com.octopus.tools.utils;

import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.img.IImgIdent;
import com.octopus.utils.img.impl.BackgroundValidateCode;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;
import javax.imageio.ImageIO;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ImgIdentTool extends XMLDoObject
{
  static transient Log log = LogFactory.getLog(ImgIdentTool.class);
  Map<String, IImgIdent> imgIdents = new HashMap();

  public ImgIdentTool(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);

    this.imgIdents.put("background", new BackgroundValidateCode());
  }

  public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map cfg)
    throws Exception
  {
    Object o = input.get("verifyImage");
    if (o instanceof InputStream) {
      InputStream in = (InputStream)o;
      if (null != input) {
        BufferedImage img = ImageIO.read(in);

        String s = ((IImgIdent)this.imgIdents.get(input.get("verifyType"))).getValidatecode(img, ((Integer)input.get("len")).intValue(), (String)input.get("tempdir"));
        if (StringUtils.isNotBlank(s))
          return s;

      }

    }
    else if (log.isDebugEnabled()) {
      System.out.println(o);
    }

    return null;
  }

  public void doInitial()
    throws Exception
  {
  }

  public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map cfg)
    throws Exception
  {
    return ((null != input) && (null != input.get("verifyImage")) && (((InputStream)input.get("verifyImage")).available() > 0) && (null != input) && (null != input.get("verifyType")) && (null != input.get("len")));
  }

  public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map cfg, Object ret)
    throws Exception
  {
    if (log.isDebugEnabled())
      System.out.println("    img ident:" + ret);

    return new ResultCheck(true, ret);
  }

  public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return false;
  }

  public boolean rollback(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret, Exception e) throws Exception
  {
    throw new Exception("now support rollback");
  }
}