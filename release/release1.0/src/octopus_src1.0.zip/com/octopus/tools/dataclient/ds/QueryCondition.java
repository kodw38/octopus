package com.octopus.tools.dataclient.ds;

import com.octopus.tools.dataclient.ds.field.FieldDef;
import com.octopus.tools.dataclient.ds.store.FieldCondition;
import java.util.ArrayList;
import java.util.Iterator;

public class QueryCondition
{
  ArrayList<FieldCondition> queryCondition;
  ArrayList<FieldDef> queryFields;
  ArrayList<FieldDef> orderFields;

  public FieldDef[] getOrderFields()
  {
    if (null != this.orderFields)
      return ((FieldDef[])this.orderFields.toArray(new FieldDef[this.orderFields.size()]));
    return null;
  }

  public void setOrderFields(ArrayList<FieldDef> orderFields) {
    if (this.orderFields == null) this.orderFields = new ArrayList();
    if (null != orderFields)
      for (Iterator i$ = orderFields.iterator(); i$.hasNext(); ) { FieldDef c = (FieldDef)i$.next();
        this.orderFields.add(c); }
  }

  public void addOrderField(FieldDef fd) {
    if (null == this.orderFields) this.orderFields = new ArrayList();
    if (null != fd)
      this.orderFields.add(fd);
  }

  public FieldCondition[] getFieldCondition() {
    if ((null != this.queryCondition) && (this.queryCondition.size() > 0))
      return ((FieldCondition[])this.queryCondition.toArray(new FieldCondition[this.queryCondition.size()]));
    return null;
  }

  public void setFieldCondition(FieldCondition[] queryCondition) {
    if (this.queryCondition == null) this.queryCondition = new ArrayList();
    if (null != queryCondition) {
      FieldCondition[] arr$ = queryCondition; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { FieldCondition c = arr$[i$];
        this.queryCondition.add(c); } }
  }

  public void addFieldCondition(FieldCondition condition) {
    if (null == this.queryCondition) this.queryCondition = new ArrayList();
    if (null != condition)
      this.queryCondition.add(condition);
  }

  public FieldDef[] getQueryField() {
    return ((FieldDef[])this.queryFields.toArray(new FieldDef[this.queryFields.size()]));
  }

  public void setQueryField(FieldDef[] queryField) {
    if (this.queryFields == null) this.queryFields = new ArrayList();
    if (null != queryField) {
      FieldDef[] arr$ = queryField; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { FieldDef f = arr$[i$];
        this.queryFields.add(f); }
    }
  }

  public void addQueryField(FieldDef fd) {
    if (null == this.queryFields) this.queryFields = new ArrayList();
    this.queryFields.add(fd);
  }
}