package com.octopus.tools.dataclient.impl.engines;

public abstract interface ITyper
{
  public abstract Object typer(Object paramObject);
}