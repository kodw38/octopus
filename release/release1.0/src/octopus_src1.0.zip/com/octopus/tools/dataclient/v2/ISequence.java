package com.octopus.tools.dataclient.v2;

public abstract interface ISequence
{
  public abstract long getNextSequence(String paramString)
    throws Exception;
}