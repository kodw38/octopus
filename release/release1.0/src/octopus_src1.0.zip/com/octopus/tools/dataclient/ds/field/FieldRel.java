package com.octopus.tools.dataclient.ds.field;

public class FieldRel
{
  public static final int REL_TYPE_NOTNULL = 1;
  public static final int REL_TYPE_NULL = 2;
  private FieldDef relField;
  private int relType;

  public FieldRel(FieldDef relField, int type)
  {
    this.relField = relField;
    this.relType = type;
  }

  public FieldDef getRelField() {
    return this.relField;
  }

  public void setRelField(FieldDef relField) {
    this.relField = relField;
  }

  public int getRelType() {
    return this.relType;
  }

  public void setRelType(int relType) {
    this.relType = relType;
  }
}