package com.octopus.tools.dataclient;

public abstract interface IDataRouter
{
  public abstract IDataEngine[] getRouter(String paramString, Object paramObject);
}