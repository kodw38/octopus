package com.octopus.tools.dataclient.impl;

import com.octopus.tools.dataclient.IDataEngine;
import com.octopus.tools.dataclient.IDataRouter;
import com.octopus.tools.dataclient.IDictionary;
import com.octopus.tools.dataclient.ds.field.FieldContainer;
import com.octopus.tools.dataclient.ds.field.FieldDef;
import com.octopus.tools.dataclient.ds.field.TableDef;
import com.octopus.tools.dataclient.ds.field.TableDefContainer;
import com.octopus.tools.dataclient.ds.store.TableValue;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class Dictionary extends XMLObject
  implements IDictionary
{
  static transient Log log = LogFactory.getLog(Dictionary.class);

  public Dictionary(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);

    IDataRouter router = (IDataRouter)getPropertyObject("router");
    String dc = xml.getProperties().getProperty("datasource");
    IDataEngine[] engine = router.getRouter(dc, null);
    if (null == engine) throw new Exception("not find dataEngine by dataSource=" + dc);
    TableValue fv = engine[0].queryByTableName(xml.getChild("fields")[0].getText(), null);
    FieldDef[] fs = fv.getTableDef().getFieldDefs();
    List fds = fv.getRecordValues();
    if (null != fds)
      for (Iterator i$ = fds.iterator(); i$.hasNext(); ) { Object[] ds = (Object[])i$.next();
        FieldDef f = new FieldDef();
        int isadd = 0;
        for (int i = 0; i < fs.length; ++i) {
          if (fs[i].getFieldCode().equalsIgnoreCase("FIELD_NAME"))
            f.setFieldName(String.valueOf(ds[i]));
          if (fs[i].getFieldCode().equalsIgnoreCase("FIELD_CODE"))
            f.setFieldCode(String.valueOf(ds[i]));
          if (fs[i].getFieldCode().equalsIgnoreCase("FIELD_TYPE"))
            f.setFieldType((String)ds[i]);
          if (fs[i].getFieldCode().equalsIgnoreCase("STATE"))
            isadd = ((Integer)ds[i]).intValue();
        }
        if (isadd > 0)
          FieldContainer.addFieldDef(f);
      }


    TableValue tv = engine[0].queryByTableName(xml.getChild("tables")[0].getText(), null);
    FieldDef[] ts = tv.getTableDef().getFieldDefs();
    List tds = tv.getRecordValues();
    Map tables = new HashMap();
    if (null != tds)
      for (Iterator i$ = tds.iterator(); i$.hasNext(); ) { Object[] ds = (Object[])i$.next();
        int isadd = 0;
        String datasource = null; String datapath = null; String fieldcode = null;
        for (int i = 0; i < ts.length; ++i)
        {
          if (ts[i].getFieldCode().equalsIgnoreCase("TABLE_NAME"))
            datapath = String.valueOf(ds[i]);
          if (ts[i].getFieldCode().equalsIgnoreCase("FIELD_CODE"))
            fieldcode = (String)ds[i];
          if (ts[i].getFieldCode().equalsIgnoreCase("STATE"))
            isadd = ((Integer)ds[i]).intValue();
        }
        if (isadd > 0) {
          if (!(tables.containsKey(datasource + "^" + datapath))) tables.put(datasource + "^" + datapath, new LinkedList());
          FieldDef fdd = FieldContainer.getField(fieldcode);
          if (null != fdd)
            ((List)tables.get(datasource + "^" + datapath)).add(fdd);
          else
            log.error("not find fielddef[" + fieldcode + "].");
        }
      }


    if (tables.size() > 0) {
      Iterator its = tables.keySet().iterator();
      while (its.hasNext()) {
        String k = (String)its.next();
        String[] dn = k.split("\\^");
        TableDef td = new TableDef();
        td.setDataSource(dn[0]);
        td.setName(dn[1]);
        td.setFieldDefs((FieldDef[])((List)tables.get(k)).toArray(new FieldDef[0]));
        TableDefContainer.addTableDef(td);
      }
    }
  }

  public void notifyObject(String op, Object obj)
    throws Exception
  {
  }

  public void destroy()
    throws Exception
  {
  }

  public void initial()
    throws Exception
  {
  }

  public FieldDef[] getFieldDef(String likeFieldName)
  {
    return new FieldDef[0];
  }
}