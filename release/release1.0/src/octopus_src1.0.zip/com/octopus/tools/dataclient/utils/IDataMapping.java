package com.octopus.tools.dataclient.utils;

import java.util.List;
import java.util.Map;

public abstract interface IDataMapping
{
  public abstract List<Map> mapping(Object paramObject)
    throws Exception;
}