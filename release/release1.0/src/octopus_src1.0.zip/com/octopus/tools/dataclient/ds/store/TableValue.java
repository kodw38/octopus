package com.octopus.tools.dataclient.ds.store;

import com.octopus.tools.dataclient.ds.field.FieldDef;
import com.octopus.tools.dataclient.ds.field.TableDef;
import java.io.Serializable;
import java.util.List;

public class TableValue
  implements Serializable
{
  private Long cacheMaxPk;
  private Long cacheMinPk;
  private Long resultMaxPk;
  private Long resultMinPk;
  private List recordValues;
  private TableDef tableDef;
  private FieldCondition[] queryCondition;
  public static final char SPLIT_CHAR_DBTABLE = 6;
  public static final char SPLIT_CHAR_FIELDS = 7;

  public TableDef getTableDef()
  {
    return this.tableDef;
  }

  public void setTableDef(TableDef tableDef)
  {
    this.tableDef = tableDef;
  }

  public Long getCacheMaxPk() {
    return this.cacheMaxPk;
  }

  public void setCacheMaxPk(Long cacheMaxPk) {
    this.cacheMaxPk = cacheMaxPk;
  }

  public Long getCacheMinPk() {
    return this.cacheMinPk;
  }

  public void setCacheMinPk(Long cacheMinPk) {
    this.cacheMinPk = cacheMinPk;
  }

  public Long getResultMaxPk() {
    return this.resultMaxPk;
  }

  public void setResultMaxPk(Long resultMaxPk) {
    this.resultMaxPk = resultMaxPk;
  }

  public Long getResultMinPk() {
    return this.resultMinPk;
  }

  public void setResultMinPk(Long resultMinPk) {
    this.resultMinPk = resultMinPk;
  }

  public List<Object[]> getRecordValues()
  {
    return this.recordValues;
  }

  public void setRecordValues(List recordValues) {
    this.recordValues = recordValues;
  }

  public FieldCondition[] getQueryCondition() {
    return this.queryCondition;
  }

  public void setQueryCondition(FieldCondition[] queryCondition) {
    this.queryCondition = queryCondition;
  }

  public void merge(TableValue tv) {
    getRecordValues().addAll(tv.getRecordValues());
  }

  public StringBuffer toStringBuffer() {
    StringBuffer sb = new StringBuffer();
    for (int i = 0; i < this.recordValues.size(); ++i) {
      if (i == 0)
      {
        sb.append(this.tableDef.getDataSource() + '\6' + this.tableDef.getName() + "\n");

        for (int k = 0; k < this.tableDef.getFieldDefs().length; ++k)
          if (k == 0)
            sb.append(this.tableDef.getFieldDefs()[k].getFieldCode());
          else
            sb.append('\7' + this.tableDef.getFieldDefs()[k].getFieldCode());


        sb.append("\n");
      }

      Object[] oneRecord = (Object[])(Object[])this.recordValues.get(i);
      for (int k = 0; k < oneRecord.length; ++k)
        if (k == 0)
          sb.append(oneRecord[k].toString());
        else
          sb.append("," + oneRecord[k].toString());


      sb.append("\n");
    }
    return sb;
  }
}