package com.octopus.tools.dataclient;

import com.octopus.tools.dataclient.impl.trans.AbstractTransactionTask;

public abstract interface ITransaction
{
  public abstract boolean work(AbstractTransactionTask[] paramArrayOfAbstractTransactionTask, int paramInt);

  public abstract boolean receive(String paramString1, String paramString2, boolean paramBoolean);

  public abstract String generatorTransactionId(int paramInt);
}