package com.octopus.tools.dataclient.impl.trans;

import com.octopus.tools.jvminsmgr.InstancesUtils;
import com.octopus.tools.jvminsmgr.ds.WaitResults;
import com.octopus.utils.alone.BooleanUtils;
import java.io.Serializable;
import java.util.concurrent.locks.ReentrantLock;

public abstract class AbstractTransactionTask
  implements Serializable
{
  String tranId;
  String seqNo;
  String srcInstance;
  final ReentrantLock lock = new ReentrantLock();

  public void setTransactionId(String id)
  {
    this.tranId = id;
    this.srcInstance = id.substring(0, id.indexOf("_")); }

  public void setTaskSeqNo(String seqNo) {
    this.seqNo = seqNo;
  }

  boolean feedBack(boolean b)
  {
    WaitResults wr = InstancesUtils.remoteWaitInvokeInstances(this.srcInstance, Transaction.class.getName(), "receive", new Object[] { this.tranId, this.seqNo, Boolean.valueOf(b) }, null);

    return ((null != wr) && (null != wr.getResults()) && (BooleanUtils.isTrue(wr.getResults()[0])));
  }

  void doTask()
    throws Exception
  {
    try
    {
      this.lock.lock();
      task();
      boolean b = feedBack(true);
      if (!(b)) {
        doRollback();
        throw new Exception("feedback error in task. transactionId[" + this.tranId + "]");
      }
    } catch (Exception e) {
    }
    finally {
      this.lock.unlock(); } }

  Object doCommit() throws Exception {
    try {
      try {
        this.lock.lock();
        Object localObject1 = doCommit();

        boolean b = feedBack(true);
        if (!(b)) {
          doRollback();
          throw new Exception("feedback error in task. transactionId[" + this.tranId + "]");
        }
        this.lock.unlock();
        return localObject1;
      }
      catch (Exception e)
      {
        throw e; }
    } finally {
      boolean b = feedBack(true);
      if (!(b)) {
        doRollback();
        throw new Exception("feedback error in task. transactionId[" + this.tranId + "]");
      }
      this.lock.unlock(); } }

  boolean doRollback() throws Exception {
    try {
      try {
        this.lock.lock();
        boolean bool = rollback();

        this.lock.unlock(); return bool;
      }
      catch (Exception e)
      {
        throw e; }
    } finally {
      this.lock.unlock();
    }
  }

  public abstract void task()
    throws Exception;

  public abstract Object commit()
    throws Exception;

  public abstract boolean rollback()
    throws Exception;
}