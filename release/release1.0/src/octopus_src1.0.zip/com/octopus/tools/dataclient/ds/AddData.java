package com.octopus.tools.dataclient.ds;

import java.util.Map;
import net.sf.json.JSONArray;

public class AddData
{
  String opCode;
  Map[] data;

  public AddData(String opCode, Map[] data)
  {
    this.opCode = opCode;
    this.data = data;
  }

  public String getOpCode() {
    return this.opCode;
  }

  public void setOpCode(String opCode) {
    this.opCode = opCode;
  }

  public Map[] getData() {
    return this.data;
  }

  public void setData(Map[] data) {
    this.data = data;
  }

  public String toString() {
    StringBuffer sb = new StringBuffer();
    sb.append("opCode:" + this.opCode).append(",").append("datas:").append(JSONArray.fromObject(this.data).toString());
    return sb.toString();
  }
}