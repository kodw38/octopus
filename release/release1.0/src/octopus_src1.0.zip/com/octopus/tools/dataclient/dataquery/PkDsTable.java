package com.octopus.tools.dataclient.dataquery;

import java.util.List;

public class PkDsTable
{
  String ds;
  String tableName;
  List pkv;

  public String getDs()
  {
    return this.ds;
  }

  public void setDs(String ds) {
    this.ds = ds;
  }

  public String getTableName() {
    return this.tableName;
  }

  public void setTableName(String tableName) {
    this.tableName = tableName;
  }

  public List getPkv() {
    return this.pkv;
  }

  public void setPkv(List pkv) {
    this.pkv = pkv;
  }
}