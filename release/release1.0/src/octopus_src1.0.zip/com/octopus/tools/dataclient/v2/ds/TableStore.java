package com.octopus.tools.dataclient.v2.ds;

import com.octopus.utils.ds.TableBean;

public class TableStore extends TableBean
{
  String dataSource;
  String suffixRule;
  String storeExpress;

  public String getDataSource()
  {
    return this.dataSource;
  }

  public void setDataSource(String dataSource) {
    this.dataSource = dataSource;
  }

  public String getSuffixRule() {
    return this.suffixRule;
  }

  public void setSuffixRule(String suffixRule) {
    this.suffixRule = suffixRule;
  }

  public String getStoreExpress() {
    return this.storeExpress;
  }

  public void setStoreExpress(String storeExpress) {
    this.storeExpress = storeExpress;
  }
}