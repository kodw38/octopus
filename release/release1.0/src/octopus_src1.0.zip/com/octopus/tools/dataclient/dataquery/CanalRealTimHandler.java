package com.octopus.tools.dataclient.dataquery;

import com.octopus.tools.dataclient.dataquery.redis.RedisClient;
import com.octopus.tools.synchro.canal.AbstractMessageHandler;
import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLParameter;
import java.util.Map;
import java.util.Properties;
import redis.clients.jedis.Jedis;

public class CanalRealTimHandler extends AbstractMessageHandler
{
  AngleConfig config = null;
  String rediskey;
  RedisClient rc;

  public CanalRealTimHandler(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);

    this.rediskey = ((String)StringUtils.convert2MapJSONObject(xml.getProperties().getProperty("config")).get("redis"));
    this.rc = ((RedisClient)getObjectById("RedisClient"));

    this.config = ((AngleConfig)getPropertyObject("config"));
  }

  Jedis getRedis() throws Exception
  {
    return this.rc.getRedis(this.rediskey);
  }

  public void doRecord(XMLParameter env, String type, String tableCode, Map oldData, Map newData) throws Exception
  {
    Jedis jedis;
    tableCode = tableCode.substring(tableCode.lastIndexOf(".") + 1);
    if (type.equals("INSERT")) {
      jedis = getRedis();
      try {
        AngleLoader.appendData(this.config, jedis, tableCode, newData, null, null);
      } finally {
        jedis.close();
      }
    } else if (type.equals("DELETE"))
    {
      jedis = getRedis();
      try {
        AngleLoader.deleteData(this.config, jedis, tableCode, oldData);
      } finally {
        jedis.close();
      }
    } else if (type.equals("UPDATE"))
    {
      jedis = getRedis();
      try {
        AngleLoader.updateData(this.config, jedis, tableCode, oldData, newData, null, null);
      } finally {
        jedis.close();
      }
    }
  }

  public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config)
    throws Exception
  {
    return null;
  }

  public void doInitial()
    throws Exception
  {
  }

  public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    return false;
  }

  public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return null;
  }

  public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return false;
  }

  public boolean rollback(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret, Exception e) throws Exception
  {
    return false;
  }
}