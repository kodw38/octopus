package com.octopus.tools.dataclient.ds.field;

import java.io.Serializable;

public class TableDef
  implements Serializable
{
  String dataSource;
  String name;
  FieldDef[] fieldDefs;
  FieldDef[] mustFields;

  public String getDataSource()
  {
    return this.dataSource;
  }

  public void setDataSource(String dataSource) {
    this.dataSource = dataSource;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public FieldDef[] getFieldDefs() {
    return this.fieldDefs;
  }

  public void setFieldDefs(FieldDef[] fieldDefs) {
    this.fieldDefs = fieldDefs;
  }

  public FieldDef[] getMustFields() {
    return this.mustFields;
  }

  public void setMustFields(FieldDef[] mustFields) {
    this.mustFields = mustFields;
  }
}