package com.octopus.tools.dataclient.v2;

import com.octopus.utils.ds.Condition;
import com.octopus.utils.ds.TableBean;
import com.octopus.utils.xml.auto.XMLParameter;
import java.util.List;
import java.util.Map;

public abstract interface IDataSource
{
  public abstract List<Map<String, Object>> query(String paramString, String[] paramArrayOfString, List<Condition> paramList, Map<String, String> paramMap, int paramInt1, int paramInt2, TableBean paramTableBean)
    throws Exception;

  public abstract int getCount(String paramString, String[] paramArrayOfString, List<Condition> paramList, TableBean paramTableBean)
    throws Exception;

  public abstract List<Map<String, String>> queryAsString(String paramString, String[] paramArrayOfString, List<Condition> paramList, Map<String, String> paramMap, int paramInt1, int paramInt2, TableBean paramTableBean)
    throws Exception;

  public abstract List<Map<String, Object>> query(String paramString, Map paramMap, int paramInt1, int paramInt2)
    throws Exception;

  public abstract boolean addRecord(XMLParameter paramXMLParameter, String paramString1, String paramString2, String paramString3, Map<String, Object> paramMap)
    throws Exception;

  public abstract boolean addRecords(XMLParameter paramXMLParameter, String paramString1, String paramString2, String paramString3, List<Map<String, Object>> paramList)
    throws Exception;

  public abstract boolean insertRecord(XMLParameter paramXMLParameter, String paramString1, String paramString2, String paramString3, Map<String, Object> paramMap, int paramInt)
    throws Exception;

  public abstract boolean insertRecords(XMLParameter paramXMLParameter, String paramString1, String paramString2, String paramString3, List<Map<String, Object>> paramList, int paramInt)
    throws Exception;

  public abstract boolean delete(XMLParameter paramXMLParameter, String paramString1, String paramString2, String paramString3, List<Condition> paramList, TableBean paramTableBean)
    throws Exception;

  public abstract boolean update(XMLParameter paramXMLParameter, String paramString1, String paramString2, String paramString3, List<Condition> paramList, Map<String, Object> paramMap, TableBean paramTableBean)
    throws Exception;

  public abstract IDataSource getDataSource(String paramString);

  public abstract boolean exist(String paramString)
    throws Exception;

  public abstract long getNextSequence(String paramString)
    throws Exception;
}