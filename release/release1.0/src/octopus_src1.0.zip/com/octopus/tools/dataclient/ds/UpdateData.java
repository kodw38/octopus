package com.octopus.tools.dataclient.ds;

import com.octopus.tools.dataclient.ds.store.FieldCondition;
import com.octopus.tools.dataclient.ds.store.FieldValue;

public class UpdateData
{
  FieldCondition[] conditions;
  FieldValue[] fieldValues;

  public FieldCondition[] getConditions()
  {
    return this.conditions;
  }

  public void setConditions(FieldCondition[] conditions) {
    this.conditions = conditions;
  }

  public FieldValue[] getFieldValues() {
    return this.fieldValues;
  }

  public void setFieldValues(FieldValue[] fieldValues) {
    this.fieldValues = fieldValues;
  }
}