package com.octopus.tools.dataclient;

import com.octopus.tools.dataclient.ds.AddData;
import com.octopus.tools.dataclient.ds.DelCnd;
import com.octopus.tools.dataclient.ds.MetaCnd;
import com.octopus.tools.dataclient.ds.QueryCondition;
import com.octopus.tools.dataclient.ds.UpdateData;
import com.octopus.tools.dataclient.ds.store.DataOperatorContainer;
import com.octopus.tools.dataclient.ds.store.TableValue;

public abstract interface IDataClient
{
  public abstract boolean store(DataOperatorContainer paramDataOperatorContainer, Object paramObject)
    throws Exception;

  public abstract TableValue query(QueryCondition paramQueryCondition, Object paramObject)
    throws Exception;

  public abstract boolean add(AddData paramAddData)
    throws Exception;

  public abstract boolean delete(DelCnd paramDelCnd, Object paramObject)
    throws Exception;

  public abstract boolean update(UpdateData paramUpdateData)
    throws Exception;

  public abstract Object query(QueryCondition paramQueryCondition)
    throws Exception;

  public abstract Object getMetaData(MetaCnd paramMetaCnd)
    throws Exception;

  public abstract Object getMetaDataBatch(MetaCnd[] paramArrayOfMetaCnd)
    throws Exception;

  public abstract boolean addBatch(AddData[] paramArrayOfAddData)
    throws Exception;

  public abstract boolean deleteBatch(DelCnd[] paramArrayOfDelCnd)
    throws Exception;

  public abstract boolean updateBatch(UpdateData[] paramArrayOfUpdateData)
    throws Exception;

  public abstract Object queryBatch(QueryCondition[] paramArrayOfQueryCondition)
    throws Exception;
}