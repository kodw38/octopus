package com.octopus.tools.dataclient.v2.ds;

import java.util.List;
import java.util.Map;

public class RouteResultBean
{
  String dataSource;
  String tableName;
  String originalTableName;
  String op;
  List<String> queryFields;
  List<String> keyfields;
  List<Map> structure;
  Object datas;
  Object conds;
  Map format;
  int start;
  int end;
  Boolean isForceDB;
  Map fieldsMapping;
  List<String> sqls;

  public List<Map> getStructure()
  {
    return this.structure;
  }

  public void setStructure(List<Map> structure) {
    this.structure = structure;
  }

  public Map getFieldsMapping() {
    return this.fieldsMapping;
  }

  public void setFieldsMapping(Map fieldsMapping) {
    this.fieldsMapping = fieldsMapping;
  }

  public Boolean isForceDB() {
    return this.isForceDB;
  }

  public void setForceDB(Boolean isForceDB) {
    this.isForceDB = isForceDB;
  }

  public List<String> getKeyfields()
  {
    return this.keyfields;
  }

  public String getOriginalTableName() {
    return this.originalTableName;
  }

  public void setOriginalTableName(String originalTableName) {
    this.originalTableName = originalTableName;
  }

  public void setKeyfields(List<String> keyfields) {
    this.keyfields = keyfields;
  }

  public List<String> getSqls() {
    return this.sqls;
  }

  public void setSqls(List<String> sqls) {
    this.sqls = sqls;
  }

  public String getOp() {
    return this.op;
  }

  public int getStart() {
    return this.start;
  }

  public void setStart(int start) {
    this.start = start;
  }

  public int getEnd() {
    return this.end;
  }

  public void setEnd(int end) {
    this.end = end;
  }

  public void setOp(String op) {
    this.op = op;
  }

  public String getDataSource() {
    return this.dataSource;
  }

  public Map getFormat() {
    return this.format;
  }

  public void setFormat(Map format) {
    this.format = format;
  }

  public void setDataSource(String dataSource) {
    this.dataSource = dataSource;
  }

  public String getTableName() {
    return this.tableName;
  }

  public void setTableName(String tableName) {
    this.tableName = tableName;
  }

  public List<String> getQueryFields() {
    return this.queryFields;
  }

  public void setQueryFields(List<String> queryFields) {
    this.queryFields = queryFields;
  }

  public Object getDatas() {
    return this.datas;
  }

  public void setDatas(Object datas) {
    this.datas = datas;
  }

  public Object getConds() {
    return this.conds;
  }

  public void setConds(Object conds) {
    this.conds = conds;
  }
}