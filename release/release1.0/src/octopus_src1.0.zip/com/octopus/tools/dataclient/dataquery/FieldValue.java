package com.octopus.tools.dataclient.dataquery;

public class FieldValue
{
  String field;
  String[] values;

  public String getField()
  {
    return this.field;
  }

  public void setField(String field) {
    this.field = field;
  }

  public String[] getValues() {
    return this.values;
  }

  public void setValues(String[] values) {
    this.values = values;
  }
}