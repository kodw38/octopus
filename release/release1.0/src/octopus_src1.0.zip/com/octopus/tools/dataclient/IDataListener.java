package com.octopus.tools.dataclient;

public abstract interface IDataListener
{
}