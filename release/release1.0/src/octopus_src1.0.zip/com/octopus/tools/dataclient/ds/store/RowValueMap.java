package com.octopus.tools.dataclient.ds.store;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

public class RowValueMap
{
  private TreeMap valueMap = new TreeMap();
  private TreeMap rowIdMap = new TreeMap();

  public void put(FieldValue value)
  {
    if (null == value.getRowId())
      throw new IllegalArgumentException(" parameter RecordValue'RowId can't is null.");

    if (null == value.getValue())
      throw new IllegalArgumentException(" parameter RecordValue'Value can't is null.");

    if (this.valueMap.containsKey(value.getValue())) {
      ((List)this.valueMap.get(value.getValue())).add(value);
    } else {
      List li = new ArrayList();
      li.add(value);
      this.valueMap.put(value.getValue(), li);
    }
    if (this.rowIdMap.containsKey(value.getRowId()))
      throw new IllegalArgumentException(" row index:" + value.getRowId() + " data has exist.");

    this.rowIdMap.put(value.getRowId(), value);
  }

  void update(FieldValue old, FieldValue nnew)
  {
    if (null == old.getRowId())
      throw new IllegalArgumentException("updateing old RecordValue'RowId can't is null.");

    if (null == old.getValue())
      throw new IllegalArgumentException("updateing old RecordValue'Value can't is null.");

    if (null == nnew.getRowId())
      throw new IllegalArgumentException("updateing new RecordValue'RowId can't is null.");

    if (null == nnew.getValue()) {
      throw new IllegalArgumentException("updateing new RecordValue'Value can't is null.");
    }

    if (old.getRowId() == nnew.getRowId()) {
      this.rowIdMap.put(old.getRowId(), nnew);
      ((List)this.valueMap.get(old.getValue())).remove(old);
      ((List)this.valueMap.get(old.getValue())).add(nnew);
    } else {
      remove(old);
      put(nnew);
    }
  }

  void remove(FieldValue value) {
    if (null != value.getValue())
      ((List)this.valueMap.get(value.getValue())).remove(value);

    if (null == value.getRowId())
      this.rowIdMap.remove(value.getRowId());
  }

  public FieldValue getRecordValueByRowID(Long rowId)
  {
    return ((FieldValue)this.rowIdMap.get(rowId));
  }

  public List getRecordValueByInRow(Long[] rowids) {
    List li = new ArrayList();
    if (null != rowids)
    {
      for (int i = 0; i < rowids.length; ++i) {
        FieldValue value = (FieldValue)this.rowIdMap.get(rowids[i]);
        if (null != value) li.add(value);
      }
    }
    return li;
  }

  public Long getMaxRow() {
    return ((Long)this.rowIdMap.lastKey());
  }

  public Long getMinRow() {
    return ((Long)this.rowIdMap.firstKey());
  }

  public Object getMaxValue() {
    return this.valueMap.lastKey();
  }

  public Object getMinValue() {
    return this.valueMap.firstKey();
  }

  public int getSize() {
    return this.rowIdMap.size();
  }

  public List getRecordValueListByValue(Object value) {
    return ((List)this.valueMap.get(value));
  }

  public List getRecordValueListByInValue(Object[] values) {
    List ret = new ArrayList();

    if (null != values)
      for (int i = 0; i < values.length; ++i) {
        List tem = (List)this.valueMap.get(values[i]);
        if (null != tem)
          ret.addAll(tem);
      }


    return ret;
  }

  public List getRecordValueByBetweenValue(Object after, Object before) {
    SortedMap subMap = this.valueMap.subMap(after, before);
    List list = new ArrayList();
    Iterator cs = subMap.values().iterator();

    while (cs.hasNext()) {
      List tem = (List)cs.next();
      list.addAll(tem);
    }
    return list;
  }

  public List getRecordValueByBetweenRow(Long after, Long before) {
    SortedMap subMap = this.rowIdMap.subMap(after, before);
    List list = new ArrayList();
    list.addAll(subMap.values());
    return list;
  }

  public List getRecordValueByRowEqualMore(Long rowid) {
    Long max = getMaxRow();
    SortedMap subMap = this.rowIdMap.subMap(rowid, max);
    subMap.put(max, getRecordValueByRowID(max));
    List list = new ArrayList();
    list.addAll(subMap.values());
    return list; }

  public List getRecordValueByRowMore(Long rowid) {
    Long max = getMaxRow();
    SortedMap subMap = this.rowIdMap.subMap(rowid, max);
    subMap.remove(rowid);
    subMap.put(max, getRecordValueByRowID(max));
    List list = new ArrayList();
    list.addAll(subMap.values());
    return list;
  }

  public List getRecordValueByRowEqualLess(Long rowid) {
    Long min = getMinRow();
    SortedMap subMap = this.rowIdMap.subMap(min, rowid);
    subMap.put(rowid, getRecordValueByRowID(rowid));
    List list = new ArrayList();
    list.addAll(subMap.values());
    return list;
  }

  public List getRecordValueByRowLess(Long rowid) {
    Long min = getMinRow();
    SortedMap subMap = this.rowIdMap.subMap(min, rowid);
    List list = new ArrayList();
    list.addAll(subMap.values());
    return list;
  }

  public List getRecordValueByValueEqualMore(Object value) {
    Object max = getMaxValue();
    SortedMap subMap = this.rowIdMap.subMap(value, max);
    subMap.put(max, getRecordValueListByValue(max));
    List list = new ArrayList();
    Iterator cs = subMap.values().iterator();

    while (cs.hasNext()) {
      List tem = (List)cs.next();
      list.addAll(tem);
    }
    return list; }

  public List getRecordValueByValueMore(Object value) {
    Object max = getMaxValue();
    SortedMap subMap = this.rowIdMap.subMap(value, max);
    subMap.remove(value);
    subMap.put(max, getRecordValueListByValue(max));
    List list = new ArrayList();
    Iterator cs = subMap.values().iterator();

    while (cs.hasNext()) {
      List tem = (List)cs.next();
      list.addAll(tem);
    }
    return list;
  }

  public List getRecordValueByValueEqualLess(Object value) {
    Object min = getMinValue();
    SortedMap subMap = this.valueMap.subMap(min, value);
    subMap.put(value, getRecordValueListByValue(value));
    List list = new ArrayList();
    Iterator cs = subMap.values().iterator();

    while (cs.hasNext()) {
      List tem = (List)cs.next();
      list.addAll(tem);
    }
    return list;
  }

  public List getRecordValueByValueLess(Object value) {
    List list = new ArrayList();
    Object min = getMinValue();
    SortedMap subMap = this.valueMap.subMap(min, value);
    Iterator cs = subMap.values().iterator();

    while (cs.hasNext()) {
      List tem = (List)cs.next();
      list.addAll(tem);
    }
    return list;
  }

  public List getRecordValueListByLikeValue(Object value) {
    List list = new ArrayList();
    Iterator it = this.valueMap.keySet().iterator();
    while (it.hasNext()) {
      Object o = it.next();
      if (o.toString().indexOf(value.toString()) >= 0)
        list.addAll((List)this.valueMap.get(o));
    }

    return list;
  }

  TreeMap getValueMap()
  {
    return this.valueMap;
  }

  TreeMap getRowIdMap() {
    return this.rowIdMap;
  }
}