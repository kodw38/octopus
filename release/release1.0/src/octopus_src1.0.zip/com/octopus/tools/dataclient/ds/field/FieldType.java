package com.octopus.tools.dataclient.ds.field;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FieldType
{
  public static final String FIELD_TYPE_LONG = "L";
  public static final String FIELD_TYPE_INT = "I";
  public static final String FIELD_TYPE_DOUBLE = "F";
  public static final String FIELD_TYPE_STRING = "S";
  public static final String FIELD_TYPE_INPUTSTREAM = "M";
  public static final String FIELD_TYPE_DATE = "D";
  public static final String FIELD_TYPE_BOOLEAN = "B";
  private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd 24hh:MM:ss");

  public static String convertFrom(int type)
  {
    if (2004 == type)
      return "M";

    if (1 == type)
      return "S";

    if (91 == type)
      return "D";

    if (8 == type)
      return "F";

    if (6 == type)
      return "F";

    if (4 == type)
      return "L";

    if (-1 == type)
      return "S";

    if (7 == type)
      return "F";

    if (92 == type)
      return "D";

    if (93 == type)
      return "D";

    if (12 == type)
      return "S";

    if (2 == type)
      return "L";

    if (4 == type)
      return "I";

    throw new UnsupportedOperationException("unsupport db type " + type);
  }

  public static Class getTypeClass(String type)
  {
    if (type == "L")
      return Long.class;

    if (type == "F")
      return Double.class;

    if (type == "S")
      return String.class;

    if (type == "M")
      return InputStream.class;

    if (type == "D")
      return Date.class;

    if (type == "I")
      return Integer.class;

    return null;
  }

  public static Object convertTypeObject(String o, String type) throws Exception {
    o = o.replaceAll("\\'", "");
    if ("L" == type)
      return new Long(o);

    if ("F" == type)
      return new Double(o);

    if ("S" == type)
      return o.trim();

    if ("M" == type)
      return o.trim();

    if ("D" == type)
      return dateFormat.parse(o);

    if ("I" == type)
      return Integer.valueOf(Integer.parseInt(o));

    throw new UnsupportedOperationException("no suppert data type:" + type + "[LONG = 1,DOUBLE = 2,STRING = 3,INPUTSTREAM = 4,DATE = 5]");
  }
}