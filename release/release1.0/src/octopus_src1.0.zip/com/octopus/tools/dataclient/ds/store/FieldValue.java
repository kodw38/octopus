package com.octopus.tools.dataclient.ds.store;

import com.octopus.tools.dataclient.ds.field.FieldDef;

public class FieldValue
{
  FieldDef fieldDef;
  private Object value;
  private Long rowId;

  public void setValue(Object value)
  {
    this.value = value;
  }

  public FieldDef getFieldDef() {
    return this.fieldDef;
  }

  public void setFieldDef(FieldDef fieldDef) {
    this.fieldDef = fieldDef;
  }

  public FieldValue(Object value, Long rowid) {
    this.value = value;
    this.rowId = rowid;
  }

  public Object getValue() {
    return this.value;
  }

  public Long getRowId() {
    return this.rowId;
  }
}