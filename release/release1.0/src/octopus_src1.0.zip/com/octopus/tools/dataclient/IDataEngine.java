package com.octopus.tools.dataclient;

import com.octopus.tools.dataclient.ds.DelCnd;
import com.octopus.tools.dataclient.ds.QueryCondition;
import com.octopus.tools.dataclient.ds.UpdateData;
import com.octopus.tools.dataclient.ds.store.TableValue;
import java.util.Map;

public abstract interface IDataEngine
{
  public abstract boolean add(TableValue[] paramArrayOfTableValue, Object paramObject)
    throws Exception;

  public abstract TableValue query(QueryCondition paramQueryCondition, Object paramObject)
    throws Exception;

  public abstract TableValue queryByTableName(String paramString, Object paramObject)
    throws Exception;

  public abstract boolean update(UpdateData paramUpdateData)
    throws Exception;

  public abstract Object add(String paramString, Map[] paramArrayOfMap, Object paramObject)
    throws Exception;

  public abstract Object delete(DelCnd paramDelCnd, Object paramObject)
    throws Exception;

  public abstract Object update(String paramString, Map paramMap1, Map paramMap2, Object paramObject)
    throws Exception;

  public abstract Object rollbackAdd(String paramString, Map[] paramArrayOfMap, Object paramObject)
    throws Exception;

  public abstract Object rollbackDelete(String paramString, Map paramMap, Object paramObject)
    throws Exception;

  public abstract Object rollbackUpdate(String paramString, Map paramMap1, Map paramMap2, Object paramObject)
    throws Exception;

  public abstract Object query(String paramString, Map paramMap, int paramInt1, int paramInt2, Object paramObject)
    throws Exception;

  public abstract Object getMetaData(String paramString, Map paramMap, Object paramObject)
    throws Exception;
}