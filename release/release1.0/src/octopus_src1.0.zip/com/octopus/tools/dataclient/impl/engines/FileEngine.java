package com.octopus.tools.dataclient.impl.engines;

import com.octopus.tools.dataclient.IDataEngine;
import com.octopus.tools.dataclient.ds.DelCnd;
import com.octopus.tools.dataclient.ds.QueryCondition;
import com.octopus.tools.dataclient.ds.UpdateData;
import com.octopus.tools.dataclient.ds.store.TableValue;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import java.util.Map;

public class FileEngine extends XMLObject
  implements IDataEngine
{
  IDCS dcs;
  ITyper typer;

  public FileEngine(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void notifyObject(String op, Object obj)
    throws Exception
  {
  }

  public void destroy()
    throws Exception
  {
  }

  public void initial()
    throws Exception
  {
  }

  public Object add(String opId, Map[] data, Object env) throws Exception
  {
    return null;
  }

  public Object delete(DelCnd delData, Object env) throws Exception
  {
    return null;
  }

  public boolean add(TableValue[] tableValues, Object env) throws Exception
  {
    return false;
  }

  public TableValue query(QueryCondition cnd, Object env) throws Exception
  {
    return null;
  }

  public TableValue queryByTableName(String tableName, Object env) throws Exception
  {
    return null;
  }

  public boolean update(UpdateData updateData) throws Exception
  {
    return false;
  }

  public Object update(String opId, Map cnd, Map data, Object env) throws Exception
  {
    return null;
  }

  public Object rollbackAdd(String opId, Map[] data, Object env) throws Exception
  {
    return null;
  }

  public Object rollbackDelete(String opId, Map cnd, Object env) throws Exception
  {
    return null;
  }

  public Object rollbackUpdate(String opId, Map cnd, Map data, Object env) throws Exception
  {
    return null;
  }

  public Object query(String opId, Map cnd, int startIndex, int endIndex, Object env) throws Exception
  {
    return null;
  }

  public Object getMetaData(String opId, Map cnd, Object env) throws Exception
  {
    return null;
  }
}