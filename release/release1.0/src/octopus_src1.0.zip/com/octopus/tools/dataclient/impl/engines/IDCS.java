package com.octopus.tools.dataclient.impl.engines;

public abstract interface IDCS
{
  public abstract DC getDC(String paramString);
}