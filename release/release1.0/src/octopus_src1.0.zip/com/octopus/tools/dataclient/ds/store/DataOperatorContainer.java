package com.octopus.tools.dataclient.ds.store;

import com.octopus.tools.dataclient.ds.DelCnd;
import com.octopus.tools.dataclient.ds.UpdateData;
import com.octopus.tools.dataclient.ds.field.FieldContainer;
import com.octopus.tools.dataclient.ds.field.FieldDef;
import com.octopus.utils.alone.ArrayUtils;
import com.octopus.utils.xml.auto.XMLParameter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class DataOperatorContainer
{
  HashMap<FieldDef, List> addDataMap;
  List<TableValue> addTableList;
  List<UpdateData> updateDataMap;
  List<DelCnd> deleteDataList;

  public DataOperatorContainer()
  {
    this.addDataMap = new HashMap();
    this.addTableList = new ArrayList();

    this.updateDataMap = new ArrayList();

    this.deleteDataList = new ArrayList(); }

  public void addTablesValue(TableValue[] tvs) {
    if (ArrayUtils.isNotEmpty(tvs)) {
      TableValue[] arr$ = tvs; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { TableValue tv = arr$[i$];
        this.addTableList.add(tv);
      }
    }
  }

  public boolean isEmpty() {
    return ((this.addDataMap.size() == 0) && (this.addTableList.size() == 0) && (this.updateDataMap.size() == 0) && (this.deleteDataList.size() == 0));
  }

  public List<TableValue> getAddTableList()
  {
    return this.addTableList;
  }

  public void setAddTableList(List<TableValue> addTableList) {
    this.addTableList = addTableList;
  }

  public void addData(FieldDef field, Object value) {
    if (!(this.addDataMap.containsKey(field)))
      this.addDataMap.put(field, new ArrayList());

    if ((!(value instanceof String)) || (!(XMLParameter.isHasRetainChars((String)value))))
      ((List)this.addDataMap.get(field)).add(value);
  }

  public void addData(Map jsonObject) throws Exception {
    Iterator ks = jsonObject.keySet().iterator();
    while (ks.hasNext()) {
      String n = (String)ks.next();
      FieldDef f = FieldContainer.getField(n);
      if (null != f)
        if (f.getFieldType() == "B")
          addData(f, Boolean.valueOf((String)jsonObject.get(n)));
        else if (f.getFieldType() == "F")
          if ((null != jsonObject.get(n)) && (jsonObject.get(n) instanceof Double))
            addData(f, (Double)jsonObject.get(n));
          else if ((null != jsonObject.get(n)) && (jsonObject.get(n) instanceof String))
            addData(f, Double.valueOf((String)jsonObject.get(n)));
          else
            addData(f, null);
        else if (f.getFieldType() == "L")
          addData(f, Long.valueOf((String)jsonObject.get(n)));
        else if (f.getFieldType() == "S")
          addData(f, (String)jsonObject.get(n));
        else if (f.getFieldType() == "I")
          addData(f, Integer.valueOf((String)jsonObject.get(n)));
        else if (f.getFieldType() == "D") {
          if (jsonObject.get(n) instanceof Long)
            addData(f, new Date(((Long)jsonObject.get(n)).longValue()));
          else if (jsonObject.get(n) instanceof Date)
            addData(f, jsonObject.get(n));
          else if (jsonObject.get(n) instanceof String)
            addData(f, jsonObject.get(n));

        }
        else
          throw new Exception("not support the data type[" + f.getFieldType() + "]");
    }
  }

  public void updateData(FieldCondition[] condition, FieldValue[] fieldValues, Object value)
  {
    UpdateData ud = new UpdateData();
    ud.setConditions(condition);
    ud.setFieldValues(fieldValues);
    this.updateDataMap.add(ud);
  }

  public void deleteData(DelCnd condition) {
    this.deleteDataList.add(condition);
  }

  public HashMap<FieldDef, List> getAddDataMap() {
    return this.addDataMap;
  }

  public List<UpdateData> getUpdateDataMap() {
    return this.updateDataMap;
  }

  public List<DelCnd> getDeleteDataList() {
    return this.deleteDataList;
  }
}