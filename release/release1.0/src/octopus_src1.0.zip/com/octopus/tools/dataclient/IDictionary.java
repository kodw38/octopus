package com.octopus.tools.dataclient;

import com.octopus.tools.dataclient.ds.field.FieldDef;

public abstract interface IDictionary
{
  public abstract FieldDef[] getFieldDef(String paramString);
}