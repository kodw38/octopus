package com.octopus.tools.dataclient.v2.ds;

import java.util.Map;

public class DataDefines
{
  public String getTableName(Map data)
  {
    return null;
  }

  public String getDataSource(Map data, Map env) {
    return null;
  }

  public String getStoreTableName(Map data, Map env) {
    return null;
  }
}