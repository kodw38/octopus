package com.octopus.tools.dataclient.utils;

import com.octopus.utils.alone.ObjectUtils;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class DataMapping extends XMLObject
  implements IDataMapping
{
  public DataMapping(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void notifyObject(String op, Object obj)
    throws Exception
  {
  }

  public void destroy()
    throws Exception
  {
  }

  public void initial()
    throws Exception
  {
  }

  public List<Map> mapping(Object data) throws Exception
  {
    XMLMakeup[] ms = getXML().getChild("m");

    if (null != ms) {
      Map map = new HashMap();

      for (int i = 0; i < ms.length; ++i) {
        String fieldcode = ms[i].getProperties().getProperty("field");

        map.put(ms[i].getText().trim(), fieldcode);
      }

      List vs = new ArrayList();
      if (data instanceof List)
        for (int i = 0; i < ((List)data).size(); ++i)
          appendData(vs, ((List)data).get(i), map);

      else
        appendData(vs, data, map);

      return vs;
    }

    return null;
  }

  void appendData(List<Map> vs, Object data, Map ps) throws Exception {
    HashMap ret = new HashMap();
    Iterator its = ps.keySet().iterator();
    while (its.hasNext()) {
      String v = (String)its.next();
      String k = (String)ps.get(v);
      ret.put(k, ObjectUtils.getValueByPath(data, v));
    }
    vs.add(ret);
  }
}