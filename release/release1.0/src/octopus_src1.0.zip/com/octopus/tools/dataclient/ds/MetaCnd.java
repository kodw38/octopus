package com.octopus.tools.dataclient.ds;

import java.util.Map;
import net.sf.json.JSONObject;

public class MetaCnd
{
  String opCode;
  Map cnd;

  public MetaCnd(String opCode, Map cnd)
  {
    this.opCode = opCode;
    this.cnd = cnd;
  }

  public String getOpCode() {
    return this.opCode;
  }

  public void setOpCode(String opCode) {
    this.opCode = opCode;
  }

  public Map getCnd() {
    return this.cnd;
  }

  public void setCnd(Map cnd) {
    this.cnd = cnd; }

  public String toString() {
    StringBuffer sb = new StringBuffer();
    sb.append("opCode:" + this.opCode).append(",").append("data:").append(JSONObject.fromObject(this.cnd).toString());
    return sb.toString();
  }
}