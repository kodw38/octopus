package com.octopus.tools.dataclient.dataquery.ws4;

import com.octopus.tools.dataclient.dataquery.FieldMapping;
import com.octopus.tools.dataclient.dataquery.FieldValue;

public class WSQueryBean
{
  String[] queryFields;
  FieldMapping[] fieldMapping;
  FieldValue[] fieldValue;

  public String[] getQueryFields()
  {
    return this.queryFields;
  }

  public void setQueryFields(String[] queryFields) {
    this.queryFields = queryFields;
  }

  public FieldMapping[] getFieldMapping() {
    return this.fieldMapping;
  }

  public void setFieldMapping(FieldMapping[] fieldMapping) {
    this.fieldMapping = fieldMapping;
  }

  public FieldValue[] getFieldValue() {
    return this.fieldValue;
  }

  public void setFieldValue(FieldValue[] fieldValue) {
    this.fieldValue = fieldValue;
  }
}