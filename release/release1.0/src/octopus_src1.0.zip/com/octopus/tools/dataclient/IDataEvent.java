package com.octopus.tools.dataclient;

public abstract interface IDataEvent
{
}