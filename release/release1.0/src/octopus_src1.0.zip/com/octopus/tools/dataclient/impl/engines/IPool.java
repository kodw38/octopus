package com.octopus.tools.dataclient.impl.engines;

import java.util.Properties;

public abstract interface IPool
{
  public abstract Properties getConnProperties();

  public abstract boolean isMatch(DC paramDC, Object paramObject);

  public abstract boolean isDefault();
}