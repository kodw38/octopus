package com.octopus.tools.alarm;

import java.util.Map;

public abstract interface IAlarmGet
{
  public abstract boolean addAlarm(String paramString1, String paramString2, Map<String, String> paramMap);
}