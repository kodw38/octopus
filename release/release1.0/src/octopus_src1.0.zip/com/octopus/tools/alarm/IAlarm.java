package com.octopus.tools.alarm;

import java.util.Date;
import java.util.List;

public abstract interface IAlarm
{
  public abstract boolean alarm(List<String> paramList1, List<String> paramList2, String paramString1, String paramString2, Date paramDate, int paramInt);
}