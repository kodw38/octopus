package com.octopus.tools.alarm.ds;

public class AlarmMsg
{
  String title;
  String summary;
  String content;
  String keyWords;
  String sender;
  String receivers;
  String cc;

  public String getTitle()
  {
    return this.title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getSummary() {
    return this.summary;
  }

  public void setSummary(String summary) {
    this.summary = summary;
  }

  public String getContent() {
    return this.content;
  }

  public void setContent(String content) {
    this.content = content;
  }

  public String getKeyWords() {
    return this.keyWords;
  }

  public void setKeyWords(String keyWords) {
    this.keyWords = keyWords;
  }

  public String getSender() {
    return this.sender;
  }

  public void setSender(String sender) {
    this.sender = sender;
  }

  public String getReceivers() {
    return this.receivers;
  }

  public void setReceivers(String receivers) {
    this.receivers = receivers;
  }

  public String getCc() {
    return this.cc;
  }

  public void setCc(String cc) {
    this.cc = cc;
  }
}