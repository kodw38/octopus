package com.octopus.tb;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.formula.functions.T;

import com.alibaba.fastjson.JSONArray;
import com.octopus.utils.alone.ObjectUtils;
public class SystemInfoUtils {
	/**
	 * 
	 * @Title: convertToMap 
	 * @Description: 首行为键次行为值
	 * @param list
	 * @return
	 * @return: Map
	 */
	public static Map convertToMap(List<List<String>> list){
		Map json = new HashMap();
		if(null !=  list && list.size()>1){
			 for(int i=0;i<list.get(0).size();i++){
				 json.put(list.get(0).get(i), list.get(1).get(i));
			 }
		 }
		return json;
	}
	/**
	 * 
	 * @Title: compareString 
	 * @Description: 比较两个字符串
	 * @param str1
	 * @param str2
	 * @return
	 * @return: boolean
	 */
	public static boolean compareString(String str1,String str2) {
		if(StringUtils.isNotEmpty(str1)) {
			return str1.equals(str2);
		}
		else if(StringUtils.isNotEmpty(str2)) {
			return str2.equals(str1);
		}
		return false;
	}
	public static String compareColAndGet(List<List<String>> target,int compareCol,String compareStr,int targetCol,Boolean isEqual){
    	List<String> ret = compareColAndGet(target,compareCol,compareStr,targetCol,0,isEqual);
    	return ret.size()>0?ret.get(0):null;
    }
    public static List<String> compareColAndGet(List<List<String>> target,int compareCol,String compareStr,int targetStartCol,int targetEndCol,boolean isEqual){
    	List<String> ret = new ArrayList();
    	if(target.size() == 1){
    		ret.add(target.get(0).get(targetStartCol));
    	}
    	for(List<String> temp : target){
			 if(temp.size()>compareCol && !(temp.get(compareCol).equals(compareStr) ^ isEqual)){
				 if(targetEndCol == 0){
					 ret.add(temp.get(targetStartCol));
					 break;
				 }
				 else{
					 ret = new ArrayList(-1 == targetEndCol?temp.subList(targetStartCol, temp.size()):temp.subList(targetStartCol, targetEndCol));
				 }
			 }
		 }
    	return ret;
    }
	public static List<List<String>> subList(List<List<String>> list,int start,int end){
		if(end < list.size())
			return new ArrayList(list.subList(start, end));
		else
			return new ArrayList(list.subList(start, list.size()-1));
	}
	/**
	 * 
	 * @Title: addValueToMap 
	 * @Description: 添加键值到MAP
	 * @param map
	 * @param key
	 * @param value
	 * @return
	 * @return: Map
	 */
	public static Map addValueToMap(Map map,String key,Object value){
		if(null != key){
			map.put(key, value);
		}
		return map;
	}
	
	public static String getDate(String pattern){
    	SimpleDateFormat format = new SimpleDateFormat(pattern);
    	return format.format(new Date());
    }
	public static List splitToList(String str,String regex) {
		if(null != str && str.length() > 0) {
			return Arrays.asList(str.split(regex));
		}
		return null;
	}
	public static T[] convertListToArray(List<T> list) {
		if(null != list && list.size() > 0) {
			return list.toArray(new T[0]);
		}
		return null;
	} 
	public static List mergeList(List<?> list1,List list2) {
		if(null != list1) {
			if(null!=list2)
				list1.addAll(list2);
			return list1;
		}
		else
			return list2;
	}
	/**
	 * 
	 * @Title: convertString2Map 
	 * @Description: 将系统打印输出的map内容转换为MAP对象
	 * @param mapStr
	 * @return
	 * @return: Map
	 */
	public static Map convertString2Map(String mapStr) {
		mapStr = mapStr.trim();
		if(mapStr.startsWith("{")&&mapStr.endsWith("}")) {
			Map newMap = new LinkedHashMap();
			String content = mapStr.substring(1, mapStr.length()-1);
			for(String keyV : content.split(",")){
				if(keyV.indexOf('=')>0) {
					String k = keyV.split("=")[0];
					String v = null;
					if(keyV.split("=").length > 1) {
						v = keyV.split("=")[1];
					}
					if(StringUtils.isNotEmpty(k.trim())) {
						newMap.put(k.trim(), v);
					}
				}
			}
			return newMap;
		}
		return null;
	}
	/**
	 * 
	 * @Title: convertString2List 
	 * @Description: 数组字符串转List对象
	 * @param listStr
	 * @return
	 * @return: List
	 */
	public static List convertString2List(String listStr) {
		String newListStr = listStr.trim();
		List ret = new ArrayList();
		if(newListStr.startsWith("[")&&newListStr.endsWith("]")) {
			String content = newListStr.substring(1, newListStr.length()-1);
			//子元素为map
			if(content.startsWith("{")) {
				ret = JSONArray.parseArray(newListStr.replaceAll("=", ":"),LinkedHashMap.class);
			}
			//子元素为字符串
			else {
				ret = JSONArray.parseArray(newListStr.replaceAll("=", ":"),String.class);
			}
			return ret;
		}
		return null;
	}
	public String removeString(String str,String rmStr,String regex) {
		if(StringUtils.isEmpty(str)||StringUtils.isEmpty(rmStr)) {
			return str;
		}
		if(StringUtils.isEmpty(regex)) {
			return str.replaceAll(rmStr, "");
		}else {
			List<String> newStr = new ArrayList<String>();
			String[] strArray = str.split(regex);
			for(String s : strArray) {
				if(!rmStr.equals(s)) {
					newStr.add(s);
				}
			}
			return transListToStr(newStr,regex);
		}
	}
	public String transListToStr(List list,String regex) {
		StringBuilder sb = new StringBuilder();
		if(null != list && list.size()>0) {
			for(Object o : list) {
				sb.append(o).append(regex);
			}
			if(StringUtils.isNotEmpty(regex))
				return sb.substring(0, sb.length()-1);
		}
		return sb.toString();
	}
	public static Object convertString(String data,String type) {
		if("Integer".equalsIgnoreCase(type)) {
			if(null == data || data.isEmpty()) {
				return Integer.valueOf(0);
			}
			return Integer.valueOf(data);
		}
		return data;
	}
	private static Boolean contain(Collection<Object> datas,Object elements) {
		if(!(elements instanceof Collection)
				&& !elements.getClass().isArray())
			return ((Collection)datas).contains(elements.toString());
		else{
			if(elements.getClass().isArray()){
				return ((Collection)datas).containsAll(Arrays.asList((Object[])elements));
			}else{
				return ((Collection)datas).containsAll((Collection)elements);
			}
		}
	}
	public static Boolean contain(Object data,Object element) throws Exception{
		if(null != data){
			if(null == element)
				return true;
			if(data instanceof String){
				return ((String)data).contains(element.toString());
			}else if(data instanceof Collection){
				return contain((Collection)data,element);
			}else if(data.getClass().isArray()){
				return contain(Arrays.asList((Object[])data),element);
			}else{
				throw new Exception("Not support data ClassType ["+data.getClass().getName()+"]");
			}
		}
		return false;
	}
	public static Object ConvertDataAndCalculate(String cal,String date,String pattern,int number,String unit){
		if(StringUtils.isEmpty(date))
			return null;
		String patternTemp = StringUtils.isEmpty(pattern)?"yyyy-MM-dd":pattern;
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		Date newDate;
		try {
			newDate = sdf.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
		if(StringUtils.isNotEmpty(cal)) {
			Calendar calender = Calendar.getInstance();
			calender.setTime(newDate);
			int fieldCode;
			if("D".equalsIgnoreCase(unit)){
				fieldCode = Calendar.DAY_OF_YEAR;
			}else if("Y".equalsIgnoreCase(unit)){
				fieldCode = Calendar.YEAR;
			}else if("M".equalsIgnoreCase(unit)){
				fieldCode = Calendar.MONTH;
			}else{
				return sdf.format(calender.getTime());
			}
			if ("A".equalsIgnoreCase(cal)) {
				calender.add(fieldCode,number);
			}else if("D".equalsIgnoreCase(cal)) {
				calender.add(fieldCode,0-number);
			}
			return sdf.format(calender.getTime());
		}
		return newDate;
	}
	public static String newString(String str1,String str2){
		return new String(str1+str2);
	}

		public static void main(String[] args) throws Exception {
			List l = new ArrayList();
			Map h = new HashMap();
			h.put("a", "asd");
			h.put("a", "1");
			l.add(h);
			l.add(h);
			ObjectUtils.convertList2String(l);
			Map m = convertString2Map("{lastFile=20180801, lastFileList=U src/com/asiainfo/crm/logs/auditlog/filter/AuditLogFilter.java\r\n" + 
					"U src/com/asiainfo/crm/logs/auditlog/AuditRulesMatcher.java\r\n" + 
					"U src/com/asiainfo/crm/logs/auditlog/exe/command/AuditLogRunnable.java}, filepath=/home/build/releaseNote/CRM_R332/checkReleaseLog.txt}");
		ConvertDataAndCalculate("A","2018-01-01","yyyy-MM-dd",3,"M");
		char[] ch = "mysql".toCharArray();
		StringBuilder sb = new StringBuilder();

		for(int i = 1; i <= ch.length; ++i) {
			char tmp = ch[i - 1];
			int var5 = tmp * i + ch.length;
			var5 %= 96;
			var5 = (var5 + 32) % 128;
			sb.append((char)var5);
		}
		System.out.print(sb.toString());
		List list1 = new ArrayList();
		list1.add("ab");
		list1.add("a");
		list1.add("abb");
		list1.add("1");
		List list2 = new ArrayList();
		list2.add("ab");
		list2.add("a");
		String s1 = "abb";
		String s2 = "ab";
		int i = 1;
		String[] a1 = {"abb","a","ab","1"};
		System.out.println(contain(list1,list2));
		System.out.println(contain(list1,s1));
		System.out.println(contain((Object)list1,i));
		System.out.println(contain(s1,s2));
		System.out.println(contain(a1,list2));
		System.out.println(contain(a1,list1));
		System.out.println(contain(list1,a1));
		System.out.println(contain(a1,s1));
		System.out.println(contain(a1,i));
	}
//	public static String wsdldownLoadWSDL(String url) throws Exception{
//		URL url_Ob = new URL(url);  
//		URLConnection conn = url_Ob.openConnection();
//		XMLMakeup xml = XMLUtil.getDataFromStream(conn.getInputStream());
//	}
}
