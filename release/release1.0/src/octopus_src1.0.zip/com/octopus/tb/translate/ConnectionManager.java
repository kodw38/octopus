/**   
 * Copyright © 2017 公司名. All rights reserved.
 * 
 * @Title: ConnectionManager.java 
 * @Prject: treasurebag
 * @Package: com.asiainfo.tb.translate 
 * @Description: TODO
 * @author: ligs   
 * @date: 2017年9月4日 上午10:56:15 
 * @version: V1.0   
 */
package com.octopus.tb.translate;

import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.SingleClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.params.CoreProtocolPNames;
import org.apache.http.params.HttpParams;

/** 
 * @ClassName: ConnectionManager 
 * @Description: TODO
 * @author: ligs
 * @date: 2017年9月4日 上午10:56:15  
 */
public class ConnectionManager {
	/** 连接超时时间 */
    static final int TIMEOUT = 30000;
    /** 数据传输超时 */
    static final int SO_TIMEOUT = 30000;
 
    static String UA = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1"
            + " (KHTML, like Gecko) Chrome/21.0.1180.89 Safari/537.1";
 
    private ConnectionManager() {
 
    }
 
    public static DefaultHttpClient getHttpClient() {
        SchemeRegistry schemeRegistry = new SchemeRegistry();
        schemeRegistry.register(new Scheme("http", PlainSocketFactory
                .getSocketFactory(), 80));
        schemeRegistry.register(new Scheme("https", SSLSocketFactory
                .getSocketFactory(), 443));
 
        HttpParams params = new BasicHttpParams();
        params.setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, TIMEOUT);
        params.setParameter(CoreConnectionPNames.SO_TIMEOUT, SO_TIMEOUT);
        params.setParameter(CoreProtocolPNames.USER_AGENT, UA);
        ClientConnectionManager cm = new SingleClientConnManager(params,
                schemeRegistry);
        
        DefaultHttpClient client = new DefaultHttpClient(cm, params);
        return client;
    }
}
