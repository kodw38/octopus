/**   
 * Copyright © 2017 公司名. All rights reserved.
 * 
 * @Title: BaiduTranslate.java 
 * @Prject: treasurebag
 * @Package: com.asiainfo.tb.translate 
 * @Description: TODO
 * @author: ligs   
 * @date: 2017年9月4日 下午3:51:03 
 * @version: V1.0   
 */
package com.octopus.tb.translate;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.security.NoSuchAlgorithmException;

import com.octopus.tb.sec.MD5;
import com.octopus.utils.common.TBUtils;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/** 
 * @ClassName: BaiduTranslate 
 * @Description: TODO
 * @author: ligs
 * @date: 2017年9月4日 下午3:51:03  
 */
public class BaiduTranslate {
	private static final String AUTO= "auto";//自动检测
	private static final String ZH	= "zh";//中文
	private static final String EN	= "en";//英语
	private static final String YUE	= "yue";//粤语
	private static final String WYW	= "wyw";//文言文
	private static final String JP	= "jp";//日语
	private static final String KOR	= "kor";//韩语
	private static final String FRA	= "fra";//法语
	private static final String SPA	= "spa";//西班牙语
	private static final String TH	= "th";//泰语
	private static final String ARA	= "ara";//阿拉伯语
	private static final String RU	= "ru";//俄语
	private static final String PT	= "pt";//葡萄牙语
	private static final String DE	= "de";//德语
	private static final String IT	= "it";//意大利语
	private static final String EL	= "el";//希腊语
	private static final String NL	= "nl";//荷兰语
	private static final String PL	= "pl";//波兰语
	private static final String BUL	= "bul";//保加利亚语
	private static final String EST	= "est";//爱沙尼亚语
	private static final String DAN	= "dan";//丹麦语
	private static final String FIN	= "fin";//芬兰语
	private static final String CS	= "cs";//捷克语
	private static final String ROM	= "rom";//罗马尼亚语
	private static final String SLO	= "slo";//斯洛文尼亚语
	private static final String SWE	= "swe";//瑞典语
	private static final String HU	= "hu";//匈牙利语
	private static final String CHT	= "cht";//繁体中文
	private static final String VIE	= "vie";//越南语	
	private static String appid="20170904000080339";
	private static String secret="I86i2jAn_DT2lXQGj50v";
	
    public static String translate(String from,String to,String data){
        //获取随机值
        String salt = TBUtils.getFixLenthString(10);
        //计算签名sign,md5加密
        String sign = "";
        StringBuffer encodeStrBuff = new StringBuffer();
        encodeStrBuff.append(appid).append(data).append(salt).append(secret);
        MD5 md5 = new MD5();
		try {
			String encodeStr = new String(encodeStrBuff.toString().getBytes("UTF-8"));
			sign =TBUtils.byteTo16Hex(md5.MD5Encrypt(encodeStr));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return null;
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return null;
		}
       return getDate("{"+getResult(appid,data,from,to,salt,sign));
    }
    //百度平台（翻译接口）相关数据  
    private static String getResult(String appid,String body,String from ,String to,String salt,String sign){  
        String result="";  
        //拼接相关参数  
        String params="http://api.fanyi.baidu.com/api/trans/vip/translate?appid=20170904000080339&q="+body+"&from="+from+"&to="+to+"&salt="+salt+"&sign="+sign;         
         try {  
            URL url = new URL(params);  
            URLConnection connection = url.openConnection();    
            //设置连接时间(10*1000)  
            connection.setConnectTimeout(10*1000);  
            //设置输出  
            connection.setDoOutput(true);  
            //设置输出  
            connection.setDoInput(true);  
            //设置缓存  
            connection.setUseCaches(false);           
            //outputstream-----输出流  
            InputStream inputstream=connection.getInputStream();  
            //缓存字符流  
            BufferedReader buffer = new BufferedReader(new InputStreamReader(inputstream));   
            //返回相关结果  
            StringBuilder builder=new StringBuilder();  
            while(buffer.read()!=-1){  
                builder.append(buffer.readLine());                
            }  
            //返回相关结果  
            result=builder.toString();  
            //缓存字符流关闭操作  
            buffer.close();  
  
        } catch (MalformedURLException e) {  
            // TODO Auto-generated catch block  
            e.printStackTrace();  
        } catch (IOException e) {
            // TODO Auto-generated catch block  
            e.printStackTrace();  
        }  
          
        return result;  
    }  
    //解析百度服务器平台返回的相关数据信息  
    public static String getDate(String result){  
        String date="";  
          
        JSONObject object=JSONObject.fromObject(result);  
        JSONArray array=object.getJSONArray("trans_result");  
        int length=array.size();  
        for(int i=0;i<length;i++){  
            JSONObject params=JSONObject.fromObject(array.get(i));  
            String str=params.getString("dst");  
            try {  
            	date=URLDecoder.decode(str,"utf-8");  
            } catch (UnsupportedEncodingException e) {  
                // TODO Auto-generated catch block  
                e.printStackTrace();  
            }             
        }     
        return date;  
    }
    /**  
     * @param args  
	 * @throws UnsupportedEncodingException 
	 * @throws NoSuchAlgorithmException 
     */  
    public static void main(String[] args) throws UnsupportedEncodingException, NoSuchAlgorithmException {  
        /* String data="条条道路通罗马"; */
         String data1="All roads lead to Rome";
         String from=AUTO;  
         String to=ZH;
         System.out.println(translate(from, to, data1));
    }  
}
