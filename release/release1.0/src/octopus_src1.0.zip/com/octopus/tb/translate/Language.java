/**   
 * Copyright © 2017 公司名. All rights reserved.
 * 
 * @Title: Language.java 
 * @Prject: treasurebag
 * @Package: com.asiainfo.tb.translate 
 * @Description: TODO
 * @author: ligs   
 * @date: 2017年9月4日 上午10:54:58 
 * @version: V1.0   
 */
package com.octopus.tb.translate;

/** 
 * @ClassName: Language 
 * @Description: TODO
 * @author: ligs
 * @date: 2017年9月4日 上午10:54:58  
 */
public enum Language {

	AUTO("自动", "auto"), //
    TAIWAN("台湾", "zh-TW"), //
    CHINA("中文", "zh-CN"), //
    ENGLISH("英语", "en"), //
    JAPAN("日文", "ja");//
 
    private String name;
    private String value;
 
    private Language(String name, String value) {
        this.name = name;
        this.value = value;
    }
 
    public String getName() {
        return name;
    }
 
    public void setName(String name) {
        this.name = name;
    }
 
    public String getValue() {
        return value;
    }
 
    public void setValue(String value) {
        this.value = value;
    }
}
