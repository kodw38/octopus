package com.octopus.tb.catalog;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;

public class GetCatalog extends XMLDoObject{
	
	private XMLDoObject dataClient;
	
	Map<String,List<String>> temMap=new HashMap();
	
	
	private List<Map<String, String>> getCatalogInfos() throws Exception{
		try {
			String sqlStr="[SELECT * FROM tb.isp_dictionary_catalog;]";
			Map<String,Object> scInput = new HashMap<String, Object>();
			scInput.put("op", "query");
//			scInput.put("ds", "dictionary");
			scInput.put("sqls", JSONArray.fromObject(sqlStr));
			//scInput.put("localPath", localPath);
			return  (List<Map<String, String>>) dataClient.doSomeThing(null, null, scInput, null, null);
		}catch (Exception e) {
			throw new Exception("query catalog failed",e);
		}
		
	}
	
	public GetCatalog(XMLMakeup xml, XMLObject parent, Object[] containers)
			throws Exception {
		super(xml, parent, containers);
		// TODO Auto-generated constructor stub
	}


	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		GetCatalog getsome=new GetCatalog(null, null, null);
	    Object obj=getsome.doSomeThing(null, null, null, null, null);
		

	}



	@Override
	public boolean checkInput(String arg0, XMLParameter arg1, Map arg2,
			Map arg3, Map arg4) throws Exception {
		// TODO Auto-generated method stub
		return true;
	}



	@Override
	public ResultCheck checkReturn(String arg0, XMLParameter arg1, Map arg2,
			Map arg3, Map arg4, Object arg5) throws Exception {
		// TODO Auto-generated method stub
		return  new ResultCheck(true, arg5);
	}



	@Override
	public boolean commit(String arg0, XMLParameter arg1, Map arg2, Map arg3,
			Map arg4, Object arg5) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}



	@Override
	public void doInitial() throws Exception {
		// TODO Auto-generated method stub
		
	}



	@Override
	public  Object doSomeThing(String arg0, XMLParameter arg1, Map arg2,
			Map arg3, Map arg4) throws Exception {
		List<Map<String, String>> datas=getCatalogInfos();
		temMap=new HashMap();
	
		if(datas!=null&&datas.size()>0){
			for(int i=0;i<datas.size();i++){
				String parentCode=(String) datas.get(i).get("PARTNER_CATALOG_CODE");
				String catalogCode=(String) datas.get(i).get("CATALOG_CODE");
				String catalogName=(String) datas.get(i).get("CATALOG_NAME");
				
				if(temMap!=null){
					if(temMap.get(parentCode) != null){
						List list=temMap.get(parentCode);
						list.add(catalogCode+"_"+catalogName);
					}else{
						List list=new ArrayList();
						list.add(catalogCode+"_"+catalogName);
						temMap.put(parentCode, list);
					}
				}else{
					List list=new ArrayList();
					list.add(catalogCode+"_"+catalogName);
					temMap.put(parentCode, list);
				}
			}
		}
		Map ret =getCatalogStruct("0",temMap);
		JSONObject obj=JSONObject.fromObject(ret);
		System.out.print(obj);
		return obj;
	}
	
	private Map getCatalogStruct(String id,Map map){
		Map listMap=new HashMap();
		List list=(List) map.get(id);
		if(list!=null&&list.size()>0){
			for(int i=0;i<list.size();i++){
				String code_name=(String) list.get(i);
				String[] strArr=code_name.split("_");
				String code=strArr[0];
				
				Map childMap=getCatalogStruct(code,temMap);
			
				listMap.put(code_name, childMap);
			}
		}
		return listMap;
	}



	@Override
	public boolean rollback(String arg0, XMLParameter arg1, Map arg2, Map arg3,
			Map arg4, Object arg5, Exception arg6) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

}
