/**   
 * Copyright © 2017 公司名. All rights reserved.
 * 
 * @Title: AuthorizationFilter.java 
 * @Prject: treasurebag
 * @Package: com.octopus.tb.sec.filter
 * @Description: TODO
 * @author: ligs   
 * @date: 2017年8月11日 下午2:54:24 
 * @version: V1.0   
 */
package com.octopus.tb.sec.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

/** 
 * @ClassName: AuthorizationFilter 
 * @Description: TODO
 * @author: ligs
 * @date: 2017年8月11日 下午2:54:24  
 */

public class AuthorizationFilter  implements Filter {

	/* (non Javadoc) 
	 * @Title: destroy
	 * @Description: TODO 
	 * @see javax.servlet.Filter#destroy() 
	 */
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	/* (non Javadoc) 
	 * @Title: doFilter
	 * @Description: TODO
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @throws IOException
	 * @throws ServletException 
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain) 
	 */
	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
			throws IOException, ServletException {
		HttpServletResponse response = (HttpServletResponse)servletResponse;
		HttpServletRequest request = (HttpServletRequest)servletRequest;
		long l = System.currentTimeMillis();
		//校验请求信息
		if(checkToken(request,response)){
			
		}
	}

	/* (non Javadoc) 
	 * @Title: init
	 * @Description: TODO
	 * @param arg0
	 * @throws ServletException 
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig) 
	 */
	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		
	}

	public boolean checkToken(HttpServletRequest request,HttpServletResponse response){
		String token = request.getHeader("authorization");
		if (StringUtils.isEmpty(token)) {
            // TODO:拦截响应
        }
		String endPoint = request.getHeader("actions");
		String clientId = request.getHeader("clientId");
		//TokenValidateResponse checkResult = TokenValidator.checkToken(token, endPoint, clientId);
		//TODO 从缓存中根据键token 取出对应的接口
//		if(!checkResult.isResultFlag()){
//			
//		}
		//鉴权成功，返回鉴权信息
		response.setStatus(HttpServletResponse.SC_OK);
		return true;
	}
}
