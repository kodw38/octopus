/**   
 * Copyright © 2017 公司名. All rights reserved.
 * 
 * @Title: AuthInfo.java 
 * @Prject: treasurebag
 * @Package: com.octopus.tb.sec.auth.beans
 * @Description: TODO
 * @author: ligs   
 * @date: 2017年8月14日 下午2:51:10 
 * @version: V1.0   
 */
package com.octopus.tb.sec.auth.sever.beans;

import java.util.Date;

/**
 * 
 * @ClassName: AuthInfo 
 * @Description: 存放于redis中的对应token的鉴权信息
 * @author: ligs
 * @date: 2017年8月14日 下午2:57:31
 */
public class AuthInfo {
	//接口名称
	private String endPoint;
	//客户端ID
	private String clientId;
	//生成日期
	private Date createDate;
	//令牌
	private TbAccessToken token;
	/**
	 * @return the endPoint
	 */
	public String getEndPoint() {
		return endPoint;
	}
	/**
	 * @param endPoint the endPoint to set
	 */
	public void setEndPoint(String endPoint) {
		this.endPoint = endPoint;
	}
	/**
	 * @return the clientId
	 */
	public String getClientId() {
		return clientId;
	}
	/**
	 * @param clientId the clientId to set
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	/**
	 * @return the createDate
	 */
	public Date getCreateDate() {
		return createDate;
	}
	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public TbAccessToken getToken() {
		return token;
	}
	public void setToken(TbAccessToken token) {
		this.token = token;
	}
	
}
