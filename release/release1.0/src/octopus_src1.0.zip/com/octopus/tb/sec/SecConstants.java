/**   
 * Copyright © 2017 公司名. All rights reserved.
 * 
 * @Title: SecConstants.java 
 * @Prject: treasurebag
 * @Package: com.octopus.tb.sec 
 * @Description: TODO
 * @author: ligs   
 * @date: 2017年12月29日 下午4:00:51 
 * @version: V1.0   
 */
package com.octopus.tb.sec;

/** 
 * @ClassName: SecConstants 
 * @Description: TODO
 * @author: ligs
 * @date: 2017年12月29日 下午4:00:51  
 */
public final class SecConstants {
	public final static String ENCRYT_ALGORITHM = "EncrytAlgorithm";
	public final static String ENCODE_TYPE = "EncodeType";
	public final static String ENCRYT_KEY = "EncrytKey";
}
