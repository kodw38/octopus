/**   
 * Copyright © 2017 公司名. All rights reserved.
 * 
 * @Title: TokenValidater.java 
 * @Prject: treasurebag
 * @Package: com.octopus.tb.sec.auth
 * @Description: TODO
 * @author: ligs   
 * @date: 2017年8月11日 下午5:20:15 
 * @version: V1.0   
 */
package com.octopus.tb.sec.auth.sever;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.octopus.isp.ds.RequestParameters;
import com.octopus.isp.ds.Session;
import com.octopus.tb.sec.auth.common.AuthConstant;
import com.octopus.tb.sec.auth.sever.beans.TbAccessToken;
import com.octopus.tb.sec.auth.sever.beans.TokenValidateResponse;
import com.octopus.tb.sec.exception.AuthorizationErrorCode;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;

import net.sf.json.JSONObject;

/**
 * @ClassName: TokenValidater
 * @Description: token校验
 * @author: ligs
 * @date: 2017年8月11日 下午5:20:15
 */
public class TokenValidator extends XMLDoObject {

	/**
	 * @fieldName: serialVersionUID
	 * @fieldType: long
	 * @Description: 服务器端TOKEN校验
	 */
	protected static transient Log logger = LogFactory.getLog(TokenValidator.class);
	private static final long serialVersionUID = 1L;
	private String tokenScope;
	private String tokenPrivilege;
	private String tokenType;
	private XMLDoObject redisClient;
	private static final String FORMAT = "yyyyMMddHHmmss";

	/**
	 * @Title:TokenValidater
	 * @Description:TODO
	 * @param xml
	 * @param parent
	 * @throws Exception
	 */

	public TokenValidator(XMLMakeup xml, XMLObject parent, Object[] containers) throws Exception {
		super(xml, parent, containers);
	}

	public Object checkToken(String token, String endPoint, String clientId, String redisKey) {
		TokenValidateResponse res = new TokenValidateResponse();
		res.setResultFlag(false);
		String[] tokenStrs = token.split("\\s+");
		if (null == tokenStrs || tokenStrs.length < 2 || !tokenType.contains(tokenStrs[0])
				|| StringUtils.isEmpty(tokenStrs[1])) {
			res.setResultCode(AuthorizationErrorCode.UNAUTHORIZED);
			return res;
		}
		String relToken = tokenStrs[1];
		// 根据token获取redis中的鉴权信息
		Map<String, String> rcInput = new HashMap<String, String>();
		rcInput.put("op", "lget");
		rcInput.put("db", redisKey);
		rcInput.put("key", relToken);
		List temp = null;
		try {
			temp = (List) redisClient.doSomeThing(null, null, rcInput, null, null);
		} catch (Exception e) {
			logger.error("query TokenRedis failed", e);
		}
		// token不存在
		if (null == temp || temp.isEmpty()) {
			logger.error("TokenValidate failed!Token not exist in TB:" + relToken);
			res.setResultCode(AuthorizationErrorCode.UNAUTHORIZED);
			return res;
		}
		// 校验请求信息和鉴权信息是否相符
		String authInfoStr = (String) temp.get(0);
		JSONObject authInfo = JSONObject.fromObject(authInfoStr);
		// 1.不存在该token
		if (null == authInfo) {
			logger.error("TokenValidate failed!Token not exist in TB:" + relToken);
			res.setResultCode(AuthorizationErrorCode.UNAUTHORIZED);
			return res;
		}
		JSONObject tokenInfo = (JSONObject) authInfo.get(AuthConstant.AuthInfo.TOKEN);
		// 2.该token未授权该请求接口(非必需)
		if (AuthConstant.TokenScope.PRIVATE.equals(tokenInfo.get(AuthConstant.TbAccessToken.SCOPE))
				&& !endPoint.equals(authInfo.get(AuthConstant.AuthInfo.ENDPOINT))) {
			logger.error("TokenValidate failed!EndPoint(" + endPoint + ") not accredit :" + relToken);
			res.setResultCode(AuthorizationErrorCode.INVALID_RESOURCE);
			return res;
		}
		// 3.超过token有效时限
		Calendar cal = Calendar.getInstance();
		Date nowTime = cal.getTime();
		try {
			cal.setTime((new SimpleDateFormat(FORMAT)).parse((String) authInfo.get(AuthConstant.AuthInfo.CREATE_DATE)));
		} catch (ParseException e) {
			logger.error("check effect time failed", e);
		}
		// 时间间隔
		int interval = (int) ((nowTime.getTime() - cal.getTimeInMillis()) / 1000);
		int expireTime = (Integer) authInfo.get(AuthConstant.AuthInfo.EXPIRE_TIME);
		// 超过失效时间
		if (interval > expireTime) {
			logger.error(new StringBuilder().append("TokenValidate failed!More than effect time:").append(relToken)
					.append("expireTime").append(expireTime).append(",nowTime:").append(nowTime.toString())
					.append(",createTime:").append(cal.getTime().toString()).toString());
			res.setResultCode(AuthorizationErrorCode.UNAUTHORIZED);
			rcInput.put("op", "remove");
			try {
				redisClient.doSomeThing(null, null, rcInput, null, null);
			} catch (Exception e) {
				logger.error("delete token cache failed", e);
			}
			return res;
		}
		// 4.token注册client与请求client不一致(非必需) token与client绑定
		if (AuthConstant.TokenPrivilege.PRIVATE.equals(tokenInfo.get(AuthConstant.TbAccessToken.PRIVILEGE))
				&& !clientId.equals(authInfo.get(AuthConstant.AuthInfo.CLIENT_ID))) {
			logger.error("TokenValidate failed!client " + clientId + " not allowd,token:" + relToken + ",allowClient:"
					+ authInfo.get("clientId"));
			res.setResultCode(AuthorizationErrorCode.UNAUTHORIZED);
			return res;
		}
		// 校验通过返回token
		TbAccessToken retTokenInfo = new TbAccessToken();
		retTokenInfo.setAccessToken(String.valueOf(tokenInfo.get(AuthConstant.TbAccessToken.ACCESS_TOKEN)));
		retTokenInfo.setPrivilege(String.valueOf(tokenInfo.get(AuthConstant.TbAccessToken.PRIVILEGE)));
		retTokenInfo.setScope(String.valueOf(tokenInfo.get(AuthConstant.TbAccessToken.SCOPE)));
		retTokenInfo.setTokenType(String.valueOf(tokenInfo.get(AuthConstant.TbAccessToken.TOKEN_TYPE)));
		retTokenInfo.setExpiresIn((Integer) (expireTime - interval));
		res.setResultFlag(true);
		res.setTokenInfo(retTokenInfo);
		return new Object[] { res, authInfo };
	}

	@Override
	public void doInitial() throws Exception {

	}
	@Override
	public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception {
		if (null == input || input.isEmpty() || StringUtils.isEmpty((String) input.get("token"))) {
			return false;
		}
		return true;
	}

	@Override
	public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret)
			throws Exception {
		return new ResultCheck(true, ret);
	}

	@Override
	public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret)
			throws Exception {
		return false;
	}

	@Override
	public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception {
		Map p = ((Map) env.get("${env}"));
		// token作用范围-作用于指定接口或者所有接口,枚举:private/public
		tokenScope = (String) p.get("TokenScope");
		// token权限-是否与客户端绑定,枚举:private/public
		tokenPrivilege = (String) p.get("TokenPrivilege");
		// token类型-生成token的类型
		tokenType = (String) p.get("TokenType");
		String redisKey = (String) p.get("TokenRedis");
		String op = (String) input.get("op");
		if (null == redisClient) {
			redisClient = (XMLDoObject) getObjectById("RedisClient");
		}
		if (op.equals("checkToken")) {
			String token = (String) input.get("token");
			// 调用服务名称
			String endPoint = (String) input.get("endPoint");
			String clientId = (String) input.get("clientId");
			Object os = checkToken(token, endPoint, clientId, redisKey);
			if (os.getClass().isArray()) {
				try {// set session in request env each time.
					if (null == ((RequestParameters) env).getSession()) {
						XMLDoObject sm = (XMLDoObject) env.get("${sessionManager}");
						HashMap in = new HashMap();
						in.put("op", "getSession");
						in.put("UserName", ((Map) ((Object[]) os)[1]).get("clientId"));
						Object si = sm.doSomeThing(null, null, in, null, null);
						if (null != si) {
							((RequestParameters) env).setSession((Session) si);
						}
					}
				} catch (Exception e) {
				}
				return ((Object[]) os)[0];
			} else {
				return os;
			}
		}
		return null;
	}

	@Override
	public boolean rollback(String paramString, XMLParameter paramXMLParameter, Map paramMap1, Map paramMap2,
			Map paramMap3, Object paramObject, Exception paramException) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}
//	public String createToken(String clientId) throws UnsupportedEncodingException, NoSuchAlgorithmException{
//		return TBUtils.getRandomUUID()+(StringUtils.isEmpty(clientId)?"":"_"+clientId);
//	}
}
