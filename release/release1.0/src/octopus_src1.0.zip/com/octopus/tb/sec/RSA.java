/**   
 * Copyright © 2017 公司名. All rights reserved.
 * 
 * @Title: RSA.java 
 * @Prject: treasurebag
 * @Package: com.octopus.tb.sec
 * @Description: TODO
 * @author: ligs   
 * @date: 2017年8月21日 下午2:26:25 
 * @version: V1.0   
 */
package com.octopus.tb.sec;

import java.security.InvalidKeyException;  
import java.security.KeyPair;  
import java.security.KeyPairGenerator;  
import java.security.NoSuchAlgorithmException;  
import java.security.interfaces.RSAPrivateKey;  
import java.security.interfaces.RSAPublicKey;  
  
import javax.crypto.BadPaddingException;  
import javax.crypto.Cipher;  
import javax.crypto.IllegalBlockSizeException;  
import javax.crypto.NoSuchPaddingException;

/** 
 * @ClassName: RSA 
 * @Description: 非对称加密
 * @author: ligs
 * @date: 2017年8月21日 下午2:26:25  
 */
public class RSA {
	//公钥
	private  RSAPublicKey publicKey;
	//私钥
	private  RSAPrivateKey privateKey;
	
	public RSA() throws NoSuchAlgorithmException{
		KeyPair keyPair = generateKeyPair();
		publicKey = (RSAPublicKey) keyPair.getPublic();
	    privateKey = (RSAPrivateKey)keyPair.getPrivate();
	}
	protected byte[] encrypt(RSAPublicKey publicKey,String msg) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException{  
        if(publicKey!=null){  
        	byte[] srcBytes = msg.getBytes();
            //Cipher负责完成加密或解密工作，基于RSA  
            Cipher cipher = Cipher.getInstance("RSA");  
            //根据公钥，对Cipher对象进行初始化  
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);  
            byte[] resultBytes = cipher.doFinal(srcBytes);  
            return resultBytes;  
        }  
        return null;  
    }  
      
      
    protected byte[] decrypt(RSAPrivateKey privateKey,byte[] srcBytes) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException{  
        if(privateKey!=null){  
            //Cipher负责完成加密或解密工作，基于RSA  
            Cipher cipher = Cipher.getInstance("RSA");  
            //根据私钥，对Cipher对象进行初始化  
            cipher.init(Cipher.DECRYPT_MODE, privateKey);  
            byte[] resultBytes = cipher.doFinal(srcBytes);  
            return resultBytes;  
        }  
        return null;  
    }  
  
    public KeyPair generateKeyPair() throws NoSuchAlgorithmException{
    	//KeyPairGenerator类用于生成公钥和私钥对，基于RSA算法生成对象  
        KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");  
        //初始化密钥对生成器，密钥大小为1024位  
        keyPairGen.initialize(1024);  
        //生成一个密钥对，保存在keyPair中  
        KeyPair keyPair = keyPairGen.generateKeyPair();
        return keyPair;
    }
      
    public static void main(String[] args) throws NoSuchAlgorithmException, InvalidKeyException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {  
        RSA rsa = new RSA();  
        String msg = "郭XX-精品相声";  
        //得到私钥  
        RSAPrivateKey privateKey = rsa.getPrivateKey();
        privateKey.getPrivateExponent();
        //得到公钥  
        RSAPublicKey publicKey = rsa.getPublicKey(); 
        //用公钥加密  
        byte[] resultBytes = rsa.encrypt(publicKey, msg);  
          
        //用私钥解密  
        byte[] decBytes = rsa.decrypt(privateKey, resultBytes);  
          
        System.out.println("明文是:" + msg);
        System.out.println("加密后是:" + new String(resultBytes));  
        System.out.println("解密后是:" + new String(decBytes));  
    }
	/**
	 * @return the publicKey
	 */
	public RSAPublicKey getPublicKey() {
		return publicKey;
	}
	/**
	 * @param publicKey the publicKey to set
	 */
	public void setPublicKey(RSAPublicKey publicKey) {
		this.publicKey = publicKey;
	}
	/**
	 * @return the privateKey
	 */
	public RSAPrivateKey getPrivateKey() {
		return privateKey;
	}
	/**
	 * @param privateKey the privateKey to set
	 */
	public void setPrivateKey(RSAPrivateKey privateKey) {
		this.privateKey = privateKey;
	}  
  
}
