/**   
 * Copyright © 2018 公司名. All rights reserved.
 * 
 * @Title: RequestParamsCheck.java 
 * @Prject: treasurebag
 * @Package: com.octopus.tb.sec.auth.sever 
 * @Description: TODO
 * @author: ligs   
 * @date: 2018年5月25日 下午3:33:05 
 * @version: V1.0   
 */
package com.octopus.tb.sec.auth.sever;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;

import com.octopus.isp.ds.RequestParameters;
import com.octopus.tb.sec.exception.AuthorizationErrorCode;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;

/** 
 * @ClassName: RequestParamsCheck 
 * @Description: TODO
 * @author: ligs
 * @date: 2018年5月25日 下午3:33:05  
 */
public class RequestParamsCheck  extends XMLDoObject{

	private List<String> grantTypes; 
	private List<String> tokenTypes;
	private int expiresTimeMax = 0;
	private static final Pattern pattern = Pattern.compile("^(0|(-)?[1-9][0-9]*)$");
	/** 
	 * @Title:RequestParamsCheck
	 * @Description:TODO 
	 * @param xml
	 * @param parent
	 * @param containers
	 * @throws Exception 
	 */
	public RequestParamsCheck(XMLMakeup xml, XMLObject parent, Object[] containers) throws Exception {
		super(xml, parent, containers);
		//获取配置
		Properties props = xml.getChild("properties")[0].getPropertiesByChildNameAndText("property");
		String grantTypesStr = props.getProperty("allowdGrantTypes");
		if(StringUtils.isEmpty(grantTypesStr))
			throw new Exception("Please config grantTypes");
		String expiresMax = props.getProperty("expiresMax");
		if(StringUtils.isEmpty(expiresMax)
				|| !pattern.matcher(expiresMax).matches())
			throw new Exception("Please config expiresMax");
		String tokenTypesStr = props.getProperty("allowdTokenTypes");
		if(StringUtils.isEmpty(tokenTypesStr))
			throw new Exception("Please config tokenTypes");
		//初始化
		grantTypes = Arrays.asList(grantTypesStr.split(","));
		expiresTimeMax = Integer.parseInt(expiresMax);
		tokenTypes = Arrays.asList(tokenTypesStr.split(","));
	}

	/* (non Javadoc) 
	 * @Title: checkInput
	 * @Description: TODO
	 * @param paramString
	 * @param paramXMLParameter
	 * @param paramMap1
	 * @param paramMap2
	 * @param paramMap3
	 * @return
	 * @throws Exception 
	 * @see com.octopus.utils.xml.auto.IXMLDoObject#checkInput(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map) 
	 */
	@Override
	public boolean checkInput(String paramString, XMLParameter paramXMLParameter, Map paramMap1, Map paramMap2,
			Map paramMap3) throws Exception {
		// TODO Auto-generated method stub
		return true;
	}

	/* (non Javadoc) 
	 * @Title: checkReturn
	 * @Description: TODO
	 * @param paramString
	 * @param paramXMLParameter
	 * @param paramMap1
	 * @param paramMap2
	 * @param paramMap3
	 * @param paramObject
	 * @return
	 * @throws Exception 
	 * @see com.octopus.utils.xml.auto.IXMLDoObject#checkReturn(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map, java.lang.Object) 
	 */
	@Override
	public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception {
		 return new ResultCheck(true,ret);
	}

	/* (non Javadoc) 
	 * @Title: commit
	 * @Description: TODO
	 * @param paramString
	 * @param paramXMLParameter
	 * @param paramMap1
	 * @param paramMap2
	 * @param paramMap3
	 * @param paramObject
	 * @return
	 * @throws Exception 
	 * @see com.octopus.utils.xml.auto.IXMLDoObject#commit(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map, java.lang.Object) 
	 */
	@Override
	public boolean commit(String paramString, XMLParameter paramXMLParameter, Map paramMap1, Map paramMap2,
			Map paramMap3, Object paramObject) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non Javadoc) 
	 * @Title: doInitial
	 * @Description: TODO
	 * @throws Exception 
	 * @see com.octopus.utils.xml.auto.IXMLDoObject#doInitial() 
	 */
	@Override
	public void doInitial() throws Exception {
		// TODO Auto-generated method stub
		
	}

	/* (non Javadoc) 
	 * @Title: doSomeThing
	 * @Description: TODO
	 * @param paramString
	 * @param paramXMLParameter
	 * @param paramMap1
	 * @param paramMap2
	 * @param paramMap3
	 * @return
	 * @throws Exception 
	 * @see com.octopus.utils.xml.auto.IXMLDoObject#doSomeThing(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map) 
	 */
	@Override
	public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception {
		String op = (String) input.get("op");
		if("checkAuthGenerate".equals(op)) {
			String clientId = (String) input.get("client_id");
			String clientSecret = (String) input.get("client_secret");
			String grantType = (String) input.get("grant_type");
			String expiresIn = null;
            Object ot = input.get("expires_in");
            if(null != ot) {
                if (ot instanceof String) {
                    expiresIn = (String) ot;
                } else {
                    expiresIn=ot.toString();
                }
            }

			//使用卫语句校验
			if(StringUtils.isEmpty(clientId)) {
				return AuthorizationErrorCode.MISS_CLIENT_ID;
			}
			if(StringUtils.isEmpty(clientSecret)) {
				return AuthorizationErrorCode.MISS_CLIENT_SECRET;
			}
			if(StringUtils.isEmpty(grantType)) {
				return AuthorizationErrorCode.MISS_GRANT_TYPE;
			}else if(!grantTypes.contains(grantType)){
				return AuthorizationErrorCode.INVALID_GRANT_TYPE;
			}
			if(StringUtils.isNotEmpty(expiresIn)) {
				if(!pattern.matcher(expiresIn).matches()) {
					return AuthorizationErrorCode.INVALID_EXPIRY_TIME;
				}else {
					int time = Integer.parseInt(expiresIn);
					if(time > expiresTimeMax) {
						return AuthorizationErrorCode.EXPIRY_TIME_1;
					}else if(time <= 0) {
						return AuthorizationErrorCode.EXPIRY_TIME_2;
					}
				}
			}
			return Boolean.valueOf(true);
		}else if("checkAuthValidate".equals(op)) {
			RequestParameters par = (RequestParameters)env;
			String authorization = StringUtils.isEmpty(par.getHeader("authorization"))?par.getHeader("Authorization"):par.getHeader("authorization");
			if(StringUtils.isEmpty(authorization)) {
				return AuthorizationErrorCode.MISS_AUTHORIZATION;
			}else {
				String[] authorizationSplit = authorization.split("\\s+");
				if(authorizationSplit.length < 2) {
					return AuthorizationErrorCode.INVALID_AUTHORIZATION;
				}
				if(!tokenTypes.contains(authorizationSplit[0])){
					return AuthorizationErrorCode.INVALID_TOKEN_TYPE;
				}
			}
			return Boolean.valueOf(true);
		}
		return null;
	}

	/* (non Javadoc) 
	 * @Title: rollback
	 * @Description: TODO
	 * @param paramString
	 * @param paramXMLParameter
	 * @param paramMap1
	 * @param paramMap2
	 * @param paramMap3
	 * @param paramObject
	 * @param paramException
	 * @return
	 * @throws Exception 
	 * @see com.octopus.utils.xml.auto.IXMLDoObject#rollback(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map, java.lang.Object, java.lang.Exception) 
	 */
	@Override
	public boolean rollback(String paramString, XMLParameter paramXMLParameter, Map paramMap1, Map paramMap2,
			Map paramMap3, Object paramObject, Exception paramException) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

}
