/**   
 * Copyright © 2017 公司名. All rights reserved.
 * 
 * @Title: AuthorizationException.java 
 * @Prject: treasurebag
 * @Package: com.octopus.tb.sec.exception
 * @Description: TODO
 * @author: ligs   
 * @date: 2017年8月11日 下午3:52:53 
 * @version: V1.0   
 */
package com.octopus.tb.sec.auth.sever.beans;

import com.octopus.tb.sec.exception.AuthorizationErrorCode;

import net.sf.json.JSONObject;

/** 
 * @ClassName: AuthorizationException 
 * @Description: 鉴权结果
 * @author: ligs
 * @date: 2017年8月11日 下午3:52:53  
 */
public class TokenValidateResponse {
    /**
	 * @fieldName: serialVersionUID
	 * @fieldType: long
	 * @Description: TODO
	 */
	
	private boolean resultFlag;
	private TbAccessToken tokenInfo;
    private AuthorizationErrorCode resultCode;
    /**
	 * @return the resultFlag
	 */
	public boolean isResultFlag() {
		return resultFlag;
	}
	/**
	 * @param resultFlag the resultFlag to set
	 */

	public void setResultFlag(boolean resultFlag) {
		this.resultFlag = resultFlag;
	}
	/**
	 * @return the resultCode
	 */
	public AuthorizationErrorCode getResultCode() {
		return resultCode;
	}
	/**
	 * @param resultCode the resultCode to set
	 */
	public void setResultCode(AuthorizationErrorCode resultCode) {
		this.resultCode = resultCode;
	}
	public TbAccessToken getTokenInfo() {
		return tokenInfo;
	}
	public void setTokenInfo(TbAccessToken tokenInfo) {
		this.tokenInfo = tokenInfo;
	}
	@Override
	public String toString() {
		return JSONObject.fromObject(this).toString();
	}
}