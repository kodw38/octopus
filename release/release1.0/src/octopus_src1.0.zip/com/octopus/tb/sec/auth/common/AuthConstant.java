/**   
 * Copyright © 2017 公司名. All rights reserved.
 * 
 * @Title: AuthConstant.java 
 * @Prject: treasurebag
 * @Package: com.octopus.tb.sec.auth
 * @Description: TODO
 * @author: ligs   
 * @date: 2017年8月14日 下午3:42:51 
 * @version: V1.0   
 */
package com.octopus.tb.sec.auth.common;

/** 
 * @ClassName: AuthConstant 
 * @Description: 鉴权相关常量
 * @author: ligs
 * @date: 2017年8月14日 下午3:42:51  
 */
public final class AuthConstant {
	private AuthConstant(){
		throw new IllegalStateException("Utility class");
	}
	//Token的作用域
	public final class TokenScope{
		//只能调用注册的接口
		public static final String PRIVATE = "private";
		//可调用所有平台接口
		public static final String PUBLIC = "public";
	}
	//Token的作用域
	public final class TokenPrivilege{
		//只能调用注册的接口
		public static final String PRIVATE = "private";
		//可调用所有平台接口
		public static final String PUBLIC = "public";
	}
	public final class AuthInfo{
		public static final String ENDPOINT = "endPoint";
		public static final String CREATE_DATE = "createDate";
		public static final String EXPIRE_TIME = "expireTime";
		public static final String CLIENT_ID = "clientId";
		public static final String TOKEN = "token";
	}
	public final class TbAccessToken{
		public static final String SCOPE = "scope";
		public static final String EXPIRE_TIME = "expireTime";
		public static final String ACCESS_TOKEN = "accessToken";
		public static final String PRIVILEGE = "privilege";
		public static final String TOKEN_TYPE = "tokenType";

	}
	public final class AuthRedis{
		public static final String AUTH_REDIS_NAME = "SI";
	}
}
