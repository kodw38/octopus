/**   
 * Copyright © 2017 公司名. All rights reserved.
 * 
 * @Title: AuthorizationErrorCode.java 
 * @Prject: treasurebag
 * @Package: com.octopus.tb.sec.exception
 * @Description: TODO
 * @author: ligs   
 * @date: 2017年8月11日 下午3:13:17 
 * @version: V1.0   
 */
package com.octopus.tb.sec.exception;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


/** 
 * @ClassName: AuthorizationErrorCode 
 * @Description: 鉴权错误code
 * @author: ligs
 * @date: 2017年8月11日 下午3:13:17  
 */
public enum AuthorizationErrorCode {

	MISS_CLIENT_ID("400.004","Bad Request","Missing input parameter: client_id"),
	MISS_CLIENT_SECRET("400.005","Bad Request","Missing input parameter: client_secret"),
	MISS_GRANT_TYPE("400.006","Bad Request","Missing input parameter: grant_type"),
	EXPIRY_TIME_1("400.007","Bad Request","Expiry time cannot be more than 24 hours."),
	EXPIRY_TIME_2("400.008","Bad Request","Expiry time cannot be 0 second or lesser."),
	MISS_AUTHORIZATION("400.009","Bad Request","Missing input parameter: Authorization"),
	//MISS_COMPANY("400.007","Bad Request","Missing input parameter: company"),
	INVALID_CLIENT("401.001","Unauthorized","client_id or client_secret is invalid"),
	UNAUTHORIZED("401.002","Unauthorized","Access token is invalid or expired"),
	INVALID_AUTHORIZATION("401.004","Bad Request","Invalid format of Authorization"),
	INVALID_TOKEN_TYPE("401.005","Bad Request","Unsupport protocol of token"),
	INVALID_GRANT_TYPE("401.006","Bad Request","Unsupport grant_type"),
	INVALID_EXPIRY_TIME("401.007","Bad Request","Invalid Param expires_in"),
	INVALID_RESOURCE("404.003","Resource Not Found","Resource not found/Invalid resource"),
	SYSTEM_ERROR("500.001","Internal Server Error","Internal Server Error");
	
	private String code;
    private String error;
    private String message;
    
	private AuthorizationErrorCode(String code, String error,String message) {
        this.code = code;
        this.error = error;
        this.message = message;
    }
	private static class messageHolder {
		private static Map<String,AuthorizationErrorCode> messages = new HashMap();
		static {
			for(AuthorizationErrorCode v : AuthorizationErrorCode.values()) {
				messages.put(v.getCode(), v);
			}
		}
	}
	public static AuthorizationErrorCode getByCode(String code) {
		return messageHolder.messages.get(code);
	}
	
	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the error
	 */
	public String getError() {
		return error;
	}

	/**
	 * @param error the error to set
	 */
	public void setError(String error) {
		this.error = error;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	
}
