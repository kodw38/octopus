package com.octopus.tb.sec.auth.common;

import com.octopus.tb.sec.exception.AuthorizationErrorCode;

public class SecUtils {

	public static AuthorizationErrorCode getByCode(String code) {
		return AuthorizationErrorCode.getByCode(code);
	}
}
