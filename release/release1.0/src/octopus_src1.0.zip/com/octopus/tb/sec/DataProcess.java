/**   
 * Copyright © 2017 公司名. All rights reserved.
 * 
 * @Title: DataProcess.java 
 * @Prject: treasurebag
 * @Package: com.octopus.tb.sec.auth
 * @Description: TODO
 * @author: ligs   
 * @date: 2017年8月22日 下午3:24:55 
 * @version: V1.0   
 */
package com.octopus.tb.sec;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import com.octopus.utils.common.TBUtils;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;

/** 
 * @ClassName: DataProcess 
 * @Description: TODO
 * @author: ligs
 * @date: 2017年8月22日 下午3:24:55  
 */
public class DataProcess extends XMLDoObject{

	/**
	 * @fieldName: serialVersionUID
	 * @fieldType: long
	 * @Description: TODO
	 */
	private static final long serialVersionUID = 1L;
	@SuppressWarnings("unchecked")
	private static final List<String> encryptAlgorithms = new ArrayList(){
		{add("MD5");add("AES");add("DES");add("RSA");add("3DES");}
	};
	@SuppressWarnings("unchecked")
	private static final List<String> encodeTypes = new ArrayList(){
		{add("BASE64");add("16HEX");}
	};
	private static final String ALGORITHM_MD5 = "MD5";
	private static final String ALGORITHM_AES = "AES";
	private static final String ALGORITHM_DES = "DES";
	private static final String ALGORITHM_RSA = "RSA";
	private static final String ALGORITHM_3DES = "3DES";
	public final static String OP_ENCODE = "encode";
	public final static String DATA = "data";
	
	/** 
	 * @Title:DataProcess
	 * @Description:TODO 
	 * @param xml
	 * @param parent
	 * @throws Exception 
	 */
	public DataProcess(XMLMakeup xml,XMLObject parent,Object[] containers) throws Exception {
		super(xml, parent,containers);
		// TODO Auto-generated constructor stub
	}

    @Override
    public void doInitial() throws Exception {

    }

    /* (non Javadoc)
         * @Title: checkInput
         * @Description: TODO
         * @param paramString
         * @param paramXMLParameter
         * @param paramMap1
         * @param paramMap2
         * @param paramMap3
         * @return
         * @throws Exception
         * @see com.octopus.utils.xml.auto.IXMLDoObject#checkInput(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map)
         */
	@Override
	public boolean checkInput(String paramString, XMLParameter paramXMLParameter, Map paramMap1, Map paramMap2,
			Map paramMap3) throws Exception {
		return true;
	}

	/* (non Javadoc) 
	 * @Title: checkReturn
	 * @Description: TODO
	 * @param paramString
	 * @param paramXMLParameter
	 * @param paramMap1
	 * @param paramMap2
	 * @param paramMap3
	 * @param paramObject
	 * @return
	 * @throws Exception 
	 * @see com.octopus.utils.xml.auto.IXMLDoObject#checkReturn(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map, java.lang.Object)
	 */
	@Override
	public ResultCheck checkReturn(String paramString, XMLParameter paramXMLParameter, Map paramMap1, Map paramMap2,
			Map paramMap3, Object paramObject) throws Exception {
		return new ResultCheck(true, paramObject);
	}

    @Override
    public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception {
        return false;
    }

    /* (non Javadoc)
     * @Title: doSomeThing
     * @Description: TODO
     * @param paramString
     * @param paramXMLParameter
     * @param paramMap1
     * @param paramMap2
     * @param paramMap3
     * @return
     * @throws Exception
     * @see com.octopus.utils.xml.auto.IXMLDoObject#doSomeThing(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map)
     */
	@Override
	public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception {
		String data = (String) input.get(DATA);
		String ops = (String) input.get("op");
		for(String op : ops.split(",")){
			if(OP_ENCODE.equalsIgnoreCase(op)){
				String encryptAlgorithm = (String) input.get(SecConstants.ENCRYT_ALGORITHM);
				String encodeType = (String) input.get(SecConstants.ENCODE_TYPE);
				String encrytKey = (String) input.get(SecConstants.ENCRYT_KEY);
				byte[] encryptData = new byte[0];
				encryptData = encrypt(data,encrytKey,encryptAlgorithm);
				data = encode(encryptData,encodeType);
			}
		}
		return data;
	}
	private byte[] encrypt(String data,String encrytKey,String encryptAlgorithm) throws Exception{
		switch(encryptAlgorithms.indexOf(encryptAlgorithm)){
		case 0 : return MD5Encrypt(data);
		case 1 : return AESEncrypt(data);
		case 3 : return DESEncrypt(data,encrytKey);
		case 4 : return RSAEncrypt(data);
		case 5 : return DES3Encrypt(data,encrytKey);
		default : return data.getBytes("UTF-8");
		}
	}
	private String encode(byte[] ret,String encodeType){
		switch(encodeTypes.indexOf(encodeType)){
		case 0 : return TBUtils.base64Encode(ret);
		case 1 : return TBUtils.byteTo16Hex(ret);
		default : return new String(ret);
	}
	}
	private byte[] MD5Encrypt(String data) throws NoSuchAlgorithmException, UnsupportedEncodingException{
		return MD5.MD5Encrypt(data);
	}
	private byte[] AESEncrypt(String data) throws NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException{
		AES aes = new AES();
		return aes.Encrytor(data);
	}
	private byte[] DESEncrypt(String data,String key) throws Exception{
		return DES.encrypt(data, key);
	}
	private byte[] RSAEncrypt(String data) throws NoSuchAlgorithmException, InvalidKeyException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException{
		RSA rsa = new RSA();
		//公钥
		RSAPublicKey publicKey = rsa.getPublicKey();
		//私钥
		RSAPrivateKey privateKey = rsa.getPrivateKey();
		return rsa.encrypt(publicKey, data);
	}
	private byte[] DES3Encrypt(String data,String key) throws Exception{
		byte[] keyiv = { 1, 2, 3, 4, 5, 6, 7, 8 };
		return DES3.des3EncodeCBC(key, keyiv, data);
	}
	/* (non Javadoc) 
	 * @Title: rollback
	 * @Description: TODO
	 * @param paramString
	 * @param paramXMLParameter
	 * @param paramMap1
	 * @param paramMap2
	 * @param paramMap3
	 * @param paramObject
	 * @param paramException
	 * @return
	 * @throws Exception 
	 * @see com.octopus.utils.xml.auto.IXMLDoObject#rollback(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map, java.lang.Object, java.lang.Exception)
	 */
	@Override
	public boolean rollback(String paramString, XMLParameter paramXMLParameter, Map paramMap1, Map paramMap2,
			Map paramMap3, Object paramObject, Exception paramException) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

	
}
