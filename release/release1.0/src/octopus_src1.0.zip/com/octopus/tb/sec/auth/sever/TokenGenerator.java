/**   
 * Copyright © 2017 公司名. All rights reserved.
 * 
 * @Title: TokenGenerator.java 
 * @Prject: treasurebag
 * @Package: com.octopus.tb.sec.auth
 * @Description: TODO
 * @author: ligs   
 * @date: 2017年8月11日 下午5:18:26 
 * @version: V1.0   
 */
package com.octopus.tb.sec.auth.sever;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.octopus.tb.sec.SecConstants;
import com.octopus.tb.sec.auth.common.AuthConstant;
import com.octopus.tb.sec.auth.sever.beans.TbAccessToken;
import com.octopus.utils.common.TBUtils;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;

/** 
 * @ClassName: TokenGenerator 
 * @Description: Toker生成
 * @author: ligs
 * @date: 2017年8月11日 下午5:18:26  
 */
public class TokenGenerator extends XMLDoObject{

	private XMLDoObject dataProcess;
	private String encrytAlgorithm;
	private String encodeType;
	private String encrytKey;
	/** 
	 * @Title:TokenGenerator
	 * @Description:TODO 
	 * @param xml
	 * @param parent
	 * @param containers
	 * @throws Exception 
	 */
	public TokenGenerator(XMLMakeup xml, XMLObject parent, Object[] containers) throws Exception {
		super(xml, parent, containers);
	}
	public String createToken(String clientId) throws UnsupportedEncodingException, NoSuchAlgorithmException{
		return TBUtils.getRandomUUID()+(StringUtils.isEmpty(clientId)?"":"_"+clientId);
	}
	public String encode(String source) throws Exception {
		Map input = new HashMap();
		input.put("op", "encode");
		input.put("data", source);
		input.put(SecConstants.ENCRYT_ALGORITHM, encrytAlgorithm);
		input.put(SecConstants.ENCODE_TYPE, encodeType);
		input.put(SecConstants.ENCRYT_KEY, encrytKey);
		if(null == dataProcess) {
			dataProcess = (XMLDoObject) getObjectById("DataProcess");
		}
		return (String) dataProcess.doSomeThing(null,null , input, null, null);
	}
	public TbAccessToken getNewToken(String clientId,Integer expiresIn, String privilege, String scope,String tokenType) throws Exception {
		TbAccessToken token = new TbAccessToken();
		token.setAccessToken(encode(createToken(clientId)));
		token.setExpiresIn(expiresIn);
		token.setPrivilege(privilege);
		token.setScope(scope);
		token.setTokenType(tokenType);
        log.info("generator user["+clientId+"] token:"+token.getAccessToken());
		return token;
	}
//	public static String createToken(String clientId,String serviceName){
//		SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;
//		//使用serviceName作为密钥签名
//		byte[] apiKeySecret = DatatypeConverter.parseBase64Binary(serviceName);
//		Key signKey = new SecretKeySpec(apiKeySecret, signatureAlgorithm.getJcaName());
//		
//		JwtBuilder builder = Jwts.builder()
//				.setHeaderParam("typ", "JWT")
//				.setHeaderParam("alg", "HS256")
//				.setPayload(serviceName)
//				.signWith(signatureAlgorithm, signKey);//签名,用HS256加密
//		return builder.compact();		
//	}


    @Override
    public void doInitial() throws Exception {

    }

    /* (non Javadoc)
         * @Title: checkInput
         * @Description: TODO
         * @param arg0
         * @param arg1
         * @param arg2
         * @param arg3
         * @param arg4
         * @return
         * @throws Exception
         * @see com.octopus.utils.xml.auto.IXMLDoObject#checkInput(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map)
         */
	@Override
	public boolean checkInput(String arg0, XMLParameter arg1, Map arg2, Map arg3, Map arg4) throws Exception {
		// TODO Auto-generated method stub
		return true;
	}
	/* (non Javadoc) 
	 * @Title: checkReturn
	 * @Description: TODO
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @param arg3
	 * @param arg4
	 * @param arg5
	 * @return
	 * @throws Exception 
	 * @see com.octopus.utils.xml.auto.IXMLDoObject#checkReturn(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map, java.lang.Object) 
	 */
	@Override
	public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception {
        return new ResultCheck(true,ret);
    }
	/* (non Javadoc) 
	 * @Title: commit
	 * @Description: TODO
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @param arg3
	 * @param arg4
	 * @param arg5
	 * @return
	 * @throws Exception 
	 * @see com.octopus.utils.xml.auto.IXMLDoObject#commit(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map, java.lang.Object) 
	 */
	@Override
	public boolean commit(String arg0, XMLParameter arg1, Map arg2, Map arg3, Map arg4, Object arg5) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}
	/* (non Javadoc) 
	 * @Title: doSomeThing
	 * @Description: TODO
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @param arg3
	 * @param arg4
	 * @return
	 * @throws Exception 
	 * @see com.octopus.utils.xml.auto.IXMLDoObject#doSomeThing(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map) 
	 */
	@Override
	public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception {
		if(null == dataProcess) {
			dataProcess = (XMLDoObject) getObjectById("DataProcess");
		}
		String op = (String) input.get("op");
		Map p = ((Map)env.get("${env}"));
		encrytAlgorithm = (String) p.get("EncrytAlgorithm");
		encodeType = (String) p.get("EncodeType");
		encrytKey = (String) p.get("EncrytKey");
		String expireTime = (String)input.get(AuthConstant.TbAccessToken.EXPIRE_TIME);
		if(StringUtils.isEmpty(expireTime)) {
			expireTime = (String)p.get("TokenExpireTime") ;
		}
		if ("new".equals(op)) {
			return getNewToken((String) input.get(AuthConstant.AuthInfo.CLIENT_ID),Integer.valueOf(expireTime)
					,(String) input.get(AuthConstant.TbAccessToken.PRIVILEGE),(String) input.get(AuthConstant.TbAccessToken.SCOPE),(String) input.get(AuthConstant.TbAccessToken.TOKEN_TYPE));
		}
		return null;
	}
	/* (non Javadoc) 
	 * @Title: rollback
	 * @Description: TODO
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @param arg3
	 * @param arg4
	 * @param arg5
	 * @param arg6
	 * @return
	 * @throws Exception 
	 * @see com.octopus.utils.xml.auto.IXMLDoObject#rollback(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map, java.lang.Object, java.lang.Exception) 
	 */
	@Override
	public boolean rollback(String arg0, XMLParameter arg1, Map arg2, Map arg3, Map arg4, Object arg5, Exception arg6)
			throws Exception {
		// TODO Auto-generated method stub
		return false;
	}
}
