/**   
 * Copyright © 2017 公司名. All rights reserved.
 * 
 * @Title: MD5.java 
 * @Prject: treasurebag
 * @Package: com.octopus.utils.common
 * @Description: TODO
 * @author: ligs   
 * @date: 2017年8月16日 下午4:52:11 
 * @version: V1.0   
 */
package com.octopus.tb.sec;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** 
 * @ClassName: MD5 
 * @Description: 单向加密(信息摘要)
 * @author: ligs
 * @date: 2017年8月16日 下午4:52:11  
 */
public class MD5 {

	/**Determine encrypt algorithm MD5*/
	private static final String ALGORITHM_MD5 = "MD5";
	/**UTF-8 Encoding*/
	private static final String UTF_8 = "UTF-8";
	
	public static final byte[] MD5Encrypt(String readyEncryptStr) throws NoSuchAlgorithmException, UnsupportedEncodingException{
		if(readyEncryptStr != null){
			//Get MD5 digest algorithm's MessageDigest's instance.
			MessageDigest md = MessageDigest.getInstance(ALGORITHM_MD5);
			//Use specified byte update digest.
			md.update(readyEncryptStr.getBytes(UTF_8));
			//Get cipher text
			byte [] b = md.digest();
			//The cipher text converted to hexadecimal string
			return b;
		}else{
			return null;
		}
	}
	
}
