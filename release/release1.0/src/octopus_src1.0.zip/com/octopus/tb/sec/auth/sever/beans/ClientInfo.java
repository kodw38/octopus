/**   
 * Copyright © 2017 公司名. All rights reserved.
 * 
 * @Title: ClientInfo.java 
 * @Prject: treasurebag
 * @Package: com.octopus.tb.sec.auth.beans 
 * @Description: TODO
 * @author: ligs   
 * @date: 2017年12月28日 上午10:30:34 
 * @version: V1.0   
 */
package com.octopus.tb.sec.auth.sever.beans;

import java.util.Date;

import net.sf.json.JSONObject;

/** 
 * @ClassName: ClientInfo 
 * @Description: TODO
 * @author: ligs
 * @date: 2017年12月28日 上午10:30:34  
 */
public class ClientInfo {

	//客户ID
	private String clientId;
	//客户姓名
	private String clientName;
	//客户密码
	private String clientSecret;
	//创建时间
	private Date createDate;
	/**
	 * @return the clientId
	 */
	public String getClientId() {
		return clientId;
	}
	/**
	 * @param clientId the clientId to set
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	/**
	 * @return the clientName
	 */
	public String getClientName() {
		return clientName;
	}
	/**
	 * @param clientName the clientName to set
	 */
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	/**
	 * @return the clientSecret
	 */
	public String getClientSecret() {
		return clientSecret;
	}
	/**
	 * @param clientSecret the clientSecret to set
	 */
	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}
	
	@Override
	public String toString() {
		return JSONObject.fromObject(this).toString();
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
}
