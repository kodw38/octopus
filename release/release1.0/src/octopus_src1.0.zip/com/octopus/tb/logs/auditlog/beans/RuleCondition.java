package com.octopus.tb.logs.auditlog.beans;

import java.util.Map;

public class RuleCondition {
	public static final String S_Id = "id";
	public static final String S_UrlPath = "urlPath";
	public static final String S_Params = "params";
	public static final String S_Method = "method";
	public static final String S_Action = "action";
	public static final String S_Referer = "Referer";
	public static final String S_Properties = "properties";
	
	private Integer id; 
	/**
	 * 请求URL问号前内容
	 */
	private String urlPath;
	
	private Map params;
	/**
	 * 请求方式
	 */
	private String method;
	/**
	 * 请求参数中的action
	 */
	private String action;
	/**
	 * 请求归属页面
	 */
	private String referer;
	/**
	 * 用于存放其他扩展的属性
	 */
	private Map<String,Map<String,String>> properties;
	/**
	 * @return the urlPath
	 */
	public String getUrlPath() {
		return urlPath;
	}
	/**
	 * 
	 * @param urlPath the urlPath to set
	 */
	public void setUrlPath(String urlPath) {
		this.urlPath = urlPath;
	}
	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}
	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}
	public String getReferer() {
		return referer;
	}
	public void setReferer(String referer) {
		this.referer = referer;
	}
	/**
	 * @return the method
	 */
	public String getMethod() {
		return method;
	}
	/**
	 * @param method the method to set
	 */
	public void setMethod(String method) {
		this.method = method;
	}
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * @return the properties
	 */
	public Map<String,Map<String,String>> getProperties() {
		return properties;
	}
	/**
	 * @param properties the properties to set
	 */
	public void setProperties(Map<String,Map<String,String>> properties) {
		this.properties = properties;
	}
	public Map getParams() {
		return params;
	}
	public void setParams(Map params) {
		this.params = params;
	}
	
	
}
