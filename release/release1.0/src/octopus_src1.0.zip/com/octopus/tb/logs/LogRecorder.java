package com.octopus.tb.logs;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import com.octopus.tb.logs.beans.RecordConfig;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLUtil;

public abstract class LogRecorder {
	
	private static class LogConfigHolder{
		private static final String CONFIG_PATH = "funs/auditRulesConfig.xml";
		private static XMLMakeup logConfig;
		private LogConfigHolder() {}
		static {
			try {
				logConfig = XMLUtil.getDataFromStream(Thread.currentThread().getContextClassLoader().getResource(CONFIG_PATH).openStream());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	/**
	 * 
	 * @Title: getConfigXml 
	 * @Description: 根据config-item的key值取配置xml
	 * @param configName
	 * @return
	 * @return: XMLMakeup
	 */
	public static XMLMakeup getConfigXml(String configName) {
		XMLMakeup[] items = LogConfigHolder.logConfig.getChild("logs-config")[0].getChild("config-item");
		if(null != items && items.length > 0) {
			for(XMLMakeup item : items) {
				if(item.getProperties().getProperty("key").equals(configName)) {
					return item;
				}
			}
		}
		return null;
	}
	/**
	 * 
	 * @Title: getRecordConfig 
	 * @Description: 根据config-item的key值取RecordConfig
	 * @param configName
	 * @return
	 * @return: RecordConfig
	 */
	public static RecordConfig getRecordConfig(String configName) {
		return init(getConfigXml(configName));
	}
	/**
	 * 
	 * @Title: init 
	 * @Description: 解析配置文件
	 * @param config
	 * @return
	 * @return: Map
	 */
	protected static RecordConfig init(XMLMakeup configXml) {
		RecordConfig config = new RecordConfig();
		if(null != configXml) {
			if(null != configXml.getChild("method"))
				config.setMethod(configXml.getChild("method")[0].getText());
			if(null != configXml.getChild("filename"))	
				config.setFileName(configXml.getChild("filename")[0].getText());
			if(null != configXml.getChild("split-methods") && null != configXml.getChild("split-methods")[0].getChildren())	{
				Map<String,String> splitMethod = new LinkedHashMap();
					for(Object child : configXml.getChild("split-methods")[0].getChildren()) {
						XMLMakeup method = (XMLMakeup) child;
						splitMethod.put(method.getName(), method.getText());
					}
				config.setSplitMethods(splitMethod);
			}
			if(null != configXml.getChild("encode-type"))	
				config.setEncodeType(configXml.getChild("encode-type")[0].getText());
			if(null != configXml.getChild("title"))	
				config.setTitle(configXml.getChild("title")[0].getText());
		}
		return config;
	}
	/**
	 * 
	 * @Title: record 
	 * @Description: 记录日志方法
	 * @param properties
	 * @return
	 * @return: Boolean
	 */
	public abstract Boolean record();
}

