package com.octopus.tb.logs.auditlog;

public class AuditConstants {

	private AuditConstants() {
	}
	public static final String REQUEST_HEADER_REFERER = "_Referer";
	public static final String SESSION_USER_ID = "USER_ID";
	public static final String SESSION_LOGIN_LOG_ID = "LOGIN_LOG_ID";
}
