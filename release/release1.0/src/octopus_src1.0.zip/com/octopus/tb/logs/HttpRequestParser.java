package com.octopus.tb.logs;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

public class HttpRequestParser {
	public static Request parse() {
		return new Request();
	}
	/**
	 * ����url�ַ���,����utf-8����
	 * 
	 * @param urlString
	 * @return
	 */
	public static Request parse(String urlString) {
		return parse(urlString, "utf-8");
	}
	
	public static Request parse(HttpServletRequest request) {
		return new Request(request);
	}

	/**
	 * ����url�ַ���,ָ���ַ������н���
	 * 
	 * @param urlString
	 * @param enc
	 * @return
	 */
	public static Request parse(String urlString, String enc) {
		if (urlString == null || urlString.length() == 0) {
			return new Request();
		}
		int questIndex = urlString.indexOf('?');
		if (questIndex == -1) {
			return new Request(urlString);
		}
		String url = urlString.substring(0, questIndex);
		String queryString = urlString.substring(questIndex + 1, urlString.length());
		return new Request(url, getParamsMap(queryString, enc));
	}

	private static Map getParamsMap(String queryString, String enc) {
		Map paramsMap = new HashMap();
		if (queryString != null && queryString.length() > 0) {
			int ampersandIndex, lastAmpersandIndex = 0;
			String subStr, param, value;
			String[] paramPair, values, newValues;
			do {
				ampersandIndex = queryString.indexOf('&', lastAmpersandIndex) + 1;
				if (ampersandIndex > 0) {
					subStr = queryString.substring(lastAmpersandIndex, ampersandIndex - 1);
					lastAmpersandIndex = ampersandIndex;
				} else {
					subStr = queryString.substring(lastAmpersandIndex);
				}
				paramPair = subStr.split("=");
				param = paramPair[0];
				value = paramPair.length == 1 ? "" : paramPair[1];
				try {
					value = URLDecoder.decode(value, enc);
				} catch (UnsupportedEncodingException ignored) {
				}
				if (paramsMap.containsKey(param)) {
					values = (String[]) paramsMap.get(param);
					int len = values.length;
					newValues = new String[len + 1];
					System.arraycopy(values, 0, newValues, 0, len);
					newValues[len] = value;
				} else {
					newValues = new String[] { value };
				}
				paramsMap.put(param, newValues);
			} while (ampersandIndex > 0);
		}
		return paramsMap;
	}

	/**
	 * �������
	 * 
	 * @author yy
	 * @date Jun 21, 2009 2:17:31 PM
	 */
	public static class Request {
		private String requestURI;
		private Map parameterMap;
		private String method;
		private Map attribute;
		private byte[] content = {};
		private String queryString;
		private String contextPath;
		private String preUrl;
		private Long userId;
		private Long logId;

		Request() {
			this("");
		}

		Request(HttpServletRequest request) {
			this.requestURI = request.getRequestURL().toString();
			this.parameterMap = request.getParameterMap();
			this.method = request.getMethod();
			try {
				this.content = convertStreamToByte(request.getInputStream());
			} catch (IOException e) {
			}
			this.queryString = request.getQueryString();
			
		}

		Request(String requestURI) {
			this.requestURI = requestURI;
			parameterMap = new HashMap();
		}

		Request(String requestURI, Map parameterMap) {
			this.requestURI = requestURI;
			this.parameterMap = parameterMap;
		}

		private byte[] convertStreamToByte(InputStream in) throws IOException {
			ByteArrayOutputStream bytestream = new ByteArrayOutputStream();
			byte[] buffer = new byte[1024];
			int ch;
			while ((ch = in.read(buffer)) != -1) {
				bytestream.write(buffer, 0, ch);
			}
			byte[] data = bytestream.toByteArray();
			bytestream.close();
			return data;
		}

		/**
		 * ���ָ�����ƵĲ���
		 * 
		 * @param name
		 * @return
		 */
		public String getParameter(String name) {
			String[] values = (String[]) parameterMap.get(name);
			if (values != null && values.length > 0) {
				return values[0];
			}
			return null;
		}

		/**
		 * ������еĲ�������
		 * 
		 * @return
		 */
		public Enumeration getParameterNames() {
			return Collections.enumeration(parameterMap.keySet());
		}

		/**
		 * ���ָ�����ƵĲ���ֵ(���)
		 * 
		 * @param name
		 * @return
		 */
		public String[] getParameterValues(String name) {
			return (String[]) parameterMap.get(name);
		}

		/**
		 * ��������url��ַ
		 * 
		 * @return
		 */
		public String getRequestURI() {
			return requestURI;
		}

		/**
		 * ��� ����-ֵMap
		 * 
		 * @return
		 */
		public Map getParameterMap() {
			return parameterMap;
		}

		public String toString() {
			StringBuffer buf = new StringBuffer();
			buf.append("{");
			buf.append("\n  url = ").append(this.requestURI);
			buf.append("\n  paramsMap = {");
			if (this.parameterMap.size() > 0) {
				Iterator it = this.parameterMap.entrySet().iterator();
				while (it.hasNext()) {
					Map.Entry e = (Map.Entry) it.next();
					buf.append(e.getKey()).append("=").append(Arrays.asList((Object[]) e.getValue()).toString())
							.append(",");
				}
				buf.deleteCharAt(buf.length() - 1);
			}
			buf.append("}\n}");
			return buf.toString();
		}

		public String getMethod() {
			return this.method;
		}

		/*
		 * ���� Javadoc��
		 * 
		 * @see javax.servlet.http.HttpServletRequest#getQueryString()
		 */
		public String getQueryString() {
			return this.queryString;
		}

		public byte[] getContent() {
			return this.content;
		}

		/**
		 * @return the contextPath
		 */
		public String getContextPath() {
			return contextPath;
		}

		/**
		 * @param contextPath the contextPath to set
		 */
		public void setContextPath(String contextPath) {
			this.contextPath = contextPath;
		}

		/**
		 * @return the preUrl
		 */
		public String getPreUrl() {
			return preUrl;
		}

		/**
		 * @param preUrl the preUrl to set
		 */
		public void setPreUrl(String preUrl) {
			this.preUrl = preUrl;
		}

		/**
		 * @return the userId
		 */
		public Long getUserId() {
			return userId;
		}

		/**
		 * @param userId the userId to set
		 */
		public void setUserId(Long userId) {
			this.userId = userId;
		}

		/**
		 * @return the logId
		 */
		public Long getLogId() {
			return logId;
		}

		/**
		 * @param logId the logId to set
		 */
		public void setLogId(Long logId) {
			this.logId = logId;
		}

		/**
		 * @param requestURI the requestURI to set
		 */
		public void setRequestURI(String requestURI) {
			this.requestURI = requestURI;
		}

		/**
		 * @param parameterMap the parameterMap to set
		 */
		public void setParameterMap(Map parameterMap) {
			this.parameterMap = parameterMap;
		}

		/**
		 * @param method the method to set
		 */
		public void setMethod(String method) {
			this.method = method;
		}

		/**
		 * @param queryString the queryString to set
		 */
		public void setQueryString(String queryString) {
			this.queryString = queryString;
		}

	}
}
