package com.octopus.tb.logs.auditlog;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.octopus.tb.logs.auditlog.beans.RuleCondition;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLUtil;

public class RulesManager {
	private static final String PATH = "funs/auditRulesConfig.xml";
	private static Log log = LogFactory.getLog(RulesManager.class);
	private static volatile Map<String,List<RuleCondition>> rules = new HashMap();
	private RulesManager() {
	}
	private static void initRules() {
		try {
				synchronized (rules) {
					if(rules.isEmpty()) {
						rules.putAll(init());
					}
				}
		} catch (IOException e) {
			log.error("init AuditLogConfig XML Exception", e);
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static Map<String,List<RuleCondition>> init() throws IOException{
		Map<String,List<RuleCondition>> rules = new HashMap();
		XMLMakeup ruleConfig = XMLUtil.getDataFromStream(Thread.currentThread().getContextClassLoader().getResource(PATH).openStream());
		XMLMakeup[] ruleItems = ruleConfig.getChild("rules")[0].getChild("item");
		for (XMLMakeup ruleItem : ruleItems) {
			RuleCondition rule = new RuleCondition();
			rule.setId(Integer.valueOf(ruleItem.getProperties().getProperty(RuleCondition.S_Id)));
			rule.setUrlPath(ruleItem.getChild(RuleCondition.S_UrlPath)[0].getText());
			rule.setMethod(ruleItem.getChild(RuleCondition.S_Method)[0].getText());
			
			rule.setReferer(ruleItem.getChild(RuleCondition.S_Referer)[0].getText());
			rule.setProperties(constructProperties(ruleItem));
			
			//解析params
			Map<String,String> params = new HashMap();
			if(null != ruleItem.getChild(RuleCondition.S_Params) && ruleItem.getChild(RuleCondition.S_Params).length > 0) {
				List<XMLMakeup> paramItems = ruleItem.getChild(RuleCondition.S_Params)[0].getChildren();
				for (XMLMakeup paramItem : paramItems) {
					params.put(paramItem.getName(), paramItem.getText());
				}
			}
			
			rule.setParams(params);
			//连接字符串作为主键
			String mapKey = null;
			String refererPath = "";
			String urlPath = "";
			//将accessPageID转换为字符串路径
			try {
				urlPath = rule.getUrlPath();
				refererPath = null == rule.getReferer()?"":rule.getReferer();
				//构造键名
				mapKey = urlPath + "_" + refererPath;
			} catch (Exception e) {
				log.error("read auditLog ruleConfig wrong,referer:"+rule.getId(),e);
				continue;
			}
			if (rules.containsKey(mapKey)) {
				rules.get(mapKey).add((rule));
			}
			else {
				List<RuleCondition> v = new ArrayList();
				v.add(rule);
				rules.put(mapKey, v);
			}
		}
		return rules;
	}
	public static Map<String,Map<String,String>> constructProperties(XMLMakeup rule){
		Map<String,Map<String,String>> properties = new HashMap();
		List<XMLMakeup> children = rule.getChildren();
		for(XMLMakeup child : children) {
			Map<String,String> childProperties = new HashMap();
			if(!child.getProperties().isEmpty()) {
				for(Entry childPropertie : child.getProperties().entrySet()) {
					childProperties.put((String)childPropertie.getKey(), (String)childPropertie.getValue());
				}
			}
			properties.put(child.getName(), childProperties);
		}
		return properties;
	}
	public static Map<String,List<RuleCondition>> getAuditRules() {
		if(rules.isEmpty()){
			initRules();
		}
		return rules;
	}
	public static List<RuleCondition> getAuditRule(String key) {
		return getAuditRules().get(key);
	}
	public static void main(String[] args) {
		String[] keys = "a.b.c".split("\\.");
		String value = "";
		Map bodyJson = new HashMap();
		bodyJson.put("c", "1");
		Map bodyJson1 = new HashMap();
		bodyJson1.put("b", bodyJson);
		Map bodyJson2 = new HashMap();
		bodyJson2.put("a", bodyJson1);
		Map child = bodyJson2;
		for(String key : keys) {
			Object v = child.get(key);
			if(null != v) {
				if(v instanceof Map) {
					child = (Map)v;
					continue;
				}else if(v.getClass().isArray()){
					value = Arrays.toString((Object[])v);
					break;
				}else if(Collection.class.isAssignableFrom(v.getClass())){
					value = Arrays.toString(((Collection)v).toArray());
					break;
				}else {
					value = String.valueOf(v);
					break;
				}
			}else {
				value = "";
				break;
			}
		}
		System.out.println(value);
	}
}