/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: AuditLogAction.java 
 * @Prject: treasurebag
 * @Package: com.octopus.tb.logs.auditlog 
 * @Description: TODO
 * @author: ligs   
 * @date: 2019年2月22日 下午2:33:11 
 * @version: V1.0   
 */
package com.octopus.tb.logs.auditlog;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.octopus.isp.ds.RequestParameters;
import com.octopus.tb.logs.auditlog.beans.RuleCondition;
import com.octopus.utils.alone.ObjectUtils;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import com.sun.xml.internal.ws.wsdl.writer.document.soap.Header;

import net.sf.json.JSONObject;


/** 
 * @ClassName: AuditLogAction 
 * @Description: TODO
 * @author: ligs
 * @date: 2019年2月22日 下午2:33:11  
 */
public class AuditLogAction extends XMLDoObject{
	/**
	 * @fieldName: serialVersionUID
	 * @fieldType: long
	 * @Description: TODO
	 */
	private static final long serialVersionUID = 1L;
	public XMLDoObject logHandler;
	private static final Log logger = LogFactory.getLog(AuditLogAction.class);
	private static Logger loggerA;
//	private static final ThreadPoolExecutor exe = new ThreadPoolExecutor(1, 5, 300, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());

	public AuditLogAction(XMLMakeup xml, XMLObject parent,Object[] containers) throws Exception {
		super(xml, parent, containers);
	}
	@Override
	public boolean checkInput(String arg0, XMLParameter arg1, Map arg2, Map arg3, Map arg4) throws Exception {
		return true;
	}

	@Override
	public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret)
			throws Exception {
		return new ResultCheck(true, ret);
	}

	@Override
	public boolean commit(String arg0, XMLParameter arg1, Map arg2, Map arg3, Map arg4, Object arg5) throws Exception {
		return false;
	}

	@Override
	public void doInitial() throws Exception {
		
	}
	private String getRefererRequest(RequestParameters request,String key) {
		String referer = request.getHeader(null == key?"Referer":key);
		return null==referer?"":referer.replaceAll("(http|https):\\/\\/[\\w\\-_]+(\\.[\\w\\-_]+)*(\\:?\\d*\\/[^\\/]+)", "");
	}
	
	@Override
	public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception {
		logger.debug("AuditLog start");
		RequestParameters par = (RequestParameters)env;
		HttpServletRequest request = (HttpServletRequest)env.get("${request}");
		boolean flag = false;
		try {
			logger.debug("AuditLog request:"+com.alibaba.fastjson.JSON.toJSONString(par.getRequestProperties()));

			//			String url = request.getRequestURI().replaceFirst(request.getContextPath(), "");
			String url = par.getRequestURI().replaceFirst((String)par.getRequestProperties().get("ContextPath"), "");
			String referer = getRefererRequest(par,(String) config.get("RefererKey"));
			String key = url+"_"+(referer.indexOf('?')>0?referer.substring(0,referer.indexOf('?')):referer);
			logger.debug("AuditLog key:"+key);
			List<RuleCondition> rules = RulesManager.getAuditRules().get(key);
			boolean isParamsMatch = false;
			if(null != rules) {
				logger.debug("AuditLog matched rules");
				Map<String,String> paramMap = par.getQueryStringMap();
				for(RuleCondition rule: rules) {
					boolean isParamMatch = true;
					if(!rule.getParams().isEmpty()) {
						Set<Entry<String,String>> set = rule.getParams().entrySet();
						for(Entry<String,String> e : set) {
							String k = e.getKey();
							String v = null == e.getValue()?"":e.getValue();
							if(StringUtils.isNotBlank(k) && !v.equals(paramMap.get(k))) {
								isParamMatch = false;
								break;
							}
						}
						if(isParamMatch) {
							logger.debug("AuditLog matched rule"+ rule.getId());
							isParamsMatch = true;
							break;
						}
					}else {
						isParamsMatch = true;
						break;
					}
				}
				if(!isParamsMatch) {
					return false;
				}
				Map requestInfo = new HashMap();
				Map rp = par.getRequestProperties();
				Map header = null;
				if(null !=  par.get("${requestHeaders}")) {
					header = JSONObject.fromObject((Map) par.get("${requestHeaders}"));
				}
				requestInfo.put("header", header);
				requestInfo.put("requestURI", par.getRequestURI().toString());
				requestInfo.put("scheme", rp.get("Scheme"));
				requestInfo.put("referer", referer);
				requestInfo.put("contextPath", rp.get("ContextPath"));
				requestInfo.put("serverName", rp.get("ServerName"));
				requestInfo.put("serverPort", rp.get("ServerPort"));
				requestInfo.put("method", rp.get("Method"));
				requestInfo.put("queryString", par.getQueryString());
				requestInfo.put("datas", input);
				Map params = new HashMap();
				params.put("requestInfo", requestInfo);
				if(null != config && null != config.get("logHandler")) {
					XMLDoObject logHandler = (XMLDoObject) getObjectById((String) config.get("logHandler"));
					if(null != logHandler) {
						logger.debug("AuditLog start Invoke handle:"+config.get("logHandler"));
						if(null != config.get("recordMethod")) {
							RequestParameters daa = new RequestParameters();
	                        daa.setRequestData(params);
	                        daa.setSession(par.getSession());
	                        daa.setTargetNames(new String[]{(String) config.get("logHandler")});
	                        daa.put("^${input}",params);
							logHandler.doThing(daa, null);
							Object rsp = daa.getResult();
							logger.debug("Auditlog recording content:"+JSON.toJSONString(rsp));
							if(rsp instanceof ResultCheck && null != ((ResultCheck)rsp).getRet()) {
								String content = (String) ((ResultCheck)rsp).getRet();
								logger.debug("Auditlog recording content:"+content);
								if(StringUtils.isNotEmpty(content) && "log4j".equals(config.get("recordMethod"))) {
									Logger appender = getAppender((String) config.get("appender"));
									appender.error(content);
									logger.debug("Auditlog record Success");
								}
							}
						}
	//					exe.execute(new AuditLogRunnable(handler, params, config));
						flag = true;
					}else {
						logger.error("AuditLog Invoke handler:"+config.get("logHandler")+" not exist");
					}
				}else {
					logger.error("AuditLog Invoke handler not config");
				}
			}
		}catch (Exception e) {
			log.error("AuditLog Exception",e);
		}
		return flag;
	}
	
	private static Logger getAppender(String appenderName) {
		if(null == loggerA) {
			loggerA = Logger.getLogger(appenderName);
		}
		return loggerA;
	}
//	public class AuditLogRunnable implements Runnable {
//		private XMLDoObject handler;
//		private Map params;
//		private Map config;
//		public AuditLogRunnable(XMLDoObject handler,Map params,Map config) {
//			this.handler = handler;
//			this.params = params;
//			this.config = config;
//		}
//		@Override
//		public void run() {
//			try {
//				if(null != config.get("recordMethod")) {
//					String content = (String) handler.doSomeThing(null, null, params, null, null);
////					String content = "456561000002||1||100073||Query||12476028||-110||2019-03-01 17:38:36||||||||||STR = ssada;IDNumber = 1111asd";
//					logger.error("Auditlog recording content:"+content);
//					if(StringUtils.isNotEmpty(content)) {
//						if("log4j".equals(config.get("recordMethod"))) {
//							Logger loggerA = Logger.getLogger((String) config.get("appender"));
//							loggerA.error(content);
//							logger.error("Auditlog record Success");
//						}
//					}
//				}
//				logger.error("Auditlog record execute finished");
//			} catch (Exception e) {
//				logger.error("Auditlog record Failed",e);
//			}
//		}
//	}
	
	@Override
	public boolean rollback(String arg0, XMLParameter arg1, Map arg2, Map arg3, Map arg4, Object arg5, Exception arg6)
			throws Exception {
		return false;
	}

}
