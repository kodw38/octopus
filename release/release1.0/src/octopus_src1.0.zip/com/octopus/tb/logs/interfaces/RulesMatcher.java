package com.octopus.tb.logs.interfaces;

public interface RulesMatcher {
	public RulesMatcher setRule(Object rule);
	public Boolean match();

}
