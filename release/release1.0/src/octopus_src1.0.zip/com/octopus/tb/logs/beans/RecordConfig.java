package com.octopus.tb.logs.beans;

import java.util.List;
import java.util.Map;

public class RecordConfig {

	private String method;
	private String fileName;
	private Map<String,String> splitMethods;
	private String encodeType;
	private String title;
	/**
	 * @return the method
	 */
	public String getMethod() {
		return method;
	}
	/**
	 * @param method the method to set
	 */
	public void setMethod(String method) {
		this.method = method;
	}
	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}
	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * @return the encodeType
	 */
	public String getEncodeType() {
		return encodeType;
	}
	/**
	 * @param encodeType the encodeType to set
	 */
	public void setEncodeType(String encodeType) {
		this.encodeType = encodeType;
	}
	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return the splitMethods
	 */
	public Map<String,String> getSplitMethods() {
		return splitMethods;
	}
	/**
	 * @param splitMethods the splitMethods to set
	 */
	public void setSplitMethods(Map<String,String> splitMethods) {
		this.splitMethods = splitMethods;
	}

}
