package com.octopus.isp.tools;

public abstract interface IDataGet
{
  public abstract Object getData(String paramString, Object paramObject)
    throws Exception;
}