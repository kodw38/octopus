package com.octopus.isp.ds;

import com.octopus.utils.alone.ArrayUtils;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.XMLParameter;

public class Contexts extends XMLObject
{
  public Contexts(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void notifyObject(String op, Object obj)
    throws Exception
  {
  }

  public void destroy()
    throws Exception
  {
  }

  public void initial()
    throws Exception
  {
  }

  public Context getContext(RequestParameters requestData)
  {
    XMLMakeup xs = (XMLMakeup)ArrayUtils.getFirst(getXML().getChild("context"));
    return ((Context)XMLParameter.newInstance(xs, Context.class, requestData.getRequestData(), true, this));
  }
}