package com.octopus.isp.ds;

import com.octopus.tools.i18n.II18N;
import com.octopus.utils.time.DateTimeUtils;
import com.octopus.utils.xml.auto.XMLParameter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Context extends XMLParameter
{
  II18N i18n;
  SimpleDateFormat systemtime;
  Locale locale;

  public Context()
  {
    this.systemtime = null;
    this.locale = null; }

  public Locale getLocale() { if ((null == this.locale) && 
      (null != getParameter("session.user.language")))
      this.locale = new Locale((String)getParameter("session.user.language"));

    if (null != this.locale)
      return this.locale;

    return Locale.CHINESE;
  }

  public String getSystemDate(long time)
  {
    try {
      if ((this.systemtime == null) && (null != getParameter("session.user.datetimestyle")))
        this.systemtime = DateTimeUtils.getDateFormat((String)getParameter("session.user.datetimestyle"), getLocale());

      if (null != this.systemtime)
        return DateTimeUtils.getZoneTime(this.systemtime, new Date(time));

      return DateTimeUtils.getCurrDateTime();
    } catch (Exception e) {
      e.printStackTrace();

      return null; }
  }

  public String getSystemDate() {
    return getSystemDate(new Date().getTime());
  }

  public II18N getI18n()
  {
    return this.i18n;
  }
}