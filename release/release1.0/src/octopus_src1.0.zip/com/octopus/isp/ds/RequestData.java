package com.octopus.isp.ds;

import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.auto.XMLParameter;

public class RequestData extends XMLParameter
{
  XMLMakeup client;
}