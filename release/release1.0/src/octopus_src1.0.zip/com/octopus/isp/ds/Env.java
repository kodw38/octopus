package com.octopus.isp.ds;

import com.octopus.utils.flow.FlowParameters;

public class Env extends FlowParameters
{
  public static String KEY_HOME = "Home";
}