package com.octopus.isp.ds;

import com.octopus.isp.bridge.launchers.impl.pageframe.SessionManager;
import com.octopus.utils.flow.FlowParameters;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class RequestParameters extends FlowParameters
{
  public static String KEY_REQUESTID = "RequestId";
  Env env;
  Context context = null;
  Session session = null;
  ClientInfo clientInfo = new ClientInfo();
  Hashtable<String, String> requestHeaders = new Hashtable();
  Hashtable<String, String> requestCookies = new Hashtable();
  String requestRUL = null;
  String requestURI = null;
  String queryString = null;
  HashMap queryStringMap = null;
  Object requestData = null;
  Date requestDate = null;
  String requestId = null;
  String[] targetNames;
  HashMap requestProperties = new HashMap();
  String instanceid;

  public String getInstanceid()
  {
    return this.instanceid;
  }

  public void setInstanceid(String instanceid) {
    this.instanceid = instanceid;
  }

  public RequestParameters() {
    addParameter("${clientInfo}", this.clientInfo);
    addParameter("${requestHeaders}", this.requestHeaders);
    addParameter("${requestCookies}", this.requestCookies);
    addParameter("${requestProperties}", this.requestProperties); }

  public HashMap getRequestProperties() {
    return this.requestProperties;
  }

  public void setRequestProperties(HashMap requestProperties) {
    addParameter("${requestProperties}", requestProperties);
  }

  public void addRequestProperties(String key, Object value) {
    this.requestProperties.put(key, value); }

  public String getRequestURI() {
    return ((String)getParameter("${requestURI}"));
  }

  public void setRequestURI(String requestURI) {
    addParameter("${requestURI}", requestURI);
  }

  public void setRequestResourceName(String name) {
    addParameter("${requestResourceName}", name);
  }

  public String getRequestResourceName() {
    return ((String)getParameter("${requestResourceName}"));
  }

  public Hashtable getRequestHeaders() {
    return ((Hashtable)getParameter("${requestHeaders}"));
  }

  public void setRequestHeaders(Hashtable requestHeaders) {
    addParameter("${requestHeaders}", requestHeaders);
  }

  public Hashtable<String, String> getRequestCookies() {
    return ((Hashtable)getParameter("${requestHeaders}"));
  }

  public void setRequestCookies(Hashtable requestHeaders) {
    addParameter("${requestCookies}", requestHeaders);
  }

  public HashMap getQueryStringMap() {
    return ((HashMap)getParameter("${queryStringMap}"));
  }

  public void setQueryStringMap(HashMap queryStringMap) {
    addParameter("${queryStringMap}", queryStringMap);
  }

  public Object getRequestData()
  {
    return getInputParameter();
  }

  public void setRequestData(Object requestData) {
    setInputParameter(requestData);
  }

  public Date getRequestDate() {
    return ((Date)getParameter("${requestDate}"));
  }

  public void setRequestDate(Date requestDate) {
    addParameter("${requestDate}", requestDate);
  }

  public String getRequestId() {
    return ((String)getParameter("${requestId}"));
  }

  public void setRequestId(String requestId) {
    addParameter("${requestId}", requestId);
  }

  public void setRequestDataSize(long size) {
    addParameter("${requestDataSize}", Long.valueOf(size)); }

  public long getRequestDataSize() {
    Object o = getParameter("${requestDataSize}");
    if (null != o)
      return ((Long)o).longValue();

    return 0L;
  }

  public void setResponseDataSize(long size) {
    addParameter("${responseDataSize}", Long.valueOf(size)); }

  public long getResponseDataSize() {
    Object o = getParameter("${responseDataSize}");
    if (null != o)
      return ((Long)o).longValue();

    return 0L;
  }

  public Env getEnv()
  {
    return ((Env)getStaticParameter("${env}"));
  }

  public void setEnv(Env env) {
    addStaticParameter("${env}", env);
  }

  public Context getContext() {
    return ((Context)getParameter("${context}"));
  }

  public void setContext(Context context) {
    addParameter("${context}", context);
  }

  public void setConstant(Map constant) {
    addGlobalParameter("${constant}", constant); }

  public void setSessionManager(SessionManager sessionManager) {
    addStaticParameter("${sessionManager}", sessionManager); }

  public static SessionManager getSessionManager() {
    return ((SessionManager)getStaticParameter("${sessionManager}")); }

  public Session getSession() {
    return ((Session)getParameter("${session}"));
  }

  public void setSession(Session session) {
    addParameter("${session}", session);
  }

  public String getRequestURL()
  {
    return ((String)getParameter("${requestURL}"));
  }

  public void setRequestURL(String requestURL) {
    addParameter("${requestURL}", requestURL);
  }

  public String getQueryString() {
    return ((String)getParameter("${queryString}"));
  }

  public void setQueryString(String queryString) {
    addParameter("${queryString}", queryString);
  }

  public void addClientInfo(String key, String value) throws IOException {
    this.clientInfo.put(key, value);
  }

  public ClientInfo getClientInfo() {
    return ((ClientInfo)getParameter("${clientInfo}"));
  }

  public void addHeader(String key, String value) throws IOException {
    this.requestHeaders.put(key, value); }

  public void addAllHeader(Map map) throws IOException {
    this.requestHeaders.putAll(map); }

  public String getHeader(String key) {
    return ((String)this.requestHeaders.get(key));
  }
}