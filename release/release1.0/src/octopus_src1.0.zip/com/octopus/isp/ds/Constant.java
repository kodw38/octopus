package com.octopus.isp.ds;

import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class Constant extends XMLObject
{
  static transient Log log = LogFactory.getLog(Constant.class);
  Map ret;

  public Constant(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void notifyObject(String op, Object obj)
    throws Exception
  {
  }

  public void destroy()
    throws Exception
  {
  }

  public void initial() throws Exception
  {
  }

  public Map getConstant()
  {
    if (null != this.ret)
      return this.ret;
    try
    {
      XMLMakeup xs = getXML().getFirstChildrenEndWithName("constants");
      if (null != xs) {
        this.ret = xs.toMap();
        return this.ret;
      }
      return null;
    }
    catch (Exception e) {
      log.error("", e);

      return null;
    }
  }
}