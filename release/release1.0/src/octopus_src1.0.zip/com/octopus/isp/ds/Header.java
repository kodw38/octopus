package com.octopus.isp.ds;

import com.octopus.utils.xml.auto.XMLParameter;

public class Header extends XMLParameter
{
}