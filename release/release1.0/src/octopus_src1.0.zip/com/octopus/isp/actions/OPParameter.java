package com.octopus.isp.actions;

import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import java.util.Map;
import org.apache.commons.lang.StringUtils;

public class OPParameter extends XMLDoObject
{
  public OPParameter(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    if (null != input) {
      String op = (String)input.get("op");
      if (StringUtils.isNotBlank(op)) {
        if ((op.equals("add")) && (StringUtils.isNotBlank((String)input.get("key"))) && (null != input.get("value")))
          env.addParameter("${" + ((String)input.get("key")) + "}", input.get("value"));
        if ((op.equals("set")) && (StringUtils.isNotBlank((String)input.get("key"))) && (null != input.get("value")))
          env.addParameter((String)input.get("key"), input.get("value"));
        else if ("clearAll".equals(op))
          env.getReadOnlyParameter().clear();
      }
    }

    return null;
  }

  public void doInitial()
    throws Exception
  {
  }

  public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    return true;
  }

  public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return new ResultCheck(true, ret);
  }

  public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return false;
  }

  public boolean rollback(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret, Exception e) throws Exception
  {
    return false;
  }
}