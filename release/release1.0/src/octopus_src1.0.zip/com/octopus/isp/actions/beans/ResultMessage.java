package com.octopus.isp.actions.beans;

public class ResultMessage
{
  private String resultCode;
  private Object resultMessage;

  public ResultMessage(String resultCode, Object resultMessage)
  {
    this.resultCode = resultCode;
    this.resultMessage = resultMessage;
  }

  public String getResultCode()
  {
    return this.resultCode;
  }

  public void setResultCode(String resultCode)
  {
    this.resultCode = resultCode;
  }

  public Object getResultMessage()
  {
    return this.resultMessage;
  }

  public void setResultMessage(String resultMessage)
  {
    this.resultMessage = resultMessage;
  }

  public static enum ResultCode
  {
    SUCCESS, FAILED;
  }
}