package com.octopus.isp.actions;

import com.octopus.utils.si.jvm.JVMUtil;
import com.octopus.utils.si.jvm.MBeanManager;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import com.sun.management.GarbageCollectorMXBean;
import com.sun.management.HotSpotDiagnosticMXBean;
import com.sun.management.OperatingSystemMXBean;
import com.sun.management.UnixOperatingSystemMXBean;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import javax.management.*;
import java.lang.management.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

//import com.sun.management.ThreadMXBean;

public class GetJvmInfo extends XMLDoObject{

	/**
	 * @fieldName: serialVersionUID
	 * @fieldType: long
	 * @Description: TODO
	 */
	private static final long serialVersionUID = 1L;
	private static final String FLAG_ALL = "0";
	private static final String FLAG_BLOCKED = "1";
	public GetJvmInfo(XMLMakeup xml, XMLObject parent,Object[] containers) throws Exception {
		super(xml, parent,containers);
	}

    @Override
    public void doInitial() throws Exception {

    }

    @Override
	public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception {
		if(null == input)
			return false;
		return true;
	}

	@Override
	public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception {
		return new ResultCheck(true, ret);
	}

    @Override
    public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception {
        return false;
    }


    @SuppressWarnings("rawtypes")
	@Override
	public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception {
		String op = (String) input.get("op");
		Map ret = new HashMap();
		MBeanManager mBeanManager = JVMUtil.checkJMXConnect(input);
		if(null == mBeanManager){
			log.error("cannot get jmxrmi connection");
			return ret;
		}
		//获取所有MBean操作列表
		if("getMBeanInfos".equalsIgnoreCase(op)){
			ret.put("mBeanInfos", getMBeanInfos(mBeanManager));
		}
		//获取MBean详细信息
		else if("getMBeanInfoDtl".equalsIgnoreCase(op)){
			ret.put("mBeanInfoDtl", getMBeanInfoByName(mBeanManager, input.get("objectName")));
		}
		//获取死锁线程
		else if("getDeadLockThread".equalsIgnoreCase(op)){
			List<Map> lockThreads = getDeadLockedThreadInfos(mBeanManager.getThreadMXBean());
			ret.put("deadLockThreadInfos", JSONArray.fromObject(lockThreads));
		}
		else if("getOSMXBean".equalsIgnoreCase(op)){
			Map osMXBean = getSystemInfo(mBeanManager.getOperatingSystemMXBean());
			ret.put("osMXBean", osMXBean);
		}
		else if("getClassLoadMXBean".equalsIgnoreCase(op)){
			Map classLoadMXBean = getClassLoadingInfo(mBeanManager.getClassLoadingMXBean());
			ret.put("classLoadMXBean", classLoadMXBean);

		}
		else if("getCompilationMXBean".equalsIgnoreCase(op)){
			Map compilationMXBean = getCompilationInfo(mBeanManager.getCompilationMXBean());
			ret.put("compilationMXBean", compilationMXBean);

		}
		else if("getGcMXBean".equalsIgnoreCase(op)){
			List<Map> gcMXBean =getGarbageCollectorInfo(mBeanManager.getGarbageCollectorMXBean());
			ret.put("gcMXBean", JSONArray.fromObject(gcMXBean));

		}
		else if("getMemoryMXBean".equalsIgnoreCase(op)){
			Map memoryMXBean =getJvmMemoryInfo(mBeanManager.getMemoryMXBean());
			ret.put("memoryMXBean", memoryMXBean);

		}
		else if("getRuntimeMXBean".equalsIgnoreCase(op)){
			Map runtimeMXBean = getRuntimeInfo(mBeanManager.getRuntimeMXBean());
			ret.put("runtimeMXBean", runtimeMXBean);

		}
		else if("getThreadMXBean".equalsIgnoreCase(op)){
			Map threadMXBean = getThreadInfo(mBeanManager.getThreadMXBean());
			ret.put("threadMXBean", threadMXBean);

		}
		else if("getThreadMXBeanDtl".equalsIgnoreCase(op)){
			String threadId = (String) input.get("threadId");
			if (threadId == null || threadId.length() == 0) {
				List threadMXBeanDtl = getAllThreadDtlInfos(mBeanManager.getThreadMXBean());
				ret.put("threadMXBeanDtl", JSONArray.fromObject(threadMXBeanDtl));
			}else{
				Map threadMXBeanDtl = getAllThreadDtlInfo(mBeanManager.getThreadMXBean(),Long.valueOf(threadId));
				ret.put("threadMXBeanDtl", threadMXBeanDtl);
			}
		}
		else if("getThreadMXBeanBasic".equalsIgnoreCase(op)){
			String flag = (String) input.get("flag");
			List threadMXBeanBasic = getAllThreadBasicInfos(mBeanManager.getThreadMXBean(),flag);
			ret.put("threadMXBeanBasic", JSONArray.fromObject(threadMXBeanBasic));
		}
		else if("getDynamicInfo".equalsIgnoreCase(op)){
			Map classLoadMXBean = getClassLoadingInfo(mBeanManager.getClassLoadingMXBean());
			Map memoryMXBean =getJvmMemoryInfo(mBeanManager.getMemoryMXBean());
			Map threadMXBean = getThreadInfo(mBeanManager.getThreadMXBean());
			Map osMXBean = copyKV(getSystemInfo(mBeanManager.getOperatingSystemMXBean()),new HashMap(),new String[]{"osCores","processCpuTime"});
			//Map classLoadMXBeanNew = copyKV(classLoadMXBean,new HashMap(),new String[]{"osCores","processCpuTime"});
			//Map memoryMXBeanNew = copyKV(memoryMXBean,new HashMap(),new String[]{"osCores","processCpuTime"});
			//Map threadMXBeanNew = copyKV(threadMXBean,new HashMap(),new String[]{"osCores","processCpuTime"});
			Map runtimeMXBean = copyKV(getRuntimeInfo(mBeanManager.getRuntimeMXBean()),new HashMap(),new String[]{"upTime","startTime"});

			ret.put("osMXBean",osMXBean);
			ret.put("runtimeMXBean",runtimeMXBean);
			ret.put("classLoadMXBean",classLoadMXBean);
			ret.put("memoryMXBean",memoryMXBean);
			ret.put("threadMXBean",threadMXBean);
		}
		else if("getVMInfo".equalsIgnoreCase(op)){
			Map memoryMXBean =copyKV(getJvmMemoryInfo(mBeanManager.getMemoryMXBean()),new HashMap(),new String[]{"heapUsed","heapMax","heapCommitted"});
			Map threadMXBean = getThreadInfo(mBeanManager.getThreadMXBean());
			Map osMXBean = copyKV(getSystemInfo(mBeanManager.getOperatingSystemMXBean()),new HashMap(),new String[]{"osCores","osName","osArch","osVersion"});
			//Map classLoadMXBeanNew = copyKV(classLoadMXBean,new HashMap(),new String[]{"osCores","processCpuTime"});
			//Map memoryMXBeanNew = copyKV(memoryMXBean,new HashMap(),new String[]{"osCores","processCpuTime"});
			//Map threadMXBeanNew = copyKV(threadMXBean,new HashMap(),new String[]{"osCores","processCpuTime"});
			Map runtimeMXBean = getRuntimeInfo(mBeanManager.getRuntimeMXBean());

			ret.put("osMXBean",osMXBean);
			ret.put("runtimeMXBean",runtimeMXBean);
			ret.put("memoryMXBean",memoryMXBean);
			ret.put("threadMXBean",threadMXBean);
		}
		//获取基本信息操作
		else{
			try{
				Map osMXBean = getSystemInfo(mBeanManager.getOperatingSystemMXBean());
				Map classLoadMXBean = getClassLoadingInfo(mBeanManager.getClassLoadingMXBean());
				Map compilationMXBean = getCompilationInfo(mBeanManager.getCompilationMXBean());
				List<Map> gcMXBean =getGarbageCollectorInfo(mBeanManager.getGarbageCollectorMXBean());
				Map memoryMXBean =getJvmMemoryInfo(mBeanManager.getMemoryMXBean());
				Map runtimeMXBean = getRuntimeInfo(mBeanManager.getRuntimeMXBean());
				Map threadMXBean = getThreadInfo(mBeanManager.getThreadMXBean());
				List threadMXBeanDtl = getAllThreadDtlInfos(mBeanManager.getThreadMXBean());
				ret.put("osMXBean", osMXBean);
				ret.put("classLoadMXBean", classLoadMXBean);
				ret.put("compilationMXBean", compilationMXBean);
				ret.put("gcMXBean", JSONArray.fromObject(gcMXBean));
				ret.put("memoryMXBean", memoryMXBean);
				ret.put("runtimeMXBean", runtimeMXBean);
				ret.put("threadMXBean", threadMXBean);
				ret.put("threadMXBeanDtl", JSONArray.fromObject(threadMXBeanDtl));
			}catch (Exception e) {
				log.error("getJvmInfo failed",e);
			}
		}
		return ret;
	}

	/**
	 *
	 * @param srcMap
	 * @param targetMap
	 * @param keys
     * @return
     */
	private Map copyKV(Map srcMap,Map targetMap,String[] keys){
		if(null != keys){
			for (String k:keys) {
				targetMap.put(k,srcMap.get(k));
			}
		}
		return targetMap;
	}

	@Override
	public boolean rollback(String xmlid, XMLParameter env, Map input, Map output, Map config,Object ret,Exception e) throws Exception {
		return false;
	}
	/**
	 * 
	 * @Title: getCompilationInfo 
	 * @Description: 获取编译信息
	 * @param compilation
	 * @return
	 * @return: Map
	 */
	private Map getCompilationInfo(CompilationMXBean compilation){ 
		 log.info("-----getCompilationInfo-----");
		 Map ret = new HashMap();
	     ret.put("compilationName", compilation.getName());
	   //判断jvm是否支持编译时间的监控  
	     if(compilation.isCompilationTimeMonitoringSupported())
	    	 ret.put("totalCompilationTime", compilation.getTotalCompilationTime());
	     return ret;
	}  
	/**
	 * 
	 * @Title: getGarbageCollectorInfo 
	 * @Description: 获取GC信息
	 * @param garbageList
	 * @return
	 * @return: Map
	 */
	private List<Map> getGarbageCollectorInfo(List<GarbageCollectorMXBean> garbageList){
    	log.info("-----getGarbageCollectorInfo-----");
    	List<Map>ret = new ArrayList();
    	for(GarbageCollectorMXBean garbage : garbageList){
    		Map retDtl = new HashMap();
	        retDtl.put("collectionCount", garbage.getCollectionCount());
	        retDtl.put("collectionTime", garbage.getCollectionTime());
	        retDtl.put("MemoryPoolNames", JSONArray.fromObject(garbage.getMemoryPoolNames()));
            try {
                retDtl.put("lastGcInfo", JSONArray.fromObject(garbage.getLastGcInfo()));
            }catch (Exception e){}
                retDtl.put("name", garbage.getName());
	        ret.add(retDtl);
    	}
        return ret;
    }  
	/**
	 * 
	 * @Title: getThreadInfo 
	 * @Description: 获取线程信息
	 * @param threads
	 * @return
	 * @return: Map
	 */
	private Map getThreadInfo(ThreadMXBean threads){
    	log.info("-----getThreadInfo-----");
        if(null != threads) {
            Map ret = new HashMap();
            //仍活动的线程总数
            ret.put("threadsCount", threads.getThreadCount());
            //当初仍活动的守护线程
            ret.put("threadsDaemon", threads.getDaemonThreadCount());
            //峰值
            ret.put("threadsPeak", threads.getPeakThreadCount());
            //线程总数（被创建并执行过的线程总数）
            ret.put("startedThreadCount", threads.getTotalStartedThreadCount());
            return ret;
        }
        return null;
    }
	/**
	 * 
	 * @Title: getDeadLockedThreadInfos 
	 * @Description: 检查是否有死锁的线程存在 
	 * @param thread
	 * @return
	 * @return: Map
	 */
	private List<Map> getDeadLockedThreadInfos(ThreadMXBean thread){
    	log.info("-----getDeadLockedThreadInfos-----");
		List<Map> ret =  new ArrayList();
		long[] deadlockedIds =  thread.findDeadlockedThreads();
	    if(deadlockedIds != null && deadlockedIds.length > 0){  
	    	ThreadInfo[] deadlockInfos = thread.getThreadInfo(deadlockedIds);
	        for(ThreadInfo deadlockInfo : deadlockInfos){
	        	Map retDtl = new HashMap();
	            retDtl.put("threadId", deadlockInfo.getThreadId());
	            retDtl.put("threadName", deadlockInfo.getThreadName());
	            retDtl.put("threadState", deadlockInfo.getThreadState());
	            retDtl.put("blockedTime", deadlockInfo.getBlockedTime());
	            retDtl.put("waitedTime", deadlockInfo.getWaitedTime());
	            retDtl.put("stackTrace", getStackTraceInfos(deadlockInfo));
	            if(null != deadlockInfo.getLockInfo())
	            	retDtl.put("lockInfo", deadlockInfo.getLockInfo().toString());
	            if(thread.isThreadCpuTimeSupported())
	                retDtl.put("cpuTime", thread.getThreadCpuTime(deadlockInfo.getThreadId()));
	            ret.add(retDtl);
	        }  
	    }
	    return ret;   
	}
	/**
	 * 
	 * @Title: getAllThreadDtlInfos 
	 * @Description:获取所有详细线程信息
	 * @param thread
	 * @return
	 * @return: List<Map>
	 */
	private List<Map> getAllThreadDtlInfos(ThreadMXBean thread){
    	log.info("-----getAllThreadDtlInfos-----");
        List<Map> ret = new ArrayList();
        if(null != thread) {
            long[] threadIds = thread.getAllThreadIds();
            if (threadIds != null && threadIds.length > 0) {
                //获取带堆栈信息的线程信息深度为10
                ret = getAllThreadDtlInfos(thread, threadIds);
            }
        }
        return ret;
    }
	private Map getAllThreadDtlInfo(ThreadMXBean thread, long id) {
		List<Map> infos = getAllThreadDtlInfos(thread, new long[]{id});
		if(infos.size()>0) {
			return infos.get(0);
		}
		return new HashMap();
	}

	private List<Map> getAllThreadDtlInfos(ThreadMXBean thread, long[] id) {
		log.info("-----getAllThreadDtlInfos-----");
		List<Map> ret = new ArrayList();
		if (null != thread) {
				//获取带堆栈信息的线程信息深度为10
			ThreadInfo[] threadInfos = thread.getThreadInfo(id, 10);
			for(ThreadInfo threadInfo : threadInfos) {
				if(null != threadInfo) {
					Map retDtl = new HashMap();
					retDtl.put("waitedCount", threadInfo.getWaitedCount());
					retDtl.put("waitedTime", threadInfo.getWaitedTime());
					retDtl.put("blockedCount", threadInfo.getBlockedCount());
					retDtl.put("blockedTime", threadInfo.getBlockedTime());
					retDtl.put("threadId", threadInfo.getThreadId());
					retDtl.put("threadName", threadInfo.getThreadName());
					retDtl.put("stackTrace", getStackTraceInfos(threadInfo));
					retDtl.put("threadState", threadInfo.getThreadState().toString());
					if(null != threadInfo.getLockInfo())
						retDtl.put("lockInfo", threadInfo.getLockInfo().toString());
					if (thread.isThreadCpuTimeSupported())
						retDtl.put("cpuTime", thread.getThreadUserTime(threadInfo.getThreadId()));
					ret.add(retDtl);
				}
			}
		}
		return ret;
	}

	private List<Map> getAllThreadBasicInfos(ThreadMXBean thread,String flag){
		log.info("-----getAllThreadDtlInfos-----");
		List<Map> ret = new ArrayList();
		if(null != thread) {
			long[] threadIds = null;
			//获取所有线程信息
			if(null == flag || flag.length() == 0 
					|| FLAG_ALL.equals(flag)) {
				threadIds = thread.getAllThreadIds();
			}
			//获取死锁线程信息
			else if(FLAG_BLOCKED.equals(flag)) {
				threadIds =  thread.findDeadlockedThreads();
			}
			if (threadIds != null && threadIds.length > 0) {
				//获取带堆栈信息的线程信息深度为10
				ThreadInfo[] threadInfos = thread.getThreadInfo(threadIds, 0);
				for (ThreadInfo threadInfo : threadInfos) {
					Map retBasic = new HashMap();
					retBasic.put("threadId", threadInfo.getThreadId());
					retBasic.put("threadName", threadInfo.getThreadName());
					ret.add(retBasic);
				}
			}
		}
		return ret;
	}
	/**
	 * 
	 * @Title: getThreadDtlInfo 
	 * @Description: 获取单个线程信息
	 * @param threadId
	 * @param thread
	 * @return
	 * @return: Map
	 */
    private Map getThreadDtlInfo(long threadId,ThreadMXBean thread){
    	log.info("-----getThreadDtlInfo-----");
    	Map ret = new HashMap();
    	ThreadInfo threadInfo = thread.getThreadInfo(threadId);
    	ret.put("threadId", threadInfo.getThreadId());
    	ret.put("threadName", threadInfo.getThreadName());
    	ret.put("threadState", threadInfo.getThreadState());
    	ret.put("blockedTime", threadInfo.getBlockedTime());
    	ret.put("waitedTime", threadInfo.getWaitedTime());
    	ret.put("stackTrace", getStackTraceInfos(threadInfo));
    	ret.put("lockInfo", threadInfo.getLockInfo().toString());
    	ret.put("cpuTime", thread.getThreadCpuTime(threadId));
    	return ret;
    }
    /**
     * 
     * @Title: getStackTraceInfos 
     * @Description: 获取线程堆栈信息
     * @param threadInfo
     * @return
     * @return: List
     */
    private List getStackTraceInfos(ThreadInfo threadInfo){
    	List ret = new ArrayList<String>();
    	for(StackTraceElement element : threadInfo.getStackTrace()){
    		ret.add(element.toString());
    	}
    	return ret;
    }
    /**
     * 
     * @Title: getActiveThreadCount 
     * @Description: 获得线程总数
     * @return
     * @return: int
     */
    private int getActiveThreadCount(){
    	
        ThreadGroup parentThread;
        for (parentThread = Thread.currentThread().getThreadGroup(); parentThread
                .getParent() != null; parentThread = parentThread.getParent());
        return parentThread.activeCount();
    }
    /**
     * 
     * @Title: getSystemInfo 
     * @Description: 获取操作系统信息
     * @param os
     * @return
     * @return: Map
     */
    private Map getSystemInfo(OperatingSystemMXBean os){  
  		log.info("-----getSystemInfo-----");
  		Map ret = new HashMap();
  		//系统名称
  		ret.put("osName", os.getName());
  		//系统版本
  		ret.put("osVersion", os.getVersion());
  		//操作系统的架构
  		ret.put("osArch", os.getArch());
  		//可用内核数
  		ret.put("osCores", os.getAvailableProcessors());
        try {
            ret.put("systemLoadAverage", os.getSystemLoadAverage());
        }catch(Exception e){}
        try {
            ret.put("systemCpuLoad", os.getSystemCpuLoad());
        }catch (Exception e){}
        try {

            ret.put("processCpuLoad", os.getProcessCpuLoad());
        }catch (Exception e){}
  		//cpu占用时间
  		try{
        ret.put("processCpuTime", os.getProcessCpuTime());
        }catch (Exception e){}
        //已提交虚拟内存
  		try{
        ret.put("committedVirtualMemory", os.getCommittedVirtualMemorySize());
        }catch (Exception e){}
        //空闲物理内存
  		try{
        ret.put("freePhysicalMemory", os.getFreePhysicalMemorySize());
        }catch (Exception e){}
        //空闲交换区空间
  		try{
        ret.put("freeSwapSpace", os.getFreeSwapSpaceSize());
        }catch (Exception e){}
        //总物理内存
  		try{
        ret.put("totalPhysicalMemory", os.getTotalPhysicalMemorySize());
        }catch (Exception e){}
        //总交换区空间
  		try{
            ret.put("totalSwapSpace", os.getTotalSwapSpaceSize());
        }catch (Exception e){}
  		return ret;
  	 }
  	 /**
  	  * 
  	  * @Title: getClassLoadingInfo 
  	  * @Description: 获取类加载信息
  	  * @param classLoad
  	  * @return
  	  * @return: Map
  	  */
    private Map getClassLoadingInfo(ClassLoadingMXBean classLoad){
		 Map ret = new HashMap();
	     ret.put("totalLoadedClassCount", classLoad.getTotalLoadedClassCount());
	     ret.put("loadedClassCount", classLoad.getLoadedClassCount());
	     ret.put("unloadedClassCount", classLoad.getUnloadedClassCount());
	     return ret;
    }
    /**
     * 
     * @Title: getJvmMemoryInfo 
     * @Description: 获取JVM内存信息
     * @param mem
     * @return
     * @return: Map
     */
  	private Map getJvmMemoryInfo(MemoryMXBean mem){
			log.info("-----getJvmMemoryInfo-----");
	    	Map ret = new HashMap();
	    	ret.put("heapUsed", mem.getHeapMemoryUsage().getUsed());
	    	ret.put("heapMax", mem.getHeapMemoryUsage().getMax());
	    	ret.put("heapCommitted", mem.getHeapMemoryUsage().getCommitted());
	    	ret.put("heapCompare", mem.getHeapMemoryUsage().getUsed()*100/mem.getHeapMemoryUsage().getCommitted());
	    	ret.put("nonHeapUsed", mem.getNonHeapMemoryUsage().getUsed());
	    	ret.put("nonHeapMax", mem.getNonHeapMemoryUsage().getMax());
	    	ret.put("nonHeapCommitted", mem.getNonHeapMemoryUsage().getCommitted());
	    	ret.put("nonHeapCompare", mem.getNonHeapMemoryUsage().getUsed()*100/mem.getNonHeapMemoryUsage().getCommitted());
	    	return ret;
	    }
  	 /**
  	  * 
  	  * @Title: getRuntimeInfo 
  	  * @Description: 获取运行时信息
  	  * @param runtime
  	  * @return
  	  * @return: Map
  	  */
  	 private Map getRuntimeInfo(RuntimeMXBean runtime){
  		log.info("-----getRuntimeInfo-----");
    	Map ret = new HashMap();
    	ret.put("vmName", runtime.getVmName());
    	ret.put("vmVersion", runtime.getVmVersion());
    	ret.put("vmVendor", runtime.getVmVendor());
    	ret.put("startTime", runtime.getStartTime());
    	ret.put("upTime", runtime.getUptime());
    	ret.put("specName", runtime.getSpecName());
    	ret.put("specVendor", runtime.getSpecVendor());
    	ret.put("specVersion", runtime.getSpecVersion());
    	ret.put("managementSpecVersion", runtime.getManagementSpecVersion());
    	//返回由引导类加载器用于搜索类文件的引导类路径
    	ret.put("bootClassPath", runtime.getBootClassPath());
    	//返回系统类加载器用于搜索类文件的 Java 类路径
    	ret.put("classPath", runtime.getClassPath());
    	//返回传递给 Java 虚拟机的输入变量
    	ret.put("inputArguments", runtime.getInputArguments());
    	//返回 Java 库路径
    	ret.put("libraryPath", runtime.getLibraryPath());
    	return ret;
  	 }
  	 private Map getUnixOperatingSystemMXBean(UnixOperatingSystemMXBean unixOS){
  		log.info("-----getUnixOperatingSystemMXBean-----");
    	Map ret = new HashMap();
    	return ret;
  	 }
  	private Map getHotSpotDiagnosticMXBean(HotSpotDiagnosticMXBean hotSpot){
  		log.info("-----getHotSpotDiagnosticMXBean-----");
    	Map ret = new HashMap();
  		ret.put("specVersion", JSONArray.fromObject(hotSpot.getDiagnosticOptions()));
  		return ret;
  	 }
  	//在前端计算
  	 private double getCpuRatio(com.sun.management.OperatingSystemMXBean opMXbean){
  		Long start = System.currentTimeMillis();  
        long startT = opMXbean.getProcessCpuTime();  
        /**    Collect data every 5 seconds      */  
        try {
            TimeUnit.SECONDS.sleep(1);  
        } catch (InterruptedException e) {  
            log.error("InterruptedException occurred while MemoryCollector sleeping...");  
        }  
        Long end = System.currentTimeMillis();  
        long endT = opMXbean.getProcessCpuTime();  
        double ratio = (endT-startT)/1000000.0/(end-start)/opMXbean.getAvailableProcessors();
        return ratio;
  	 }
  	 /**
  	  * 
  	  * @Title: getMBeanInfoByName 
  	  * @Description: 通过objectName获得MBean详细信息
  	  * @param mBeanManager
  	  * @param objNameStr
  	  * @return
  	  * @return: JSONObject
  	  */
  	 private JSONObject getMBeanInfoByName(MBeanManager mBeanManager,Object objNameStr){
  		 JSONObject ret = new JSONObject();
  		 try {
  			 if(null != objNameStr 
  					 && String.class.isAssignableFrom(objNameStr.getClass())
  					 && ((String)objNameStr).trim().length()>0){
				ObjectName objName = new ObjectName((String)objNameStr);
				ret = constructMBeanInfo(mBeanManager.getMBeanInfo(objName), objName);
  			 }
		} catch (Exception e) {
			log.error(e.getMessage());
			e.printStackTrace();
		} 
  		 return ret;
  	 }
  	 /**
  	  * 
  	  * @Title: getMBeanInfos 
  	  * @Description: 获取MBean目录
  	  * @param mBeanManager
  	  * @return
  	  * @return: JSONObject
  	  */
  	 private JSONObject getMBeanInfos(MBeanManager mBeanManager){
  		JSONObject catalog = new JSONObject();
  		try{
	  		Set<ObjectInstance> mbeans = mBeanManager.getMBean(null);
			for(Iterator<ObjectInstance> it = mbeans.iterator();it.hasNext();){
				try{
					ObjectInstance obj = it.next();
					MBeanInfo info = mBeanManager.getMBeanInfo(obj.getObjectName());
					String canonicalName = obj.getObjectName().getCanonicalName();
					String catalogName = null;
					//添加一个目录
					if(null == catalog.get(catalogName = canonicalName.trim().split(":")[0])){
						catalog.put(catalogName,new JSONObject());
					}
					JSONObject json = new JSONObject();
					if(canonicalName.indexOf('"')>0)
						canonicalName = canonicalName.replace("\"", "&#34");
					json.put("objectName", canonicalName);
					json.put("className", info.getClassName());
					json.put("description", info.getDescription());
					//构造次级目录目前只有两层结构,mBeanMap的Value如果只有一级目录为对象，有两级目录为数组
					String type = null;
					//有二级目录
					if(isHaveChildCatalog(obj.getObjectName())){
						String name = null;
						JSONObject childCatalog = (JSONObject)catalog.get(catalogName);
						String[] canArray = canonicalName.trim().split(",");
						Arrays.sort(canArray, new Comparator<String>() {
							@Override
							public int compare(String o1, String o2) {
								String o1Type = o1.split("=")[0];
								String o2Type = o2.split("=")[0];
								if("type".equalsIgnoreCase(o1Type)
										|| "name".equalsIgnoreCase(o2Type))
									return 1;
								if("name".equalsIgnoreCase(o1Type)
										|| "type".equalsIgnoreCase(o2Type))
									return -1;
								return 0;
							}
						});
						//倒序遍历每个键值对
						//指向每次循环当前目录的最小层级
						JSONObject temp = new JSONObject();
						for(int i = canArray.length-1;i>=0;i--){
							String value = canArray[i].split("=")[1].trim();
							if(i == 0){
								json.put("mBeanName", value);
								temp.put(value, json);
								break;
							}
							if(i == canArray.length-1){
								if(null == childCatalog.get(value)){
									childCatalog.put(value, new JSONObject());
									temp = (JSONObject) childCatalog.get(value);
									continue;
								}
								else{
									temp = (JSONObject) childCatalog.get(value);
									continue;
								}
							}
							if(null == temp.get(value)){
								temp.put(value, new JSONObject());
							}
							temp = (JSONObject) temp.get(value);
						}
//						name = canArray[0].trim().split("=")[1];
//						type = canArray[1].trim().split("=")[1];
//						if(null != name && null != type){
//							if(null == secCatalog.get(type)){
//								secCatalog.put(type, new JSONArray());
//							}
//							json.put("mBeanName", name);
//							((JSONArray)secCatalog.get(type)).add(json);
//						}
					}
					//不包含二级目录
					else{
						type = canonicalName.trim().split("=")[1];
						json.put("mBeanName", type);
						((JSONObject)catalog.get(catalogName)).put(type, json);
					}
				}catch (Exception e) {
					log.error("-------getMBeanInfos falied-------- : "+e.getCause().toString());
					e.printStackTrace();
					continue;
				}
			}
		}catch (Exception e) {
			log.error("-------getMBeanInfos falied-------- : "+e.getCause().toString());
			e.printStackTrace();
		}
		return catalog;
  	 }
  	 private boolean isHaveChildCatalog(ObjectName objName){
  		 if(objName.getCanonicalName().contains(",")&&objName.getCanonicalName().split("=").length>2){
  			 return true;
  		 }
  		 return false;
  	 }
  	 /**
  	  * 
  	  * @Title: constructMBeanInfo 
  	  * @Description: 构造MBean详细参数
  	  * @param info
  	  * @param objName
  	  * @return
  	  * @return: JSONObject
  	  */
  	 private JSONObject constructMBeanInfo(MBeanInfo info,ObjectName objName){
  		JSONObject json = new JSONObject();
  		if(null != info){
			JSONArray notifyJsonArray = new JSONArray();
			for(MBeanNotificationInfo notification : info.getNotifications()){
				JSONObject notifyJson = new JSONObject();
				notifyJson.put("description", notification.getDescription());
				notifyJson.put("descriptor", getDescriptorJson(notification.getDescriptor()));
				notifyJson.put("name", notification.getName());
				notifyJson.put("notifTypes", JSONArray.fromObject(notification.getNotifTypes()));
				notifyJsonArray.add(notifyJson);
			}
			JSONArray attrJsonArray = new JSONArray();
			for(MBeanAttributeInfo attribute : info.getAttributes()){
				JSONObject attrJson = new JSONObject();
				//针对是type是个数组类型使用unicode转码
				attrJson.put("type", attribute.getType().replace("[", "&#91;"));
				attrJson.put("description", attribute.getDescription());
				attrJson.put("name", attribute.getName());
				attrJson.put("descriptor", getDescriptorJson(attribute.getDescriptor()));
				attrJsonArray.add(attrJson);
			}
			JSONArray constrJsonArray = new JSONArray();
			for(MBeanConstructorInfo constr : info.getConstructors()){
				JSONObject constrJson = new JSONObject();
				constrJson.put("signature", JSONArray.fromObject(constr.getSignature()));
				constrJson.put("description", constr.getDescription());
				constrJson.put("name", constr.getName());
				constrJson.put("descriptor", getDescriptorJson(constr.getDescriptor()));
				constrJsonArray.add(constrJson);
			}
			json.put("objectName", objName.getCanonicalName());
			json.put("notifications", notifyJsonArray);
			json.put("attributes", attrJsonArray);
			json.put("constructors", constrJsonArray);
			json.put("className", info.getClassName());
			json.put("description", info.getDescription());
			json.put("descriptor",JSONObject.fromObject(info.getDescriptor()));
			if(null != info.getOperations()&&info.getOperations().length>0){
				JSONArray OperJsonArray = new JSONArray();
				for(MBeanOperationInfo oper : info.getOperations()){
					JSONObject operJson = new JSONObject();
					operJson.put("signature", getSignatureJson(oper.getSignature()));
					operJson.put("description", oper.getDescription());
					operJson.put("name", oper.getName());
					operJson.put("impact", oper.getImpact());
					operJson.put("returnType",oper.getReturnType().replace("[", "&#91;"));
					//描述信息不一定需要,内容太多，且包含特殊字符,暂时不取
					//operJson.put("descriptor", getDescriptorJson(oper.getDescriptor()));
					OperJsonArray.add(operJson);
				}
				json.put("operations", OperJsonArray);
			}
  		}
		return json;
  	 }
  	 private JSONArray getSignatureJson(MBeanParameterInfo[] signatureArray){
  		 JSONArray signJsonArray = new JSONArray();
  		 for(MBeanParameterInfo signature : signatureArray){
  			JSONObject signJson = new JSONObject();
  			signJson.put("name", signature.getName());
  			signJson.put("type", signature.getType().replace("[", "&#91;"));
  			signJson.put("description", signature.getDescription());
  			signJson.put("descriptor", getDescriptorJson(signature.getDescriptor()));
  			signJsonArray.add(signJson);
  		 }
  		 return signJsonArray;
  	 }
  	 private JSONObject getDescriptorJson(Descriptor descriptor){
  		JSONObject descriptorJson = new JSONObject();
  		descriptorJson.put("fieldNames", JSONArray.fromObject(descriptor.getFieldNames()));
  		//fieldValue可能包含特殊字符，需要unicode
  		JSONArray json = JSONArray.fromObject(descriptor.getFields());
  		if(json.size()>0){
  			for(int i=0;i<json.size();i++){
  				if(String.class.isAssignableFrom(json.get(i).getClass())){
  					String value = (String)json.get(i);
  					if(value.contains("[")||value.contains("]")||value.contains("\n")){
  						json.set(i, value.replace("[", "&#91;").replace("]", "&#93;").replace("\n", "\\n"));
  					}
  				}
  			}
  	 	}
		descriptorJson.put("fields", json);
		return descriptorJson;
  	 }
     //check update
}
