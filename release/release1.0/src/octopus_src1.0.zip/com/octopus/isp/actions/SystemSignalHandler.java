package com.octopus.isp.actions;

import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.logic.XMLLogic;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import sun.misc.Signal;
import sun.misc.SignalHandler;

public class SystemSignalHandler extends XMLLogic
  implements SignalHandler
{
  static transient Log log = LogFactory.getLog(SystemSignalHandler.class);

  public SystemSignalHandler(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void handle(Signal signal)
  {
    log.info("when be killed and destroy sub app :");
    try {
      doThing(getEmptyParameter(), getXML());
    } catch (Exception e) {
      log.error("clear system when be killed error", e);
    } finally {
      System.exit(0);
    }
  }

  public void doInitial() throws Exception
  {
    log.info("register signal TERM handel " + getClass().getName());
    Signal.handle(new Signal("TERM"), this);
  }
}