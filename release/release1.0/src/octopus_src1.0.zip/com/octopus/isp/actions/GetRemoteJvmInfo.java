package com.octopus.isp.actions;

import com.octopus.utils.si.jvm.SSHExcuteCommandHelper;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.logging.Log;

public class GetRemoteJvmInfo extends XMLDoObject
{
  private static final long serialVersionUID = 623593285L;
  static final String INPUT_OP = "op";
  static final String INPUT_INSID = "insid";
  private SSHExcuteCommandHelper sshExcuteCommandHelper;

  public GetRemoteJvmInfo(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void doInitial()
    throws Exception
  {
  }

  public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config)
    throws Exception
  {
    return ((null != input) && (null != input.get("op")) && (null != input.get("insid")));
  }

  public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config)
    throws Exception
  {
    String op = (String)input.get("op");
    String insId = (String)input.get("insid");
    String pid = null;
    Map ret = new HashMap();
    if ("getRemoteInfo".equalsIgnoreCase(op))
    {
      Map instanceInfo = new HashMap();
      instanceInfo.put("ip", "10.11.20.115");
      instanceInfo.put("loginuser", "aitasksit");
      instanceInfo.put("loginpwd", "aitasksit115");
      log.info("instanceInfo : " + instanceInfo);
      if (null == instanceInfo) {
        log.error("Not exist instance named : " + insId);
        return null;
      }

    }

    return ret;
  }

  public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return new ResultCheck(true, ret);
  }

  public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return false;
  }

  public boolean rollback(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret, Exception e) throws Exception
  {
    return false;
  }
}