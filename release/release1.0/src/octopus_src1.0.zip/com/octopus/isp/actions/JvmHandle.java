package com.octopus.isp.actions;

import com.alibaba.fastjson.JSONObject;
import com.octopus.isp.actions.beans.ResultMessage;
import com.octopus.isp.actions.beans.ResultMessage.ResultCode;
import com.octopus.utils.si.jvm.JVMUtil;
import com.octopus.utils.si.jvm.MBeanManager;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import java.lang.management.MemoryMXBean;
import java.util.List;
import java.util.Map;
import javax.management.ObjectName;
import net.sf.json.JSONArray;

public class JvmHandle extends XMLDoObject
{
  private static final long serialVersionUID = 1761432880L;

  public JvmHandle(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void doInitial()
    throws Exception
  {
  }

  public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config)
    throws Exception
  {
    if (!(commonCheck(input)))
      return false;
    if ("mBeanInvoke".equalsIgnoreCase((String)input.get("op")))
      return checkMBeanInvoke(input);
    return true;
  }

  public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret)
    throws Exception
  {
    return new ResultCheck(true, ret);
  }

  public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return false;
  }

  public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config)
    throws Exception
  {
    String op = (String)input.get("op");
    ResultMessage ret = new ResultMessage(ResultMessage.ResultCode.SUCCESS.toString(), op + " Done");
    MBeanManager mBeanManager = JVMUtil.checkJMXConnect(input);
    if (null == mBeanManager)
      return new ResultMessage(ResultMessage.ResultCode.FAILED.toString(), "cannot get jmxrmi connection");
    try {
      if ("gc".equalsIgnoreCase(op))
        gc(mBeanManager);

      if ("mBeanInvoke".equalsIgnoreCase(op))
        mBeanInvoke(mBeanManager, (String)input.get("objectName"), (String)input.get("operationName"), (Object[])(Object[])input.get("params"), (String[])(String[])input.get("signature"));
    }
    catch (Exception e)
    {
      return new ResultMessage(ResultMessage.ResultCode.FAILED.toString(), e.getMessage());
    }
    return ret;
  }

  public boolean rollback(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret, Exception e) throws Exception
  {
    return false;
  }

  private void gc(MBeanManager mBeanManager) {
    mBeanManager.getMemoryMXBean().gc(); }

  private Object mBeanInvoke(MBeanManager mBeanManager, String objectName, String operationName, Object[] params, String[] signature) {
    ObjectName mbeanName;
    try { mbeanName = new ObjectName(objectName);
      Object obj = mBeanManager.mBeanMethodInvoke(mbeanName, operationName, params, signature);
      if ((List.class.isAssignableFrom(obj.getClass())) || (obj.getClass().isArray()))
      {
        return new ResultMessage(ResultMessage.ResultCode.SUCCESS.toString(), JSONArray.fromObject(obj));
      }

      return new ResultMessage(ResultMessage.ResultCode.SUCCESS.toString(), JSONObject.toJSON(obj));
    } catch (Exception e) {
      return new ResultMessage(ResultMessage.ResultCode.FAILED.toString(), e.getMessage());
    }
  }

  private boolean checkMBeanInvoke(Map input)
  {
    return ((null != input.get("mBeanName")) && (null != input.get("operationName")));
  }

  private boolean commonCheck(Map input)
  {
    return ((null != input) && (null != input.get("host")) && (null != input.get("op")));
  }
}