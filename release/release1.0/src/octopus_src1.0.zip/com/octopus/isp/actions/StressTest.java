package com.octopus.isp.actions;

import com.alibaba.otter.canal.example.StringUtils;
import com.octopus.utils.thread.ExecutorUtils;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import java.util.List;
import java.util.Map;

public class StressTest extends XMLDoObject
{
  public StressTest(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void doInitial()
    throws Exception
  {
  }

  public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    return true;
  }

  public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    if (null != input) {
      int tc = Integer.parseInt((String)input.get("tc"));

      long dl = 0L;
      if ((StringUtils.isNotBlank((String)input.get("dl"))) && (StringUtils.isNumeric((String)input.get("dl"))))
        dl = Long.valueOf((String)input.get("dl")).longValue();

      int times = 0;
      if ((StringUtils.isNotBlank((String)input.get("times"))) && (StringUtils.isNumeric((String)input.get("times"))))
        times = Integer.valueOf((String)input.get("times")).intValue();

      String action = (String)input.get("action");
      Map actioninput = (Map)input.get("actionInput");
      Map copyFields = (Map)input.get("copyFields");
      copyFields = env.getMapValueFromParameter(copyFields, this);
      if (StringUtils.isNotBlank(action)) {
        XMLObject o = getObjectById(action);
        if (null != o) {
          if ((dl > 0L) && (tc > 0))
            ExecutorUtils.stressWork(tc, dl * 60L, o, "doThing", actioninput, new Class[] { XMLParameter.class, XMLMakeup.class, List.class }, new Object[] { env, o.getXML(), copyFields });

          if ((tc > 0) && (times > 0)) {
            long l = ExecutorUtils.stressWork(tc, times, o, "doThing", actioninput, new Class[] { XMLParameter.class, XMLMakeup.class, List.class }, new Object[] { env, o.getXML(), copyFields });
            return "{costtime:" + l + "}";
          }
        }
      }
    }
    return Boolean.valueOf(true);
  }

  public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return new ResultCheck(true, ret);
  }

  public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return false;
  }

  public boolean rollback(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret, Exception e) throws Exception
  {
    return false;
  }
}