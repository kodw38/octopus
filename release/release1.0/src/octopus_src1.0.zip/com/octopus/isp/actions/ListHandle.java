package com.octopus.isp.actions;

import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class ListHandle extends XMLDoObject
{
  private static final String DUPLICATE_REMOVAL = "duplicateRemoval";
  private static final String NEW = "new";
  private static final String ADD = "add";

  public ListHandle(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void doInitial()
    throws Exception
  {
  }

  public boolean checkInput(String paramString, XMLParameter paramXMLParameter, Map paramMap1, Map paramMap2, Map paramMap3)
    throws Exception
  {
    return true;
  }

  public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret)
    throws Exception
  {
    return new ResultCheck(true, ret);
  }

  public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return false;
  }

  public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config)
    throws Exception
  {
    String op = (String)input.get("op");

    List list = (List)input.get("list");

    Object val = input.get("val");
    if ("new".equalsIgnoreCase(op))
      return new LinkedList();

    if (null != list) {
      if ("duplicateRemoval".equalsIgnoreCase(op))
        return duplicateRemoval((String)val, list);
      if ("add".equalsIgnoreCase(op))
        return addParameter(val, list);
    }

    return null;
  }

  private List duplicateRemoval(String sign, List list) {
    Iterator it = list.iterator();
    Map newMap = new HashMap();
    while (it.hasNext()) {
      Map map = (Map)it.next();
      newMap.put(map.get(sign), map);
    }
    return new ArrayList(newMap.values()); }

  private List addParameter(Object val, List list) {
    if (null != val)
      if (List.class.isAssignableFrom(val.getClass()))
        list.addAll((List)val);
      else
        list.add(val);


    return list;
  }

  public boolean rollback(String paramString, XMLParameter paramXMLParameter, Map paramMap1, Map paramMap2, Map paramMap3, Object paramObject, Exception paramException)
    throws Exception
  {
    return false;
  }
}