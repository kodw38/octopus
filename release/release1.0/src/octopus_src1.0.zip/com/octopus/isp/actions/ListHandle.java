/**   
 * Copyright © 2017 公司名. All rights reserved.
 * 
 * @Title: ListHandle.java 
 * @Prject: treasurebag
 * @Package: com.octopus.isp.actions
 * @Description: TODO
 * @author: ligs   
 * @date: 2017年8月31日 下午4:42:24 
 * @version: V1.0   
 */
package com.octopus.isp.actions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;

/** 
 * @ClassName: ListHandle 
 * @Description: TODO
 * @author: ligs
 * @date: 2017年8月31日 下午4:42:24  
 */
public class ListHandle extends XMLDoObject {

	private static final String DUPLICATE_REMOVAL = "duplicateRemoval";
	private static final String NEW = "new";
	private static final String ADD = "add";
	/** 
	 * @Title:ListHandle
	 * @Description:TODO 
	 * @param xml
	 * @param parent
	 * @throws Exception 
	 */
	public ListHandle(XMLMakeup xml,XMLObject parent,Object[] containers) throws Exception {
		super(xml, parent,containers);
		// TODO Auto-generated constructor stub
	}

    @Override
    public void doInitial() throws Exception {

    }

    /* (non Javadoc)
         * @Title: checkInput
         * @Description: TODO
         * @param paramString
         * @param paramXMLParameter
         * @param paramMap1
         * @param paramMap2
         * @param paramMap3
         * @return
         * @throws Exception
         * @see com.octopus.utils.xml.auto.IXMLDoObject#checkInput(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map)
         */
	@Override
	public boolean checkInput(String paramString, XMLParameter paramXMLParameter, Map paramMap1, Map paramMap2,
			Map paramMap3) throws Exception {
		// TODO Auto-generated method stub
		return true;
	}

	/* (non Javadoc) 
	 * @Title: checkReturn
	 * @Description: TODO
	 * @param paramString
	 * @param paramXMLParameter
	 * @param paramMap1
	 * @param paramMap2
	 * @param paramMap3
	 * @param paramObject
	 * @return
	 * @throws Exception 
	 * @see com.octopus.utils.xml.auto.IXMLDoObject#checkReturn(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map, java.lang.Object)
	 */
	@Override
	public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception {
		return new ResultCheck(true, ret);
	}

    @Override
    public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception {
        return false;
    }

    /* (non Javadoc)
     * @Title: doSomeThing
     * @Description: TODO
     * @param paramString
     * @param paramXMLParameter
     * @param paramMap1
     * @param paramMap2
     * @param paramMap3
     * @return
     * @throws Exception
     * @see com.octopus.utils.xml.auto.IXMLDoObject#doSomeThing(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map)
     */
	@Override
	public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception {
		//操作类型
		String op = (String)input.get("op");
		//集合
		List list = (List) input.get("list");
		//操作参数
		Object val = input.get("val");
		if(NEW.equalsIgnoreCase(op))
			return new LinkedList();
		
		else if(null != list){
			if(DUPLICATE_REMOVAL.equalsIgnoreCase(op))
				return duplicateRemoval((String)val,list);
			else if(ADD.equalsIgnoreCase(op)){
				return addParameter(val,list);
			}
		}
		return null;
	}

	private List duplicateRemoval(String sign,List list){
		Iterator it = list.iterator();
		Map newMap = new HashMap();
		for(;it.hasNext();){
			Map map = (Map) it.next();
			newMap.put(map.get(sign), map);
		}
		return new ArrayList(newMap.values());
	}
	private List addParameter(Object val,List list){
		if(null != val){
			if(List.class.isAssignableFrom(val.getClass()))
				list.addAll((List)val);
			else
				list.add(val);
		}
		
		return list;
	}
	/* (non Javadoc) 
	 * @Title: rollback
	 * @Description: TODO
	 * @param paramString
	 * @param paramXMLParameter
	 * @param paramMap1
	 * @param paramMap2
	 * @param paramMap3
	 * @param paramObject
	 * @param paramException
	 * @return
	 * @throws Exception 
	 * @see com.octopus.utils.xml.auto.IXMLDoObject#rollback(java.lang.String, com.octopus.utils.xml.auto.XMLParameter, java.util.Map, java.util.Map, java.util.Map, java.lang.Object, java.lang.Exception)
	 */
	@Override
	public boolean rollback(String paramString, XMLParameter paramXMLParameter, Map paramMap1, Map paramMap2,
			Map paramMap3, Object paramObject, Exception paramException) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

}
