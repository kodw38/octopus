package com.octopus.isp.actions;

import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.XMLUtil;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.collections.CollectionUtils;

public class WSParamFilter extends XMLDoObject
{
  private static final long serialVersionUID = 1286004935L;

  public WSParamFilter(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void doInitial()
    throws Exception
  {
  }

  public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config)
    throws Exception
  {
    return (null != input.get("xml"));
  }

  public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret)
    throws Exception
  {
    return new ResultCheck(true, ret);
  }

  public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return false;
  }

  public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config)
    throws Exception
  {
    String xmlString = (String)input.get("xml");
    if (xmlString.contains("ServiceOperation")) {
      XMLMakeup xml = XMLUtil.getDataFromString(xmlString);
      XMLMakeup body = xml.getFirstChildrenEndWithName("Body");

      if (CollectionUtils.isNotEmpty(body.findByEndWithNameAndEndWithParentName("ServiceOperation", "ServiceHeader"))) {
        String operationType = ((XMLMakeup)body.findByEndWithNameAndEndWithParentName("ServiceOperation", "ServiceHeader").get(0)).getText();
        XMLMakeup RequestBody = body.getFirstChildrenEndWithName("RequestBody");

        if ((null != operationType) && (null != RequestBody))
        {
          List children = RequestBody.getChildren();
          RequestBody.setChildren(null);
          ArrayList newChildren = new ArrayList();
          for (Iterator i$ = children.iterator(); i$.hasNext(); ) { XMLMakeup child = (XMLMakeup)i$.next();
            if ((null != child.getName()) && (child.getName().contains(operationType)))
            {
              newChildren.add(child);
            }
          }
          RequestBody.setChildren(newChildren);
          xml.updateChildByTitleAndId(RequestBody);
        }
      }
      return xml.toString();
    }
    return xmlString;
  }

  public boolean rollback(String arg0, XMLParameter arg1, Map arg2, Map arg3, Map arg4, Object arg5, Exception arg6)
    throws Exception
  {
    return false;
  }

  public static void main(String[] args) throws Exception {
    XMLMakeup xml1 = XMLUtil.getDataFromStream(new FileInputStream(new File("C:\\Users\\Peter\\Desktop\\Pro.xml")));
    Map input = new HashMap();
    input.put("xml", xml1.toString());
    WSParamFilter filter = new WSParamFilter(null, null, null);
    filter.doSomeThing(null, null, input, null, null);
  }
}