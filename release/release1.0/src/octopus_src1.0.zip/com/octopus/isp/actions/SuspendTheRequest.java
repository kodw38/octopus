package com.octopus.isp.actions;

import com.octopus.utils.alone.ObjectUtils;
import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import org.apache.commons.logging.Log;

public class SuspendTheRequest extends XMLDoObject
{
  public SuspendTheRequest(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void doInitial()
    throws Exception
  {
  }

  public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    return true;
  }

  public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    String type;
    String reqSv = env.getTargetNames()[0];
    String reqid = (String)env.get("${requestId}");
    XMLMakeup x = getObjectById(reqSv).getXML();

    String nodeid = (String)config.get("nodeid");

    if (StringUtils.isNotBlank(env.getSuspendXMlId())) {
      xmlid = env.getSuspendXMlId();
      if ((StringUtils.isBlank(nodeid)) && (null != getObjectById(xmlid))) {
        nodeid = getObjectById(xmlid).getXML().getProperties().getProperty("nodeid");
      }

    }

    if (env.getStatus() == XMLParameter.TIMEOUT_DELETE)
      type = "TIME_OUT_BEGIN";
    else if (env.getStatus() == XMLParameter.HAPPEN_TIMEOUT)
      type = "TIME_OUT_BEGIN";
    else if (env.getStatus() == XMLParameter.HAPPEN_PREJUDGETIMEOUT)
      type = "TIME_OUT_PREJUDGE";
    else if (env.getStatus() == XMLParameter.HAPPEN_TIMEOUT_EXCEPTION)
      type = "TIME_OUT_EXCEPTION";
    else if (env.getStatus() == XMLParameter.HAPPEN_NOTIFICATION)
      type = "NOTIFICATION";
    else if (xmlid.contains(",interrupt"))
      type = "INTERRUPT_POINT";
    else
      type = "EXCEPTION";

    String state = "1";

    String id = reqSv + "|" + xmlid + "|" + nodeid + "|" + type + "|" + reqid + "|" + env.getLoginUserName() + "|";

    String envdata = ObjectUtils.convertKeyWithoutThreadNameMap2String(env);

    log.info("staff node id:" + id);

    String flowbody = x.toString();

    env.setResult("send to staff node " + id + " , please wait");

    Map map = new HashMap();
    map.put("interruptPoint", id);
    map.put("requestData", envdata);
    map.put("interruptSV", flowbody);
    map.put("svName", reqSv);
    map.put("type", type);
    map.put("state", state);
    map.put("user", env.getLoginUserName());
    if (env.getStatus() == XMLParameter.TIMEOUT_DELETE)
      map.put("op", "delete");
    else
      map.put("op", "");

    return map;
  }

  public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret)
    throws Exception
  {
    return new ResultCheck(true, ret);
  }

  public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return false;
  }

  public boolean rollback(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret, Exception e) throws Exception
  {
    return false;
  }
}