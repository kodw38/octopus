package com.octopus.isp.executors;

import com.octopus.utils.bftask.BFParameters;
import com.octopus.utils.bftask.IBFExecutor;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;

public class XMLDoObjectExecutor extends XMLObject
  implements IBFExecutor
{
  public XMLDoObjectExecutor(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void notifyObject(String op, Object obj)
    throws Exception
  {
  }

  public void destroy()
    throws Exception
  {
  }

  public void initial()
    throws Exception
  {
  }

  public void execute(XMLMakeup xml, String action, BFParameters parameters, Throwable error)
    throws Exception
  {
  }
}