package com.octopus.isp.executors;

import com.octopus.isp.ds.RequestParameters;
import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.bftask.BFParameters;
import com.octopus.utils.bftask.IBFExecutor;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class RuleBFExecutor extends XMLObject
  implements IBFExecutor
{
  static Map ObjectMap = null;

  public RuleBFExecutor(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void notifyObject(String op, Object obj)
    throws Exception
  {
  }

  public void destroy()
    throws Exception
  {
  }

  public void initial()
    throws Exception
  {
  }

  Map getObjects()
  {
    if (null == ObjectMap) {
      List ls = getAllUpPropertyObjects();
      if (null != ls) {
        HashMap map = new HashMap();
        for (int i = 0; i < ls.size(); ++i) {
          Object o = ls.get(i);
          map.put(((XMLObject)o).getXML().getName(), o);
        }
        ObjectMap = map;
      }
    }
    return ObjectMap;
  }

  public void execute(XMLMakeup xml, String action, BFParameters parameters, Throwable error) throws Exception
  {
    RequestParameters par = (RequestParameters)parameters;
    String ruleTxt = null;
    if (!(action.equals("parameterRule"))) {
      XMLMakeup[] properties = getXML().getChild("properties");
      if (null != properties) {
        XMLMakeup[] arr$ = properties; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { XMLMakeup x = arr$[i$];
          if (action.equals(x.getProperties().getProperty("key"))) {
            ruleTxt = x.getText();
            break;
          }
        }
      }
    } else {
      String ruleCode = (String)par.getQueryStringMap().get("rule");
      if (StringUtils.isNotBlank(ruleCode)) {
        XMLMakeup[] properties = getXML().getChild("properties");
        if (null != properties) {
          XMLMakeup[] arr$ = properties; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { XMLMakeup x = arr$[i$];
            if (action.equals(x.getProperties().getProperty("key"))) {
              ruleTxt = x.getText();
              break;
            }
          }
        }
        if (null == ruleTxt)
          throw new Exception("the rule[" + ruleCode + "] is not exist.");
      }
    }

    if (null == ruleTxt) ruleTxt = action;
    if (StringUtils.isNotBlank(ruleTxt)) {
      HashMap map = new HashMap();
      map.put("env", par.getEnv());
      map.put("context", par.getContext());
      map.put("session", par.getSession());
      map.put("client", par.getClientInfo());
      map.put("data", par.getRequestData());
      map.put("query", par.getQueryStringMap());

      Map tem = getObjects();
      if ((null != tem) && (tem.size() > 0))
        map.putAll(tem);

      map.put("top", par);
    }
  }
}