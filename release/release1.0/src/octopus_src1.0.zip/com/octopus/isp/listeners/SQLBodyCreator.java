package com.octopus.isp.listeners;

public class SQLBodyCreator
  implements IBodyCreator
{
  public String createBody(String s)
  {
    return null;
  }
}