package com.octopus.isp.listeners;

public abstract interface IBodyCreator
{
  public abstract String createBody(String paramString);
}