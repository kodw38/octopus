package com.octopus.isp.utils;

import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.exception.Logger;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.binding.soap.interceptor.AbstractSoapInterceptor;
import org.apache.cxf.helpers.IOUtils;
import org.apache.cxf.interceptor.Fault;

public class CXFInInterceptor extends AbstractSoapInterceptor
{
  static transient Log log = LogFactory.getLog(CXFInInterceptor.class);

  public CXFInInterceptor()
  {
    super("receive");
  }

  public void handleMessage(SoapMessage soapMessage)
    throws Fault
  {
    try
    {
      if (log.isDebugEnabled()) {
        InputStream in = (InputStream)soapMessage.getContent(InputStream.class);
        String s = IOUtils.toString(in);
        if (log.isDebugEnabled()) {
          HttpServletRequest request = (HttpServletRequest)soapMessage.get("HTTP.REQUEST");
          if (null != request)
            log.debug(Logger.getString(request) + "\n" + StringUtils.formatXml(s));

        }

        if (in != null)
          soapMessage.setContent(InputStream.class, new ByteArrayInputStream(s.getBytes()));
      }
    }
    catch (Exception e)
    {
    }
  }
}