package com.octopus.isp.utils;

import java.io.File;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.util.HashMap;
import java.util.List;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.cxf.Bus;
import org.apache.cxf.configuration.jsse.TLSServerParameters;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ServerFactoryBean;
import org.apache.cxf.jaxws.JaxWsServerFactoryBean;
import org.apache.cxf.jaxws.endpoint.dynamic.JaxWsDynamicClientFactory;
import org.apache.cxf.transport.http_jetty.JettyHTTPServerEngineFactory;

public class CXFUtil
{
  static transient Log log = LogFactory.getLog(CXFUtil.class);
  static HashMap<String, ServerFactoryBean> cache = new HashMap();
  static TLSServerParameters tlsParams;

  public static Object invoke(String wsdlpath, String method, Object[] parameters)
    throws Exception
  {
    JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
    Client client = dcf.createClient(wsdlpath);
    return client.invoke(method, parameters); }

  public static synchronized void addService(String host, String wsName, Class interfaceClass, Class implClass, String keypath, String password, String storePassword) throws Exception {
    ServerFactoryBean svrFactory;
    try {
      svrFactory = new ServerFactoryBean();
      if ((host.startsWith("https")) && (null == tlsParams)) {
        Bus bus = svrFactory.getBus();
        JettyHTTPServerEngineFactory serverEngineFactory = (JettyHTTPServerEngineFactory)bus.getExtension(JettyHTTPServerEngineFactory.class);
        File file = new File(keypath);
        tlsParams = new TLSServerParameters();
        KeyStore keyStore = KeyStore.getInstance("JKS");

        FileInputStream is = new FileInputStream(file);
        keyStore.load(is, storePassword.toCharArray());
        is.close();

        KeyManagerFactory keyFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        keyFactory.init(keyStore, password.toCharArray());
        KeyManager[] keyManagers = keyFactory.getKeyManagers();
        tlsParams.setKeyManagers(keyManagers);

        TrustManagerFactory trustFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        trustFactory.init(keyStore);
        TrustManager[] trustManagers = trustFactory.getTrustManagers();
        tlsParams.setTrustManagers(trustManagers);
        String port = host.substring(host.lastIndexOf(":") + 1);
        serverEngineFactory.setTLSServerParametersForPort(Integer.parseInt(port), tlsParams);
      }
      if (!(cache.containsKey(wsName))) {
        svrFactory.setServiceClass(interfaceClass);

        String url = host + "/" + wsName;
        svrFactory.setAddress(url);

        svrFactory.getInInterceptors().add(new CXFInInterceptor());
        svrFactory.getOutInterceptors().add(new CXFOutInterceptor());

        log.info("cxf add service " + host + "/" + wsName);
        svrFactory.setServiceBean(implClass.newInstance());
        svrFactory.create();
        cache.put(wsName, svrFactory);
      }
    } catch (Exception e) {
      log.error("add web Service error:", e);
      throw e; } }

  public static void addService2(String host, String wsName, Class interfaceClass, Class implClass) throws Exception {
    JaxWsServerFactoryBean jwsFactory;
    try {
      jwsFactory = new JaxWsServerFactoryBean();
      String url = host + "/" + wsName;
      jwsFactory.setAddress(url);

      jwsFactory.getInInterceptors().add(new CXFInInterceptor());
      jwsFactory.getOutInterceptors().add(new CXFOutInterceptor());

      jwsFactory.setServiceClass(interfaceClass);
      Object o = implClass.newInstance();

      jwsFactory.setServiceBean(o);
      jwsFactory.create();
      log.info("cxf add service " + host + "/" + wsName);
      cache.put(wsName, jwsFactory);
    } catch (Exception e) {
      log.error("add web Service error:", e);
      throw e; }
  }

  public static void deleteService(String wsName) {
    try {
      if (cache.containsKey(wsName)) {
        ((ServerFactoryBean)cache.get(wsName)).destroy();
        cache.remove(wsName);
      }
    }
    catch (Exception e) {
      log.error("add web Service error:", e);
    }
  }

  public static void parseWSDLByNewAddress(String wsdlAddress)
  {
  }
}