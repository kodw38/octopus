package com.octopus.isp.utils;

import java.io.PrintStream;
import java.util.Set;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.binding.soap.saaj.SAAJInInterceptor;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ReadSoapHeader extends AbstractPhaseInterceptor<SoapMessage>
{
  private SAAJInInterceptor saa = new SAAJInInterceptor();

  public ReadSoapHeader()
  {
    super("pre-protocol");
    getAfter().add(SAAJInInterceptor.class.getName());
  }

  public void handleMessage(SoapMessage message) throws Fault {
    SOAPMessage mess = (SOAPMessage)message.getContent(SOAPMessage.class);
    if (mess == null) {
      this.saa.handleMessage(message);
      mess = (SOAPMessage)message.getContent(SOAPMessage.class);
    }
    SOAPHeader head = null;
    try {
      head = mess.getSOAPHeader();
    } catch (SOAPException e) {
      e.printStackTrace();
    }

    if (head == null)
      return;

    try
    {
      NodeList nodes = head.getElementsByTagName("tns:username");
      NodeList nodepass = head.getElementsByTagName("tns:password");

      if (nodes.item(0).getTextContent().equals("wdw")) {
        if (nodepass.item(0).getTextContent().equals("wdwsb"))
          System.out.println("认证成功");
      }
      else
      {
        SOAPException soapExc = new SOAPException("认证错误");
        throw new Fault(soapExc);
      }
    } catch (Exception e) {
      SOAPException soapExc = new SOAPException("认证错误");
      throw new Fault(soapExc);
    }
  }
}