package com.octopus.isp.cell;

public abstract interface ICellEvent
{
}