package com.octopus.isp.cell.actions.rule;

import java.util.Map;

public abstract interface IRuleExecutor
{
  public abstract void setEnv(Map paramMap);
}