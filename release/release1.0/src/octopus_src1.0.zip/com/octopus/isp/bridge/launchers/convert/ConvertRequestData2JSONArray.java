package com.octopus.isp.bridge.launchers.convert;

import com.octopus.isp.bridge.launchers.IConvert;
import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class ConvertRequestData2JSONArray extends XMLObject
  implements IConvert
{
  public ConvertRequestData2JSONArray(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void notifyObject(String op, Object obj)
    throws Exception
  {
  }

  public void destroy()
    throws Exception
  {
  }

  public void initial()
    throws Exception
  {
  }

  public Object convert(Object par) throws IOException
  {
    HttpServletRequest request = (HttpServletRequest)par;
    request.setCharacterEncoding("UTF-8");
    String paramStr = null;

    int len = request.getContentLength();
    if (len > 0) {
      byte[] buffer = new byte[len];

      InputStream in = request.getInputStream();
      int total = 0;
      int once = 0;
      while ((total < len) && (once >= 0)) {
        once = in.read(buffer, total, len);
        total += once;
      }

      paramStr = new String(URLDecoder.decode(new String(buffer), "UTF-8")).trim();
    }

    if ((null != paramStr) && (paramStr.length() > 0)) {
      Map paramMap = new HashMap();
      if ((paramStr.startsWith("{")) && (paramStr.endsWith("}"))) {
        paramStr = "[".concat(paramStr).concat("]");
      } else if (paramStr.contains("&")) {
        String[] params = paramStr.split("&");
        if ((params != null) && (params.length > 0)) {
          String[] arr$ = params; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String param = arr$[i$];
            String[] paramArray = param.split("=");
            paramMap.put(paramArray[0], "");
            if ((paramArray != null) && (paramArray.length == 2)) {
              String paramKey = paramArray[0];
              String paramValue = URLDecoder.decode(paramArray[1], "UTF-8");
              if (StringUtils.isNotEmpty(paramValue))
                if ((StringUtils.trim(paramValue).startsWith("{")) && (StringUtils.trim(paramValue).endsWith("}")))
                {
                  paramMap.put(paramKey, JSONObject.fromObject(paramValue));
                }
                else paramMap.put(paramKey, paramValue);
            }
          }

        }

      }
      else if (paramStr.contains("=")) {
        String[] paramArray = paramStr.split("=");
        paramMap.put(paramArray[0], "");
        if ((paramArray != null) && (paramArray.length == 2)) {
          String paramKey = paramArray[0];
          String paramValue = URLDecoder.decode(paramArray[1], "UTF-8");
          if (StringUtils.isNotEmpty(paramValue))
            if ((StringUtils.trim(paramValue).startsWith("{")) && (StringUtils.trim(paramValue).endsWith("}")))
            {
              paramMap.put(paramKey, JSONObject.fromObject(paramValue));
            }
            else paramMap.put(paramKey, paramValue);

        }

      }

      if (!(paramMap.isEmpty()))
        paramStr = "[".concat(JSONObject.fromObject(paramMap).toString()).concat("]");

      if (paramStr.startsWith("[")) {
        JSONArray array = JSONArray.fromObject(paramStr);

        return array;
      }
    }
    return null;
  }
}