package com.octopus.isp.bridge.launchers;

import com.octopus.utils.xml.XMLObject;
import java.io.PrintStream;

public class MainSimpleLauncher
{
  public static void main(String[] args)
  {
    long l;
    try
    {
      l = System.currentTimeMillis();
      XMLObject.loadApplication("classpath:" + args[0], null, true, true);
      System.out.println("has launch system.");
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }
}