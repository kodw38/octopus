package com.octopus.isp.bridge;

public abstract interface ILauncher
{
  public abstract void start()
    throws Exception;

  public abstract boolean addEnv(String paramString, Object paramObject);

  public abstract Object invoke(Object paramObject)
    throws Exception;
}