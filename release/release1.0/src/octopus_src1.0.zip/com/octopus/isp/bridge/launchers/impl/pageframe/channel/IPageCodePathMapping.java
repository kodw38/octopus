package com.octopus.isp.bridge.launchers.impl.pageframe.channel;

public abstract interface IPageCodePathMapping
{
  public abstract String getRealPathByCode(String paramString);
}