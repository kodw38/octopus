package com.octopus.isp.bridge.impl;

import com.octopus.isp.bridge.IBridge;
import com.octopus.isp.bridge.ILauncher;
import com.octopus.isp.cell.ICell;
import com.octopus.isp.ds.Constant;
import com.octopus.isp.ds.Context;
import com.octopus.isp.ds.Contexts;
import com.octopus.isp.ds.DataEnv;
import com.octopus.isp.ds.RequestParameters;
import com.octopus.utils.alone.SNUtils;
import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.exception.Logger;
import com.octopus.utils.flow.IFlow;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class Bridge extends XMLDoObject
  implements IBridge
{
  static transient Log log = LogFactory.getLog(Bridge.class);
  HashMap<String, ILauncher> launchers;
  HashMap<String, ICell> cells;
  HashMap<String, XMLMakeup> instances;
  DataEnv env;
  Contexts contexts;
  XMLDoObject sessionmgr;
  Constant constants;
  IFlow flow;
  String instanceid;

  public Bridge(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);

    if (StringUtils.isBlank(this.instanceid))
      throw new RuntimeException("this instance name is null. please set in bridge.xml");

    if (!(this.instanceid.startsWith("INS-")))
      throw new RuntimeException("this instance name is must start with [INS-]");
  }

  public String getInstanceId()
  {
    return this.instanceid;
  }

  public ILauncher getLauncher(String launcherName)
  {
    ILauncher launcher = (ILauncher)this.launchers.get(launcherName);
    if (null == launcher)
      log.error("Launcher[" + launcherName + "] is not exist.");
    return launcher;
  }

  public Object evaluate(RequestParameters parameters)
  {
    try {
      if (null != this.constants)
        parameters.setConstant(this.constants.getConstant());

      if (null != this.env)
        parameters.setEnv(this.env.getEnv());
      if (null != this.contexts) {
        Context context = this.contexts.getContext(parameters);
        if (null == context) throw new Exception("not find context from the parameters.");
        parameters.setContext(context);
      }
      parameters.setRequestDate(new Date());
      if (StringUtils.isBlank(parameters.getRequestId()))
        parameters.setRequestId(SNUtils.getNewId());

      this.flow.doFlow(parameters);

      if (log.isInfoEnabled()) {
        log.info(Logger.getTraceString(parameters, null));
      }

      return parameters.getResult();
    }
    catch (Exception e) {
      ResultCheck ret = new ResultCheck();

      Logger.error(getClass(), parameters, getXML().getId(), "error happened", e);
      ret.setSuccess(false);
      ret.setRet(e);

      if (log.isInfoEnabled())
        log.info(Logger.getTraceString(parameters, e));

      return ret;
    }
  }

  public DataEnv getEnv()
  {
    return this.env;
  }

  public Object doSomeThing(String xmlid, XMLParameter pars, Map input, Map output, Map config) throws Exception
  {
    if ((null != input) && 
      ("getSystemParameters".equalsIgnoreCase((String)input.get("op")))) {
      RequestParameters parameters = new RequestParameters();
      if (null != this.env)
        parameters.setEnv(this.env.getEnv());
      if (null != this.contexts) {
        Context context = this.contexts.getContext(parameters);
        if (null == context) throw new Exception("not find context from the parameters.");
        parameters.setContext(context);
      }
      return parameters;
    }

    return null;
  }

  public void doInitial()
    throws Exception
  {
  }

  public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    return true;
  }

  public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return new ResultCheck(true, ret);
  }

  public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return false;
  }

  public boolean rollback(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret, Exception e) throws Exception
  {
    return false;
  }
}