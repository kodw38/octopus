package com.octopus.isp.bridge.launchers.convert;

import com.octopus.isp.actions.ISPDictionary;
import com.octopus.isp.bridge.launchers.IConvert;
import com.octopus.utils.cls.POJOUtil;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class ConvertReturn2POJO extends XMLObject
  implements IConvert
{
  public ConvertReturn2POJO(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void notifyObject(String op, Object obj)
    throws Exception
  {
  }

  public void destroy()
    throws Exception
  {
  }

  public void initial()
    throws Exception
  {
  }

  public Object convert(Object par) throws Exception
  {
    ISPDictionary dictionary = (ISPDictionary)getObjectById("Dictionary");
    if ((null != par) && (null != dictionary)) {
      if (par instanceof Collection) {
        List ls = new LinkedList();
        Iterator its = ((Collection)par).iterator();
        while (its.hasNext())
          ls.add(convert(its.next()));

        return ls.toArray(); }
      if (par instanceof Map)
      {
        return POJOUtil.convertMap2POJO((Map)par, dictionary.getClassByFields(((Map)par).keySet()), null);
      }
      return par;
    }

    return null;
  }
}