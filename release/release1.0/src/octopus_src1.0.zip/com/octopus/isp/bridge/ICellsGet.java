package com.octopus.isp.bridge;

import com.octopus.utils.xml.XMLMakeup;

public abstract interface ICellsGet
{
  public abstract XMLMakeup getCell(XMLMakeup paramXMLMakeup);
}