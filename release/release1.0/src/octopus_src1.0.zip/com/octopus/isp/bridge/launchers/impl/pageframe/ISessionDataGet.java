package com.octopus.isp.bridge.launchers.impl.pageframe;

public abstract interface ISessionDataGet
{
  public abstract String getData(Object paramObject);
}