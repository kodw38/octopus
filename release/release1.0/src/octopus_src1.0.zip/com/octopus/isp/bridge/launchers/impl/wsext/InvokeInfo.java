package com.octopus.isp.bridge.launchers.impl.wsext;

import com.octopus.utils.alone.StringUtils;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.soap.SOAPEnvelope;
import org.apache.axiom.soap.SOAPHeader;
import org.apache.axis2.context.MessageContext;

public class InvokeInfo
{
  public String className;
  public String methodName;
  Object pars;
  Map<String, String> header = new HashMap();
  Properties properties = new Properties();

  public InvokeInfo(MessageContext inMessage, String className, String methodName, Object pars)
  {
    this.className = className;
    this.methodName = methodName;
    this.pars = pars;
    if ((null != inMessage.getEnvelope()) && (null != inMessage.getEnvelope().getHeader().getFirstElement())) {
      SOAPHeader hd = inMessage.getEnvelope().getHeader();
      if (null != hd) {
        Iterator its = hd.getChildElements();
        while (its.hasNext()) {
          OMElement element = (OMElement)its.next();
          if ((StringUtils.isNotBlank(element.getLocalName())) && (StringUtils.isNotBlank(element.getText())));
          this.header.put(element.getLocalName(), element.getText());
        }
      }
    }
    Iterator its = inMessage.getPropertyNames();
    while ((null != its) && 
      (its.hasNext())) {
      String k = (String)its.next();
      Object v = inMessage.getProperty(k);
      if (null != v)
        this.properties.put(k, v);
    }
  }

  public String getClassName()
  {
    return this.className;
  }

  public Map<String, String> getHeader() {
    return this.header;
  }

  public void setHeader(Map<String, String> header) {
    this.header = header;
  }

  public Properties getProperties() {
    return this.properties;
  }

  public void setProperties(Properties properties) {
    this.properties = properties;
  }

  public void setClassName(String className) {
    this.className = className;
  }

  public String getMethodName() {
    return this.methodName;
  }

  public void setMethodName(String methodName) {
    this.methodName = methodName;
  }

  public Object getPars() {
    return this.pars;
  }

  public void setPars(Object pars) {
    this.pars = pars;
  }
}