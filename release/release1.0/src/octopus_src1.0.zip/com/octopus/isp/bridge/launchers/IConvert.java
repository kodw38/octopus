package com.octopus.isp.bridge.launchers;

public abstract interface IConvert
{
  public abstract Object convert(Object paramObject)
    throws Exception;
}