package com.octopus.isp.bridge;

import com.octopus.isp.ds.RequestParameters;

public abstract interface IBridge
{
  public abstract String getInstanceId();

  public abstract ILauncher getLauncher(String paramString);

  public abstract Object evaluate(RequestParameters paramRequestParameters);
}