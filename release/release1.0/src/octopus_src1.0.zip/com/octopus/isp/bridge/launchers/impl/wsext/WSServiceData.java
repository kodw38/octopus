package com.octopus.isp.bridge.launchers.impl.wsext;

import com.octopus.isp.bridge.launchers.impl.WebServiceLauncher;
import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.cls.ClassUtils;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.desc.Desc;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import org.apache.axis2.context.ConfigurationContext;
import org.apache.axis2.description.Parameter;
import org.apache.axis2.engine.AxisConfiguration;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class WSServiceData
{
  static transient Log log = LogFactory.getLog(WSServiceData.class);
  ConfigurationContext configurationContext;
  Map<String, Map<String, String>> pojoList;
  List<ServiceInfo> serviceList = new ArrayList();

  public WSServiceData(ConfigurationContext configurationContext)
  {
    this.configurationContext = configurationContext;
    WebServiceLauncher launcher = (WebServiceLauncher)configurationContext.getAxisConfiguration().getParameter(WebServiceLauncher.LAUNCHER_PROPERTY_KEY).getValue();

    Map temp = new HashMap();

    String path = launcher.getXML().getProperties().getProperty("loadpath");
    if (StringUtils.isNotBlank(path)) {
      Map ms = launcher.getXMLObjectContainer();
      Iterator ist = ms.keySet().iterator();
      while (ist.hasNext()) {
        Object o = ms.get(ist.next());
        if (o instanceof XMLDoObject) {
          XMLDoObject xd = (XMLDoObject)o;
          if ((xd.getXML().getProperties().containsKey("path")) && (xd.getXML().getProperties().getProperty("path").indexOf(path) == 0)) {
            String name = xd.getXML().getProperties().getProperty("path");

            ServiceInfo ser = (ServiceInfo)temp.get(name);
            if (null == ser) {
              ser = new ServiceInfo();
              ser.setServiceName(name);
              temp.put(ser.getServiceName(), ser);
            }
            try {
              if (null != xd.getDescStructure())
              {
                Class inputbean = Desc.convert2Bean(xd.getXML().getProperties().getProperty("path"), xd.getXML().getId(), (Map)xd.getDescStructure().get("input"));
                Class returnbean = Desc.convert2Bean(xd.getXML().getProperties().getProperty("path"), xd.getXML().getId(), (Map)xd.getDescStructure().get("output"));
                if ((null != inputbean) && (null != returnbean))
                  ser.addClassInfo(xd.getXML().getProperties().getProperty("path"), xd.getXML().getId(), new String[][] { { inputbean.getName() } }, returnbean.getName());
                else if (null != inputbean)
                  ser.addClassInfo(xd.getXML().getProperties().getProperty("path"), xd.getXML().getId(), new String[][] { { inputbean.getName() } }, null);
                else if (null != returnbean)
                  ser.addClassInfo(xd.getXML().getProperties().getProperty("path"), xd.getXML().getId(), (String[][])null, returnbean.getName());
              } else {
                ser.addClassInfo(xd.getXML().getProperties().getProperty("path"), xd.getXML().getId(), (String[][])null, null);
              }

            }
            catch (Exception e)
            {
              log.error("get XMLDoObject Description error", e);
            }
          }
        }

      }

      Iterator its = temp.values().iterator();
      while (its.hasNext())
        WSISPDeployer.addService(configurationContext, (ServiceInfo)its.next());

      this.serviceList.addAll(temp.values());
    }
  }

  Map<String, Map<String, String>> getPoJoMap()
  {
    return this.pojoList;
  }

  List<ServiceInfo> getServices()
  {
    return this.serviceList;
  }

  void appendService(Map<String, ServiceInfo> li, Class c, String methods) throws NoSuchMethodException {
    int len$;
    int i$;
    ServiceInfo s = (ServiceInfo)li.get("local");
    if (null == s) {
      s = new ServiceInfo();
      s.setServiceName("local");

      li.put("local", s);
    }
    if (StringUtils.isNotBlank(methods)) {
      String[] mns = methods.split(",");
      String[] arr$ = mns; len$ = arr$.length; for (i$ = 0; i$ < len$; ++i$) { String m = arr$[i$];
        s.addClassInfo(c.getName(), m, (String[][])null, null);
      }
    } else {
      Method[] ms = ClassUtils.getPublicMethods(new Class[] { c });
      Method[] arr$ = ms; len$ = arr$.length; for (i$ = 0; i$ < len$; ++i$) { Method m = arr$[i$];
        s.addClassInfo(c.getName(), m.getName(), (String[][])null, null);
      }
    }
  }
}