package com.octopus.isp.bridge.launchers.impl;

import com.google.common.collect.ImmutableMap;
import com.octopus.isp.bridge.IBridge;
import com.octopus.isp.bridge.ILauncher;
import com.octopus.isp.bridge.impl.Bridge;
import com.octopus.isp.bridge.launchers.IConvert;
import com.octopus.isp.bridge.launchers.impl.pageframe.SessionManager;
import com.octopus.isp.bridge.launchers.impl.pageframe.util.HttpUtils;
import com.octopus.isp.cell.impl.Cell;
import com.octopus.isp.ds.*;
import com.octopus.isp.utils.ISPUtil;
import com.octopus.utils.alone.ArrayUtils;
import com.octopus.utils.alone.ObjectUtils;
import com.octopus.utils.alone.SNUtils;
import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.exception.Logger;
import com.octopus.utils.net.NetUtils;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.eclipse.jetty.http.ssl.SslContextFactory;
import org.eclipse.jetty.server.ssl.SslSelectChannelConnector;
import org.eclipse.jetty.util.thread.ExecutorThreadPool;
import org.mortbay.jetty.Server;
import org.mortbay.jetty.servlet.DefaultServlet;
import org.mortbay.jetty.servlet.FilterHolder;
import org.mortbay.jetty.servlet.ServletHolder;
import org.mortbay.jetty.webapp.WebAppContext;
import org.mortbay.resource.Resource;
import org.mortbay.thread.QueuedThreadPool;
import sun.misc.BASE64Decoder;

import javax.servlet.*;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLDecoder;
import java.util.*;

/**
 * User: wfgao_000
 * Date: 15-8-20
 * Time: 下午4:58
 */
public class WebPageFrameLauncher extends Cell implements ILauncher {
    static transient Log log = LogFactory.getLog(WebPageFrameLauncher.class);
    IConvert inputconvert;
    IConvert outputconvert;
    DataEnv env=null;
    XMLDoObject statHandler;
    Map cache_headers= new HashMap();
    public static String WebPageFrameLauncher="WebPageFrameLauncher";
    String LoginUserNameKey,LoginUserPwdKey;
    public WebPageFrameLauncher(XMLMakeup xml, XMLObject parent,Object[] containers) throws Exception {
        super(xml, parent,containers);
        env = (DataEnv)getPropertyObject("env");

        XMLMakeup uns = (XMLMakeup)ArrayUtils.getFirst(xml.getByTagProperty("property","name","LoginUserNameKey"));
        if(null != uns){
            LoginUserNameKey=uns.getText();
        }
        XMLMakeup ups = (XMLMakeup)ArrayUtils.getFirst(xml.getByTagProperty("property","name","LoginUserPwdKey"));
        if(null != ups){
            LoginUserPwdKey=ups.getText();
        }
        if(null != env.getEnv() && StringUtils.isTrue((String)env.getEnv().get("webselfstart")) && StringUtils.isNotBlank(env.getEnv().get("webport"))) {
            int port =0,sslport=0;
            String sp = ((String)env.getEnv().get("webport"));
            if(StringUtils.isNotBlank(sp)){
                port = Integer.parseInt(sp);
            }
            String p = ((String)env.getEnv().get("ssl_port"));
            if(StringUtils.isNotBlank(p)){
                sslport = Integer.parseInt(p);
            }
            start((String)env.getEnv().get("webcontextpath"), (String)env.getEnv().get("webcontentpath"), port,sslport,(String)env.getEnv().get("ishttps"),(String)env.getEnv().get("ssl_keystoretype"),(String)env.getEnv().get("ssl_keystore"),(String)env.getEnv().get("ssl_password"),(String)env.getEnv().get("ssl_mgr_password"));
        }
    }

    public void start(){
        //System.out.println();
    }

    @Override
    public boolean addEnv(String key, Object value) {
        env.getEnv().addParameter(key, value);
        return true;
    }

    void setCookie(RequestParameters par,Cookie[] cs){
        StringBuffer cookie = new StringBuffer();
        if(null != cs){
            for(Cookie e:cs){
                if(cookie.length()!=0){
                    cookie.append(";");
                }
                cookie.append(e.getName()).append("=").append(e.getValue());
            }
        }
        par.getRequestHeaders().put("cookie",cookie.toString());
    }
    @Override
    public Object invoke(Object obj) throws Exception {

        HttpServletRequest request = (HttpServletRequest)((Object[])obj)[0];
        HttpServletResponse response = (HttpServletResponse)((Object[])obj)[1];

        RequestParameters pars = new RequestParameters();
        try {
            getHeaders(request, pars.getRequestHeaders(), pars);

            pars.addRequestProperties("ContextPath", request.getContextPath());
            pars.addRequestProperties("Method", request.getMethod());
            pars.addRequestProperties("Scheme", request.getScheme());
            pars.addRequestProperties("ServerName", request.getServerName());
            pars.addRequestProperties("ServerPort", request.getServerPort());
            pars.setRequestURL(request.getRequestURL().toString());
            pars.setQueryString(request.getQueryString());
            pars.setRequestURI(request.getRequestURI());
            pars.setRequestResourceName(getResourceName(request.getRequestURI()));
            pars.addParameter("${request}", request);
            pars.addParameter("${response}", response);
            pars.setQueryStringMap(getQueryStringMap(pars.getQueryString()));
        /*if(pars.getQueryStringMap().containsKey("targetinsid")){
            pars.getRequestHeaders().put("targetinsid",pars.getQueryStringMap().get("targetinsid"));
        }*/

        /*pars.addParameter("${webroot}",request.getSession().getServletContext().getRealPath("/"));
        */
            //post service info , changed remove the if for restful
            //if(pars.getRequestProperties().get("Method").equals("POST")){
            String srvname = "";
            if (null != pars.getQueryStringMap() && pars.getQueryStringMap().containsKey("actions")) {
                srvname = (StringUtils.trim((String) pars.getQueryStringMap().get("actions")));
                String[] actions = srvname.split(",");
                pars.setTargetNames(actions);
            }
            //restful post
            if (null == pars.getTargetNames() && StringUtils.isTrue(properties.getProperty("restful")) &&
                    ("POST".equals(pars.getRequestProperties().get("Method")) || "GET".equals(pars.getRequestProperties().get("Method")))) {
                String uri = pars.getRequestURI();
                Object me = pars.getValueFromExpress("getvalue(${env}.restfulAddressMapping." + uri + ")", this);
                if (null != me && me instanceof String && StringUtils.isNotBlank(me)) {
                    pars.setTargetNames(new String[]{(String) me});
                } else {
                    String startwith = properties.getProperty("restful_startwith");
                    if (StringUtils.isNotBlank(startwith) && uri.startsWith("/" + startwith + "/")) {
                        String name = uri.substring(uri.lastIndexOf("/") + 1);
                        pars.setTargetNames(new String[]{name});
                    } else {
                        String name = uri.substring(uri.lastIndexOf("/") + 1);
                        if (StringUtils.isNotBlank(name) && !name.contains(".")) {
                            pars.setTargetNames(new String[]{name});
                        }
                    }
                }
            }
            //}
            if (!pars.getRequestHeaders().contains(pars.KEY_REQUESTID)) {
                String user = (String) request.getHeader("user");
                Bridge b = (Bridge) getObjectById("bridge");
                if (null != b) {
                    pars.setRequestId(ISPUtil.getRequestId("WEB", b.getInstanceId(), (user == null ? "" : user), srvname));
                } else {
                    pars.setRequestId(ISPUtil.getRequestId("WEB", "", user, srvname));
                }
            } else {
                pars.setRequestId((String) pars.getRequestHeaders().get(pars.KEY_REQUESTID));
            }
            Logger.debug(this.getClass(), pars, (null == getXML() ? "" : getXML().getId()), "begin", null);
        /*if(log.isDebugEnabled()) {
            pars.printTime("WebPageFrame begin");
        }*/
            setCookie(pars, request.getCookies());
            if (null != inputconvert)
                obj = inputconvert.convert(obj);
            pars.setEnv(env.getEnv());


            pars.addClientInfo("ClientIp", getIp(request));
            pars.getClientInfo().setClientKind(request);
            String[] osbt = getOSBrowserTerminal(pars.getHeader("user-agent"));


            if (null != osbt && osbt.length > 2) {
                pars.addClientInfo(ClientInfo.CLIENT_IP, getIp(request));
                pars.addClientInfo(ClientInfo.CLIENT_OS, osbt[0]);
                pars.addClientInfo(ClientInfo.CLIENT_BROWSER, osbt[1]);
                pars.addClientInfo(ClientInfo.CLIENT_TERMINAL, osbt[2]);
            }

            //old session
            SessionManager sm = (SessionManager) getObjectById("SessionManager");
            pars.setSessionManager(sm);
            String sessionKey = (String) properties.get("SessionKey");
            getCookies(pars, pars.getRequestHeaders(), pars.getRequestCookies(), sessionKey, sm);
            pars.getRequestProperties().put("SessionKey", sessionKey);


            //request data
            Object objpar = getRequestData(request, pars);
            if (null != inputconvert) {
                objpar = inputconvert.convert(objpar);
            }
            pars.setRequestData(objpar);
            //login

            String[] user = getUserInfo(pars);
            if (user != null) {
                //session from login info
                Session session = sm.getSessionByUser(user[0]);
                if (null != session) {
                    pars.getRequestCookies().put(sessionKey, session.getSessionId());
                    pars.setSession(session);
                }
            }

            if (null == pars.getTargetNames()) {
                doThing(pars, getXML());
            }
            if (!pars.isStop()) {
                if (Logger.isDebugEnabled()) {
                    Logger.debug(this.getClass(), pars, (null == getXML() ? "" : getXML().getId()), "do action begin" + ArrayUtils.toJoinString(pars.getTargetNames()), null);
                }
            /*if(log.isDebugEnabled()) {
                pars.printTime("WebPageFrame invoke srv begin");
            }*/
                try {
                    ((IBridge) getPropertyObject("bridge")).evaluate(pars);
                } catch (Exception e) {
                    //Logger.error(this.getClass(),pars,(null == getXML() ? "" : getXML().getId()),e.getMessage(),e);
                    throw e;
                }
            /*if(log.isDebugEnabled()) {
                pars.printTime("WebPageFrame invoke srv end");
            }*/
                if (Logger.isDebugEnabled()) {
                    Logger.debug(this.getClass(), pars, (null == getXML() ? "" : getXML().getId()), "do action end" + ArrayUtils.toJoinString(pars.getTargetNames()), null);
                }
                HashMap map = new HashMap();
                map.put("flowid", "output");
                doCheckThing(getXML().getId(), pars, map, null, null, null);
                if (!pars.isStop()) {
                    Object ret = pars.getResult();
                    if (null != ret) {
                        if (ret instanceof ResultCheck) {
                            if (null != outputconvert) {
                                ret = outputconvert.convert(((ResultCheck) ret).getRet());
                            } else {
                                ret = ((ResultCheck) ret).getRet();
                            }
                        } else {
                            if (null != outputconvert) {
                                ret = outputconvert.convert(ret);
                            }
                        }

                    }
                    if (null == ret) {
                        ret = "";
                    }
                    addResponseDataSize(pars, ret.toString().length());
                    Logger.debug(this.getClass(), pars, (null == getXML() ? "" : getXML().getId()), "end" + ArrayUtils.toJoinString(pars.getTargetNames()), null);

                /*if (log.isDebugEnabled()) {
                    pars.printTime("WebPageFrame end");
                }*/
                    return ret;
                }
                return null;
            } else {
                if (null != pars.getResult()) {
                    if (pars.getResult() instanceof ResultCheck) {
                        if (!((ResultCheck) pars.getResult()).isSuccess()) {
                            HttpUtils hu = (HttpUtils) getObjectById("HttpUtils");
                            hu.writeError(pars);
                            return null;
                        } else {
                            return ((ResultCheck) pars.getResult()).getRet();
                        }
                    } else {
                        return pars.getResult();
                    }
                }
                return null;
            }
        }finally {

        }
    }
    private String getResourceName(String uri){
        if(StringUtils.isNotBlank(uri)){
            if(uri.contains("/")){
                return uri.substring(uri.lastIndexOf("/")+1) ;
            }else{
                return uri;
            }
        }
        return "";
    }

    private void getHeaders(HttpServletRequest paramHttpServletRequest, Hashtable paramHashtable,XMLParameter env)
    {
        //默认是admin,经过鉴权时修改对应的值
        HashMap map = new HashMap();
        map.put("auth_type","admin");
        map.put("auth_level","0");
        env.addGlobalParameter("${AuthInfo}",map);

        boolean iscacheheader=StringUtils.isTrue(properties.getProperty("iscacheheader"));
        if(iscacheheader && cache_headers.containsKey(paramHttpServletRequest.getRemoteAddr())){
            paramHashtable.putAll((Map)cache_headers.get(paramHttpServletRequest.getRemoteAddr()));
        }else {
            Enumeration localEnumeration1 = paramHttpServletRequest.getHeaderNames();

            StringBuffer str2 = new StringBuffer();
            while (localEnumeration1.hasMoreElements()) {
                String str1 = (String) localEnumeration1.nextElement();
                if(str1.equalsIgnoreCase("cookie")) continue;
                if (null != str1) {
                    Enumeration localEnumeration2 = paramHttpServletRequest.getHeaders(str1);
                    while (localEnumeration2.hasMoreElements()) {
                        if (str2.length() > 0) {
                            str2.append(";");
                        }
                        str2.append((String) localEnumeration2.nextElement());
                    }
                    String v = str2.toString();
                    if("undefined".equals(v)){
                        v="";
                    }
                    if("authinfo".equals(str1)){
                        log.debug("authinfo:"+v);
                        Map m = StringUtils.convert2MapJSONObject(v);
                        env.addGlobalParameter("${AuthInfo}",m);
                    }
                    paramHashtable.put(str1, v);
                    str2.delete(0, str2.length());
                }
            }
            if(iscacheheader) {
                Hashtable t = new Hashtable();
                t.putAll(paramHashtable);
                cache_headers.put(paramHttpServletRequest.getRemoteAddr(), t);
            }
        }
        if(log.isDebugEnabled()) {
            log.debug("request headers:" + paramHashtable);
        }
    }
    String[] getUserInfo(RequestParameters request){
        Object o = request.getRequestData();
        if(o instanceof Map){
            Map in = (Map)o;

            String userName = (String)in.get(LoginUserNameKey);
            String userPwd = (String)in.get(LoginUserPwdKey);
            if(StringUtils.isNotBlank(userName) && StringUtils.isNotBlank(userPwd))
                return new String[]{userName,userPwd};
            return null;
        }
        return null;
    }
    private void getCookies(RequestParameters parameters,Hashtable headers, Hashtable paramHashtable,String sessionkey,SessionManager sm) throws Exception {
        String cookieName = null;
        if(headers.containsKey("cookie")){
            cookieName="cookie";
        }
        if(headers.containsKey("Cookie")){
            cookieName="Cookie";
        }
        log.debug("CookieName:"+cookieName);
        if(null !=cookieName){
            String cookies = (String)headers.get(cookieName);
            log.debug("Cookie:"+cookies);
            log.debug("Cookie1:"+(String)headers.get("cookie"));
            log.debug("Cookie2:"+(String)headers.get("Cookie"));
            parameters.getRequestProperties().put("${RequestCookie}",cookies);
            String[] ss = cookies.split(";");
            for(String s:ss){
                if(s.contains("=")){
                    int n=s.indexOf("=");
                    if(n>0){
                        String k = s.substring(0,n).trim();
                        String v = s.substring(n+1);
                        log.debug("sessionKey:"+sessionkey);
                        if(k.equals(sessionkey) && parameters.getSession()==null){
                            log.debug("get session from "+k+" value "+v);
                            if(StringUtils.isNotBlank(v)){
                                log.debug("get session by cookie:"+v);
                                Session session = sm.getSessionById(v,null);
                                if(null!=session){
                                    paramHashtable.put(k,v);
                                    parameters.setSession(session);
                                    log.debug("set session from "+k+" value "+v+ " session:"+session);
                                }
                            }
                        }else if(k.equals("JSESSIONID") && parameters.getSession()==null){
                            paramHashtable.put(k,v);
                            if(StringUtils.isNotBlank(v)){
                                Session session = sm.getSessionById(null,v);
                                if(null!=session){
                                    parameters.setSession(session);
                                }
                            }
                        }else{
                            if(!paramHashtable.containsKey(k))
                                paramHashtable.put(k,v);
                        }
                    }else{
                        paramHashtable.put(s,null);
                    }
                }
            }
        }
    }
    //webpageLanucher do nothing when there is new service add or update
    public void notifyObject(String op,Object obj)throws Exception{

    }
    private HashMap getQueryStringMap(String queryStr) throws UnsupportedEncodingException {
        if(null != queryStr){
            queryStr = URLDecoder.decode(queryStr, "UTF-8");
            HashMap map = new HashMap();
            String[] ps = queryStr.split("\\&");
            for(int i=ps.length-1;i>=0;i--){
                if(StringUtils.isNotBlank(ps[i])){
                    String[] kv = ps[i].split("\\=");
                    if(kv.length==2){
                        if(StringUtils.isNotBlank(kv[0]) && StringUtils.isNotBlank(kv[1]) && !map.containsKey(kv[0])) {
                            if(queryStr.indexOf("actions=")>=0 && null!=(kv[1]) && (kv[1]).startsWith("{") && (kv[1]).endsWith("}")) {
                                map.put(kv[0], StringUtils.convert2MapJSONObject(kv[1]));
                            }else if(queryStr.indexOf("actions=")>=0 && null!=(kv[1]) && (kv[1]).startsWith("[") && (kv[1]).endsWith("]")){
                                map.put(kv[0], StringUtils.convert2ListJSONObject(kv[1]));
                            }else{
                                map.put(kv[0], kv[1]);
                            }
                        }
                    }
                }
            }
            return map;
        }
        return null;
    }

    public String getIp(HttpServletRequest request) {
        String ip = request.getHeader("x-forwarded-for");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("http_client_ip");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        // 如果是多级代理，那么取第一个ip为客户ip
        if (ip != null && ip.indexOf(",") != -1) {
            ip = ip.substring(ip.lastIndexOf(",") + 1, ip.length()).trim();
        }
        return ip;
    }

    public String[] getOSBrowserTerminal(String user_agent){
        if(StringUtils.isBlank(user_agent))return null;
        String info = user_agent.toUpperCase();
        if(info.indexOf("(")==-1){// 针对火狐浏览器 swfupload控件 上传文件请求
            return null;
        }
        String[] ret = new String[3];
        String infoTemp=info.substring(info.indexOf("(") + 1, info.indexOf(")") - 1);
        String[] strInfo = infoTemp.split(";");
        if ((info.indexOf("MSIE")) > -1) {
            ret[1]=(strInfo[1].trim());
            ret[0]=(strInfo[2].trim());
        } else {
            String[] str = info.split(" ");
            if (info.indexOf("NAVIGATOR") < 0 && info.indexOf("FIREFOX") > -1) {
                ret[1]=(str[str.length - 1].trim());
                ret[0]=(strInfo[0].trim());
            } else if ((info.indexOf("OPERA")) > -1) {
                ret[1]=(str[0].trim());
                ret[0]=(strInfo[0].trim());
            } else if (info.indexOf("CHROME") < 0 && info.indexOf("SAFARI") > -1) {
                ret[1]=(str[str.length - 1].trim());
                ret[0]=(strInfo[2].trim());
            } else if (info.indexOf("CHROME") > -1) {
                ret[1]=(str[str.length - 2].trim());
//Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.116 Safari/537.36
                ret[0]=(infoTemp);
            } else if (info.indexOf("NAVIGATOR") > -1) {
                ret[1]=(str[str.length - 1].trim());
                ret[0]=(strInfo[2].trim());
            } else {
                ret[1]=("Unknown Browser");
                ret[0]=("Unknown OS");
            }
        }
        if(StringUtils.containsIgnoreCase(user_agent, "PC")
                || StringUtils.containsIgnoreCase(user_agent,"Windows NT")){
            ret[2]="PC";
        }else if(StringUtils.containsIgnoreCase(user_agent, "IPhone") || StringUtils.containsIgnoreCase(user_agent, "Mobile")){
            ret[2]="PHONE";
        }else if(StringUtils.containsIgnoreCase(user_agent, "ipad") || StringUtils.containsIgnoreCase(user_agent, "pod")){
            ret[2]="PAD";
        }else{
            ret[2]="PC";
        }
        return ret;
    }
    void addRequestDataSize(RequestParameters pars,long requestDataSize){
        try {
            if (null != statHandler) {
                if(null != pars.getTargetNames()) {
                    for(String n:pars.getTargetNames()) {
                        HashMap input = new HashMap();
                        input.put("op", "addRequestDataSize");
                        input.put("srvId", n);
                        pars.setRequestDataSize(requestDataSize);
                        statHandler.doSomeThing(null, pars, input, null, null);
                    }
                }

            }
        }catch (Exception e){
            log.error("add request Data size error",e);
        }
    }
    void addResponseDataSize(RequestParameters pars,long requestDataSize){
        try {
            if (null != statHandler) {
                for(String n:pars.getTargetNames()) {
                    HashMap input = new HashMap();
                    input.put("op", "addResponseDataSize");
                    input.put("srvId", n);
                    pars.setResponseDataSize(requestDataSize);
                    statHandler.doSomeThing(null, pars, input, null, null);
                }
            }
        }catch (Exception e){
            log.error("add request Data size error",e);
        }
    }
    Object getRequestData(HttpServletRequest request,RequestParameters pars) throws Exception {

        boolean isMultipart = ServletFileUpload.isMultipartContent(request);
        if (isMultipart) {//ArrayUtils.isArrayLikeString(pars.getTargetNames(),"upload")
            HashMap<String, InputStream> fileMap=new HashMap<String,InputStream>();
            HashMap<String,Object> iDataMap=new HashMap<String,Object>();
            iDataMap.putAll(pars.getQueryStringMap());

            readReqeustInputStream(request, fileMap, iDataMap);
            iDataMap.put("files",fileMap);
            pars.getQueryStringMap();
            return iDataMap;
        }
        long datasize=0;
        request.setCharacterEncoding("UTF-8");
        String paramStr=null;
        int len = request.getContentLength();
        if(len>0){
            InputStream in =request.getInputStream();
            byte buffer[] = new byte[len];
            int total = 0;
            int once = 0;
            while ((total < len) && (once >=0)) {
                once = in.read(buffer,total,len);
                total += once;
            }

            paramStr = new String(buffer,"UTF-8").trim();
            //add request data size to stat
            datasize+=paramStr.length();
            addRequestDataSize(pars, datasize);

            Map ret=null;
            if(paramStr.startsWith("{")){
                ret= StringUtils.convert2MapJSONObject(paramStr);
            }else if(paramStr.startsWith("[")){
                List rt = StringUtils.convert2ListJSONObject(paramStr);
                return rt;

            }else if(paramStr.contains("=")){
                ret = StringUtils.convertHtmlAndChar2Map(paramStr);
            }
            if(null != ret){
                //接口传进来的数据不进行转换，默认是真实数据。
                //ret = pars.getMapValueFromParameter(ret,this);
                //handvar(ret,pars);
                //ret.putAll(pars.getQueryStringMap());
                return ret;
            }else{
                return paramStr;
            }
        }
        return pars.getQueryStringMap();
    }
    /**
     * get image content from httpServletRequest post String
     * @param str
     * @return
     */
    public static Map<String,InputStream> getImageFromHttpServletRequestPostString(String str){

        if(null != str) {
            String[] ss = str.split("\r\n");
            String name=null;
            HashMap ret = new HashMap();
            StringBuffer sb = new StringBuffer();
            for(int i=0;i<ss.length;i++){
                if(ss[i].indexOf("filename")>0){
                    List<String> fs = StringUtils.getTagsNoMark(ss[i],"filename=\"","\"");
                    if(null != fs && fs.size()==1){
                        name = fs.get(0);
                    }
                }
                if(null != name && (i==ss.length-3 || i==ss.length-2)){
                    sb.append(ss[i]+"\r\n");
                }
            }

            BASE64Decoder decoder = new BASE64Decoder();
            try {
                // Base64解码
                byte[] b = decoder.decodeBuffer(sb.toString());
                for (int i = 0; i < b.length; ++i) {
                    if (b[i] < 0) {// 调整异常数据
                        b[i] += 256;
                    }
                }
                ByteArrayInputStream in = new ByteArrayInputStream(b);
                ret.put(name,in);
            }catch(Exception e){

            }


            if(ret.size()>0){
                return ret;
            }
        }
        return null;
    }
    public static String unicode2String(String unicode) {
        StringBuffer string = new StringBuffer();
        String[] hex = unicode.split("\\\\u");
        for (int i = 1; i < hex.length; i++) {
            // 转换出每一个代码点
            int data = Integer.parseInt(hex[i], 16);
            // 追加成string
            string.append((char) data);
        }
        return string.toString();
    }

    void readReqeustInputStream(HttpServletRequest request,Map<String,InputStream> fileMap,Map<String,Object> iData)throws Exception{

        FileItemFactory factory = new DiskFileItemFactory();
        ServletFileUpload servletFileUpload = new ServletFileUpload(factory);
        //servletFileUpload.setSizeMax(maxPostSize);
        servletFileUpload.setHeaderEncoding("UTF-8");
        List<?> fileItems = servletFileUpload.parseRequest(request);
        for (Object fileItem : fileItems) {
            FileItem item = (FileItem) fileItem;
            if (!item.isFormField()) { // 是文件，默认只传一个
                String fileName = item.getName();
                if (org.apache.commons.lang.StringUtils.isNotBlank(fileName)) {
                    int start = fileName.lastIndexOf("\\");
                    String name = fileName.substring(start + 1, fileName.length());

                    fileMap.put(name, item.getInputStream());
                }
            } else { // 不是文件,为Form表单中的其他信息
                iData.put(item.getFieldName(), item.getString("UTF-8"));
            }
        }

    }

    void handvar(Map ret,RequestParameters pars)throws Exception{
        if(null != ret){
            Iterator ist = ret.keySet().iterator();
            while(ist.hasNext()){
                Object k = ist.next();
                if(ret.get(k) instanceof String){
                    Object o=null;
                    if(((String)ret.get(k)).startsWith("${")){
                        o = ObjectUtils.getValueByPath(pars.getReadOnlyParameter(),(String) ret.get(k));
                    }else{
                        o = pars.getExpressValueFromMap((String) ret.get(k),this);
                    }
                    if(null != o){
                        ret.put(k,o);
                    }else{
                        throw new Exception("not find the value["+ret.get(k)+"]");
                    }

                }else if(ret.get(k) instanceof List){
                    List li = new LinkedList();
                    for(int i=((List)ret.get(k)).size()-1;i>=0;i--){
                        Object o = ((List)ret.get(k)).get(i);
                        ((List)ret.get(k)).remove(o);
                        if(o instanceof Map){
                            handvar((Map)o,pars);
                        }else if(o instanceof String){
                            o = pars.getExpressValueFromMap((String)o,this);
                        }else{
                            throw new Exception("not find the value["+ret.get(k)+"]");
                        }
                        li.add(o);
                    }
                    ((List)ret.get(k)).addAll(li);
                }else if(ret.get(k) instanceof Map){
                    handvar((Map)ret.get(k),pars);
                }
            }
        }
    }

    public void start(String contenxt,String baseResource,int port,int sslport,String ishttps,String keyStoreType,String kstorePath,String storePassword,String managerPassword){
        //web.xml路径
//        String serverWebXml = web+"WEB-INF" +"/web.xml";

        if(StringUtils.isTrue(ishttps)){
            try {
                org.eclipse.jetty.server.Server server = new org.eclipse.jetty.server.Server();
                //server.setThreadPool(new ExecutorThreadPool(25, 50, 30000));

                SslSelectChannelConnector ssl_connector = new SslSelectChannelConnector();
                ssl_connector.setPort(sslport);
                SslContextFactory cf = ssl_connector.getSslContextFactory();
                if(StringUtils.isNotBlank(keyStoreType)) {
                    cf.setKeyStoreType(keyStoreType);
                }
                //cf.setNeedClientAuth(false);
                cf.setKeyStore(kstorePath);
                cf.setKeyStorePassword(storePassword);
                if(StringUtils.isNotBlank(managerPassword)) {
                    cf.setKeyManagerPassword(managerPassword);
                }
                server.addConnector(ssl_connector);
                org.eclipse.jetty.webapp.WebAppContext webapp = new org.eclipse.jetty.webapp.WebAppContext();
                if (StringUtils.isNotBlank(contenxt)) {
                    webapp.setContextPath(contenxt);
                } else {
                    webapp.setContextPath("/");
                }
                webapp.setInitParameter("org.eclipse.jetty.servlet.Default.dirAllowed", "false");
                //webapp.setResourceBase(webContextPath);
                //定位项目中class文件的位置
                webapp.setClassLoader(Thread.currentThread().getContextClassLoader());
                webapp.setBaseResource(org.eclipse.jetty.util.resource.Resource.newClassPathResource(""));

                if (StringUtils.isNotBlank(baseResource)) {
                    webapp.setBaseResource(org.eclipse.jetty.util.resource.Resource.newResource(baseResource));
                    File tmpFile = new File(baseResource + "/web_temp");
                    webapp.setTempDirectory(tmpFile);
                }

//        webapp.setDescriptor(serverWebXml);
                org.eclipse.jetty.servlet.FilterHolder holder = new org.eclipse.jetty.servlet.FilterHolder(new MyFilter(this, null));
                webapp.addFilter(holder, "/*", 0);
                server.setHandler(webapp);
                server.start();
            }catch (Exception e){
                e.printStackTrace();
            }
            System.out.println("web Server [https://"+ NetUtils.getip()+":"+sslport + baseResource + "] is started!");
            /*HttpConfiguration https_config = new HttpConfiguration();
            https_config.setSecureScheme("https");
            https_config.setSecurePort(8443);
            https_config.setOutputBufferSize(32768);
            https_config.addCustomizer(new SecureRequestCustomizer());

            SslContextFactory sslContextFactory = new SslContextFactory();
            sslContextFactory.setKeyStorePath("keystore");
            sslContextFactory.setKeyStorePassword("OBF:1xtb1uo71wg41y0q1y7z1y101wfu1unr1xu7");
            sslContextFactory.setKeyManagerPassword("OBF:1xtb1uo71wg41y0q1y7z1y101wfu1unr1xu7");

            ServerConnector httpsConnector = new ServerConnector(server,
                    new SslConnectionFactory(sslContextFactory,"http/1.1"),
                    new HttpConnectionFactory(https_config));
            httpsConnector.setPort(8443);
            httpsConnector.setIdleTimeout(500000);
            server.addConnector(httpsConnector);

            WebAppContext webApp = new WebAppContext();
            webApp = new WebAppContext();
            webApp.setContextPath("/myapp");
            webApp.setResourceBase("WebRoot");
            webApp.setInitParameter("org.eclipse.jetty.servlet.Default.dirAllowed", "false");
            webApp.setInitParameter("org.eclipse.jetty.servlet.Default.useFileMappedBuffer", "false");
            server.setHandler(webApp);

            try {
                server.start();
            } catch (Exception e) {
                e.printStackTrace();
            }*/

            /*int IDLE_THREAD_NUM=100;
            HttpConfiguration https_config = new HttpConfiguration();
            https_config.setSecureScheme("https");
            SslContextFactory sslContextFactory = new SslContextFactory();
            sslContextFactory.setKeyStorePath("C:/work/umobile/CRM_R318/treasurebag/config/keystore");
            // 私钥
            sslContextFactory.setKeyStorePassword("Treasure Bag");
            // 公钥
            sslContextFactory.setKeyManagerPassword("Treasure Bag");
            ServerConnector httpsConnector = new ServerConnector(server,
                    new SslConnectionFactory(sslContextFactory,"http/1.1"),
                    new HttpConnectionFactory(https_config));
            // 设置访问端口
            httpsConnector.setPort(8090);
            httpsConnector.setIdleTimeout(IDLE_THREAD_NUM);
            server.addConnector(httpsConnector);

            WebAppContext webApp = new WebAppContext();
            webApp = new WebAppContext();
            webApp.setContextPath("/");
            webApp.setResourceBase("./webapp");
            server.setHandler(webApp);*/

        }
        if(port>0)
        {
            Server server = new Server(port);
            //server.setThreadPool(new QueuedThreadPool(300));
            WebAppContext webapp = new WebAppContext();
            //设置加载目录，相当于tomcat中的webapps
            if (StringUtils.isNotBlank(contenxt)) {
                webapp.setContextPath(contenxt);
            } else {
                webapp.setContextPath("/");
            }
            //webapp.setResourceBase(webContextPath);
            //定位项目中class文件的位置
            webapp.setClassLoader(Thread.currentThread().getContextClassLoader());
            webapp.setBaseResource(Resource.newClassPathResource(""));
            try {
                if (StringUtils.isNotBlank(baseResource)) {
                    webapp.setBaseResource(Resource.newResource(baseResource));
                    File tmpFile = new File(baseResource + "/web_temp");
                    webapp.setTempDirectory(tmpFile);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
//        webapp.setDescriptor(serverWebXml);
            FilterHolder holder = new FilterHolder(new MyFilter(this, null));
            webapp.addFilter(holder, "/*", 0);
            //webapp.setAllowNullPathInfo(false);
            //webapp.addFilter(holder, "/*", EnumSet.of(DispatcherType.REQUEST));
            /*ServletHolder servletHolder = new ServletHolder(new DefaultServlet());
            Map<String, String> params = ImmutableMap. <String, String> builder()
                    .put("acceptRanges", "true")
                    .put("dirAllowed", "false")
                    .put("gzip", "true")
                    .put("useFileMappedBuffer", "true")
                    .build();
            holder.setInitParameters(params);
            webapp.addServlet(servletHolder,"/");*/
            server.setHandler(webapp);

            try {
                server.start();
            } catch (Exception e) {
                e.printStackTrace();
            }
            System.out.println("web Server [http://"+ NetUtils.getip()+":"+port + baseResource + "] is started!");
        }

    }
    class MyFilter implements Filter {
        ILauncher launcher;
        String home;
        public MyFilter(ILauncher launcher,String home){
            this.launcher =launcher;
            this.home=home;
        }
        @Override
        public void init(FilterConfig filterConfig) throws ServletException {
            if(null != home) {
                launcher.addEnv(Env.KEY_HOME, home);
            }
        }

        @Override
        public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
            HttpServletResponse response = (HttpServletResponse)servletResponse;
            HttpServletRequest request = (HttpServletRequest)servletRequest;

            long l = System.currentTimeMillis();
            try{
                Object ret = launcher.invoke(new Object[]{servletRequest,servletResponse});
                if(log.isDebugEnabled()) {
                    log.debug(ret);
                }
                if(null != ret){
                    String rsp = ret.toString();
                    if(rsp.startsWith("{") || rsp.startsWith("["))
                        response.setContentType("application/json;charset=UTF-8");
                    else if(ret instanceof String && ((String)ret).startsWith("<script")){
                        response.setContentType("text/html;charset=UTF-8");
                    }else
                        response.setContentType("application/text;charset=UTF-8");

                    response.getOutputStream().write(ret.toString().getBytes("UTF-8"));
                    response.flushBuffer();
                }else if(!response.isCommitted()){
                    //System.out.println("--websocket--");
                    request.getSession().setAttribute("WEB-Launcher",launcher);

                    filterChain.doFilter(request,response);
                }
            }catch(Exception e){
                if(null != request.getQueryString()) {
                    log.error("request error:" + request.getRequestURL().toString() + "/" + request.getQueryString(), e);
                }else{
                    log.error("request error:" + request.getRequestURL().toString(), e);
                }
            }finally {
                if(log.isInfoEnabled()) {
                    log.info("http tootle:"+request.getRequestURI()+(request.getQueryString()==null?"":"?"+URLDecoder.decode(request.getQueryString()))+"   " + (System.currentTimeMillis() - l)+"ms");
                }
            }
        }

        @Override
        public void destroy() {

        }
    }
}
