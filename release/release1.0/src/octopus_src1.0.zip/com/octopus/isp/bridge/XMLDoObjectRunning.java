package com.octopus.isp.bridge;

import com.octopus.isp.ds.RequestParameters;
import com.octopus.utils.xml.auto.XMLDoObject;

public class XMLDoObjectRunning
  implements Runnable
{
  XMLDoObject object;
  RequestParameters parameters;

  public XMLDoObjectRunning(XMLDoObject object, RequestParameters parameters)
  {
    this.object = object;
    this.parameters = parameters;
  }

  public void run() {
    try {
      this.object.doSomeThing(null, this.parameters, null, null, null);
    } catch (Exception e) {
      this.parameters.setError(true);
      this.parameters.setException(e);
    }
  }
}