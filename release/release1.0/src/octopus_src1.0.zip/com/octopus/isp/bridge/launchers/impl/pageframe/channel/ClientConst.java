package com.octopus.isp.bridge.launchers.impl.pageframe.channel;

public abstract interface ClientConst
{
  public static class Screen
  {
    public static String SCREEN_WIDTH = "SCREEN_WIDTH";
    public static String SCREEN_HEIGHT = "SCREEN_HEIGHT";
    public static String PIX_WIDTH = "PIX_WIDTH";
    public static String PIX_HEIGHT = "PIX_HEIGHT";
  }

  public static class Browser
  {
    public static String NAVIGATOR = "NAVIGATOR";
    public static String FIREFOX = "FIREFOX";
    public static String MSIE = "MSIE";
    public static String CHROME = "CHROME";
    public static String SAFARI = "SAFARI";
    public static String OPERA = "OPERA";
  }

  public static class ClientKind
  {
    public static String PC = "pc";
    public static String PHONE = "phone";
    public static String PAD = "pad";
  }
}