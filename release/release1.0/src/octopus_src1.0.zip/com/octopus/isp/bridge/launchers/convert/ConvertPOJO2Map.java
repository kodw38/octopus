package com.octopus.isp.bridge.launchers.convert;

import com.octopus.isp.bridge.launchers.IConvert;
import com.octopus.utils.cls.POJOUtil;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;

public class ConvertPOJO2Map extends XMLObject
  implements IConvert
{
  public ConvertPOJO2Map(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void notifyObject(String op, Object obj)
    throws Exception
  {
  }

  public void destroy()
    throws Exception
  {
  }

  public void initial()
    throws Exception
  {
  }

  public Object convert(Object par) throws Exception
  {
    if (null == par) return null;
    if (!(POJOUtil.isSimpleType(par.getClass().getName())))
      return POJOUtil.convertPojo2Map(par, null);

    return par;
  }
}