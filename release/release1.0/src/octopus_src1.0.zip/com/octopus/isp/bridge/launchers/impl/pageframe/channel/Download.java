package com.octopus.isp.bridge.launchers.impl.pageframe.channel;

import com.octopus.isp.ds.RequestParameters;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;

public class Download extends XMLDoObject
{
  public Download(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    RequestParameters requestParam = (RequestParameters)env;
    Map queryStringMap = requestParam.getQueryStringMap();

    if (requestParam.getRequestProperties().get("Method").equals("GET"))
    {
      HttpServletResponse response = (HttpServletResponse)requestParam.get("${response}");

      String fileData = (String)input.get("filedata");
      if (StringUtils.isNotEmpty(fileData)) {
        byte[] datas = fileData.getBytes("UTF-8");

        String wsName = URLDecoder.decode((String)queryStringMap.get("filename"), "ISO8859_1");

        String extend = (String)queryStringMap.get("filetype");
        StringBuffer fileName = new StringBuffer(wsName);
        if (StringUtils.isNotEmpty(extend))
          fileName.append(".").append(extend);

        response.setContentType("application/octet-stream;charset=UTF-8");
        response.setHeader("Content-disposition", "attachment; filename=" + fileName.toString());

        response.getOutputStream().write(datas);

        response.flushBuffer();
        requestParam.setStop();
      }
      else if (("download".equals(requestParam.getRequestResourceName())) || ("downloadFile".equals(requestParam.getRequestResourceName()))) {
        String f = (String)queryStringMap.get("file");
        String p = "/" + ((String)queryStringMap.get("childPath"));

        String fileName = URLDecoder.decode(f, "ISO8859_1");
        response.setContentType("application/x-msdownload");
        String name = f;
        if (f.contains("/"))
          name = f.substring(f.lastIndexOf("/") + 1);

        if (f.contains("\\"))
          name = f.substring(f.lastIndexOf("\\") + 1);

        response.setHeader("Content-disposition", "attachment; filename=" + name);
        InputStream in = null;
        try {
          StringBuffer pt = new StringBuffer();
          if ((input.containsKey("path")) && (!(XMLParameter.isHasRetainChars((String)input.get("path")))))
            pt.append(input.get("path"));

          if (StringUtils.isNotBlank(p))
            pt.append(p).append("/");

          if (StringUtils.isNotBlank(f))
            pt.append(f);

          log.error("download file " + pt.toString());

          in = new FileInputStream(new File(pt.toString()));

          byte[] b = new byte[1024];
          int i = 0;
          while ((i = in.read(b)) != -1)
            response.getOutputStream().write(b, 0, i);

          response.flushBuffer();
        } finally {
          if (null != in)
            in.close();

          requestParam.setStop();
        }
      }
    }
    return null;
  }

  public void doInitial()
    throws Exception
  {
  }

  public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    return true;
  }

  public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return new ResultCheck(true, ret);
  }

  public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return false;
  }

  public boolean rollback(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret, Exception e) throws Exception
  {
    return false;
  }
}