package com.octopus.isp.bridge.launchers.impl.pageframe.channel;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URLDecoder;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.octopus.utils.alone.ArrayUtils;
import com.octopus.utils.exception.Logger;
import org.apache.commons.lang.StringUtils;

import com.octopus.isp.ds.RequestParameters;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;

/**
 * User: wfgao_000
 * Date: 16-2-1
 * Time: 下午3:46
 */
public class Download extends XMLDoObject {
    public Download(XMLMakeup xml, XMLObject parent,Object[] containers) throws Exception {
        super(xml, parent,containers);
    }

    @Override
    public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception {
    	RequestParameters requestParam = (RequestParameters)env;
    	Map queryStringMap = requestParam.getQueryStringMap();
    	//GET请求
    	if(requestParam.getRequestProperties().get("Method").equals("GET")){
    		//打开输出流
            HttpServletResponse response = (HttpServletResponse)requestParam.get("${response}");
	        //获取input中的文件内容
            String fileData = (String) input.get("filedata");
	        if(StringUtils.isNotEmpty(fileData)){
	        	byte[] datas = fileData.getBytes("UTF-8");
	        	//获取请求参数中的方法名
	        	String wsName = URLDecoder.decode((String)queryStringMap.get("filename"), "ISO8859_1");
	        	//获取请求参数中的文件扩展名
	        	String extend = (String)queryStringMap.get("filetype");
	        	StringBuffer fileName= new StringBuffer(wsName);
	        	if(StringUtils.isNotEmpty(extend))
	        		fileName.append(".").append(extend);
	        	//设置头
	        	response.setContentType("application/octet-stream;charset=UTF-8");
	            response.setHeader("Content-disposition", "attachment; filename="+fileName.toString());
	        	//写入
	            response.getOutputStream().write(datas);
	        	//关闭
	            response.flushBuffer();
	        	requestParam.setStop();
	        }
	        else if("download".equals(requestParam.getRequestResourceName())||"downloadFile".equals(requestParam.getRequestResourceName())){
	            String f = (String)queryStringMap.get("file");
	            String p = null == queryStringMap.get("childPath") ? ""
	            		: "/" + (String)queryStringMap.get("childPath");
	            String fileName = URLDecoder.decode(f, "ISO8859_1");
	            response.setContentType("application/x-msdownload");
                String name = f;
                if(f.contains("/")){
                    name = f.substring(f.lastIndexOf("/")+1);
                }
                if(f.contains("\\")){
                    name = f.substring(f.lastIndexOf("\\")+1);
                }
	            response.setHeader("Content-disposition", "attachment; filename="+ name);
	            InputStream in = null;
	            try {
                    StringBuffer pt = new StringBuffer();
                    if(input.containsKey("path") && !XMLParameter.isHasRetainChars((String)input.get("path"))) {
                        pt.append(input.get("path"));
                    }
                    if(StringUtils.isNotBlank(p)) {
                        pt.append(p).append("/");
                    }
                    if(StringUtils.isNotBlank(f)) {
                        pt.append(f);
                    }
                    log.error("download file " + pt.toString());

		            in = new FileInputStream(
		            		new File(pt.toString()));
		            byte [] b= new byte[1024];
		            int i = 0;
		            while((i=in.read(b))!= -1){
		                response.getOutputStream().write(b, 0, i);
		            }
		            response.flushBuffer();
	            }finally {
	            	if(null != in) {
	            		in.close();
	            	}
		    		requestParam.setStop();
				}
	        }
        }
        return null;
    }

    @Override
    public void doInitial() throws Exception {

    }

    @Override
    public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception {
        return true;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception {
        return new ResultCheck(true,ret);  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception {
        return false;
    }

    @Override
    public boolean rollback(String xmlid, XMLParameter env, Map input, Map output, Map config,Object ret,Exception e) throws Exception {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
