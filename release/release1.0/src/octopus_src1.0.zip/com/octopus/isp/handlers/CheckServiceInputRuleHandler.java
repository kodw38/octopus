package com.octopus.isp.handlers;

import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.cls.proxy.IMethodAddition;
import com.octopus.utils.exception.ISPException;
import com.octopus.utils.rule.RuleUtil;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class CheckServiceInputRuleHandler extends XMLDoObject
  implements IMethodAddition
{
  static transient Log log = LogFactory.getLog(CheckServiceInputRuleHandler.class);
  List<String> methods;
  boolean isWaitBefore;
  boolean isWaitAfter;
  boolean isWaitResult;
  boolean isNextInvoke;
  Map in = null;
  XMLDoObject cache_srv_rule;
  int level;
  static Map defineRuleElement = null;

  public CheckServiceInputRuleHandler(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
    this.isWaitBefore = StringUtils.isTrue(xml.getProperties().getProperty("iswaitebefore"));
    this.isWaitAfter = StringUtils.isTrue(xml.getProperties().getProperty("iswaitafter"));
    this.isWaitResult = StringUtils.isTrue(xml.getProperties().getProperty("iswaitresult"));
    this.isNextInvoke = StringUtils.isTrue(xml.getProperties().getProperty("isnextinvoke"));
  }

  public Object beforeAction(Object impl, String m, Object[] args)
    throws Exception
  {
    if (null != impl) {
      Map data = getDataMap(args);
      String id = ((XMLObject)impl).getXML().getId();
      List rules = getRuleByActionId((XMLParameter)args[1], id);
      if (null != rules)
        for (Iterator i$ = rules.iterator(); i$.hasNext(); ) { Map rule = (Map)i$.next();
          if ((null != rule) && (StringUtils.isNotBlank(rule.get("RULE"))) && 
            (null != data)) {
            Object rul = ((XMLParameter)args[1]).getExpressValueFromMap((String)rule.get("RULE"), this);
            if (rul instanceof String) {
              Object o = RuleUtil.doRule((String)rul, data);
              if ((null != o) && (o instanceof Boolean) && (!(((Boolean)o).booleanValue())))
                throw new ISPException("600", "check [" + id + "] input parameters fail: " + ((XMLParameter)args[1]).getValueFromExpress(rule.get("NOT_CHECK_MESSAGE"), this));
            }
          }

        }


      log.error(((XMLObject)impl).getXML().getId() + " " + m + " do check input...");
    }
    return null;
  }

  List<Map> getRuleByActionId(XMLParameter env, String s) {
    HashMap in;
    try {
      in = new HashMap();

      in.put("op", "get");
      in.put("key", s);
      List ret = (List)this.cache_srv_rule.doSomeThing(null, env, in, null, null);
      if (null != ret)
        return ret;

      return null;
    }
    catch (Exception e) {
      log.error("get rule by serviceId fail", e);

      return null; }
  }

  Map getDataMap(Object[] args) {
    if ((args.length > 1) && 
      (args[1] instanceof Map)) {
      Map m = (Map)args[1];
      if (null == defineRuleElement)
        defineRuleElement = initDefineRuleElement(m);

      if (null != defineRuleElement)
        m.putAll(defineRuleElement);

      return m;
    }

    return null; }

  Map initDefineRuleElement(Map m) {
    Map c = (Map)m.get("${constant}");
    if (null != c) {
      HashMap ret = new HashMap();
      Map s = (Map)c.get("serviceinputcheckrules");
      if (null != s) {
        Iterator it = s.keySet().iterator();
        while (it.hasNext()) {
          String k = (String)it.next();
          String v = (String)s.get(k);
          if ((StringUtils.isNotBlank(k)) && (StringUtils.isNotBlank(v)))
            try
            {
              Object re = Class.forName(v).newInstance();
              ret.put(k, re);
            } catch (InstantiationException e) {
              log.error(e);
            } catch (IllegalAccessException e) {
              log.error(e);
            } catch (ClassNotFoundException e) {
              log.error(e);
            }
        }

      }

      if (ret.size() > 0) return ret;
    }
    return null;
  }

  public Object afterAction(Object impl, String m, Object[] args, boolean isInvoke, boolean isSuccess, Throwable e, Object result)
  {
    return null;
  }

  public Object resultAction(Object impl, String m, Object[] args, Object result)
  {
    return null;
  }

  public int getLevel()
  {
    return this.level;
  }

  public boolean isWaiteBefore()
  {
    return this.isWaitBefore;
  }

  public boolean isWaiteAfter()
  {
    return this.isWaitAfter;
  }

  public boolean isWaiteResult()
  {
    return this.isWaitResult;
  }

  public boolean isNextInvoke()
  {
    return this.isNextInvoke;
  }

  public void setMethods(List<String> methods)
  {
    this.methods = methods;
  }

  public List<String> getMethods()
  {
    return this.methods;
  }

  public void doInitial()
    throws Exception
  {
  }

  public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    return true;
  }

  public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    return null;
  }

  public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return null;
  }

  public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return false;
  }

  public boolean rollback(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret, Exception e) throws Exception
  {
    return false;
  }
}