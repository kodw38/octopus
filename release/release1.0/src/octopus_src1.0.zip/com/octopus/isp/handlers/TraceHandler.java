package com.octopus.isp.handlers;

import com.octopus.isp.ds.Env;
import com.octopus.isp.ds.RequestParameters;
import com.octopus.utils.alone.ObjectUtils;
import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.cls.proxy.IMethodAddition;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class TraceHandler extends XMLDoObject
  implements IMethodAddition
{
  static transient Log log = LogFactory.getLog(TraceHandler.class);
  List<String> methods = new ArrayList();
  boolean isWaitBefore = false;
  boolean isWaitAfter = false;
  boolean isWaitResult = false;
  boolean isNextInvoke = false;
  Map in = null;
  XMLDoObject store;
  Map tempDate = new HashMap();
  long curtime = 0L;
  boolean isstart = false;
  int expire = 180;

  public TraceHandler(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
    String input = xml.getProperties().getProperty("input");
    if (StringUtils.isNotBlank(input))
      this.in = StringUtils.convert2MapJSONObject(input);

    this.isWaitBefore = StringUtils.isTrue(xml.getProperties().getProperty("iswaitebefore"));
    this.isWaitAfter = StringUtils.isTrue(xml.getProperties().getProperty("iswaitafter"));
    this.isWaitResult = StringUtils.isTrue(xml.getProperties().getProperty("iswaitresult"));
    this.isNextInvoke = StringUtils.isTrue(xml.getProperties().getProperty("isnextinvoke")); }

  void listenerState() {
    if ((this.curtime > 0L) && ((System.currentTimeMillis() - this.curtime) / 1000L > this.expire))
      this.isstart = false;
  }

  Map getInfo(String method, String type, RequestParameters req, XMLMakeup xml, XMLObject impl, Object data, boolean issuccess, Throwable er) {
    Map map = new HashMap();

    map.put("RequestId", req.getRequestId());
    map.put("Method", method);
    map.put("Position", type);
    if (xml == null) xml = impl.getXML();
    List cs = xml.getChildren();
    if (null != cs) {
      List li = new ArrayList();
      for (Iterator i$ = cs.iterator(); i$.hasNext(); ) { XMLMakeup c = (XMLMakeup)i$.next();
        li.add(c.getId());
      }
      if (li.size() > 0)
        map.put("Children", li);
    }

    map.put("RequestDate", req.getRequestDate());
    map.put("SrvName", xml.getId());
    if (null != xml.getParent())
      map.put("Path", xml.getParent().getId());
    else
      map.put("Path", "");

    Date curDate = new Date();
    map.put("CurDate", curDate);

    map.put("State", Boolean.valueOf(issuccess));
    if (null != er) {
      String msg = ExceptionUtils.getFullStackTrace(er);
      msg = msg.replaceAll("\r\n", "</br>");
      msg = msg.replaceAll("\t", "");
      map.put("Error", msg);
    } else if (null != data) {
      map.put("Data", data);
    }
    if (this.tempDate.containsKey(req.getRequestId()))
      map.put("Cost", Long.valueOf(curDate.getTime() - ((Long)this.tempDate.get(req.getRequestId())).longValue()));
    else {
      this.tempDate.put(req.getRequestId(), Long.valueOf(curDate.getTime()));
    }

    map.put("ThreadName", Thread.currentThread().getName());

    map.put("ThreadState", Thread.currentThread().getState().toString());
    map.put("ThreadGroup", Thread.currentThread().getThreadGroup().toString());
    map.put("ThreadPriority", Integer.valueOf(Thread.currentThread().getPriority()));

    map.put("IP", req.getEnv().get("${ip}"));
    try {
      map.put("PID", req.getEnv().get("${pid}"));
    } catch (Exception xe) {
    }
    log.debug("trace:" + map);
    return map;
  }

  public Object beforeAction(Object impl, String m, Object[] args) throws Exception {
    if (this.isstart) {
      if ((null != m) && ("doChildren".equals(m))) return null;
      if ((null != this.store) && 
        (impl instanceof XMLObject) && (args[0] instanceof RequestParameters) && (null != ((RequestParameters)args[0]).getRequestId())) {
        Object data = ((RequestParameters)args[0]).get("${this_input}");
        if (data == null)
          data = ((RequestParameters)args[0]).get("${input_data}");

        Map d = getInfo(m, "Before", (RequestParameters)args[0], (XMLMakeup)args[1], (XMLObject)impl, data, true, null);
        HashMap it = new HashMap();
        it.put("key", d.get("RequestId"));
        it.put("value", ObjectUtils.convertMap2String(d));
        if (null != this.in) {
          Map ol = RequestParameters.getMapValueFromParameter((RequestParameters)args[0], this.in, this);
          if (null != ol)
            it.putAll(ol);

        }

        log.debug("before:" + ((XMLMakeup)args[1]).getId());
        this.store.doSomeThing(null, (RequestParameters)args[0], it, null, null);
      }

      listenerState();
    }
    return null;
  }

  public Object afterAction(Object impl, String m, Object[] args, boolean isInvoke, boolean isSuccess, Throwable e, Object result)
  {
    if (this.isstart) {
      if ((null != m) && ("doChildren".equals(m))) return null;
      if ((null != this.store) && 
        (impl instanceof XMLObject) && (args[0] instanceof RequestParameters) && (null != ((RequestParameters)args[0]).getRequestId()))
        try {
          if (null == result)
          {
            result = ((ResultCheck)((RequestParameters)args[0]).getResult()).getRet();
          }
          Map d = getInfo(m, "After", (RequestParameters)args[0], (XMLMakeup)args[1], (XMLObject)impl, result, isSuccess, e);

          HashMap it = new HashMap();
          it.put("key", d.get("RequestId"));
          it.put("value", ObjectUtils.convertMap2String(d));
          if (null != this.in) {
            Map ol = RequestParameters.getMapValueFromParameter((RequestParameters)args[0], this.in, this);
            if (null != ol)
              it.putAll(ol);

          }

          log.debug("after:" + ((XMLMakeup)args[1]).getId());
          this.store.doSomeThing(null, (RequestParameters)args[0], it, null, null);
        }
        catch (Exception ee)
        {
        }


      listenerState();
    }
    return null;
  }

  public Object resultAction(Object impl, String m, Object[] args, Object result)
  {
    return null;
  }

  public int getLevel()
  {
    return 0;
  }

  public boolean isWaiteBefore()
  {
    return this.isWaitBefore;
  }

  public boolean isWaiteAfter()
  {
    return this.isWaitAfter;
  }

  public boolean isWaiteResult()
  {
    return this.isWaitResult;
  }

  public boolean isNextInvoke()
  {
    return this.isNextInvoke;
  }

  public void setMethods(List<String> methods)
  {
    this.methods = methods;
  }

  public List<String> getMethods()
  {
    return this.methods;
  }

  public void notifyObject(String op, Object obj)
    throws Exception
  {
  }

  public void doInitial()
    throws Exception
  {
  }

  public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    return true;
  }

  public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    if (null != input) {
      Map map;
      if ((null != input.get("op")) && ("start".equals(input.get("op")))) {
        this.curtime = System.currentTimeMillis();
        if (null != input.get("expire"))
          this.expire = ((Integer)input.get("expire")).intValue();

        this.isstart = true;
        log.info("start trace.....");
      }
      if ((null != input.get("op")) && ("stop".equals(input.get("op")))) {
        this.curtime = 0L;
        this.isstart = false;
        map = new HashMap();
        if (null != this.in)
          map.putAll(this.in);

        map.put("op", "clear");
        this.store.doSomeThing(null, null, map, null, null);
        log.info("end trace....."); } else {
        if ("getTraceList".equals(input.get("op"))) {
          map = new HashMap();
          if (null != this.in)
            map.putAll(this.in);

          map.put("op", "keys");
          map.put("value", input.get("data"));
          return this.store.doSomeThing(null, null, map, null, null); }
        if ("getTrace".equals(input.get("op"))) {
          map = new HashMap();
          if (null != this.in)
            map.putAll(this.in);

          map.put("op", "lget");
          map.put("key", input.get("data"));
          return this.store.doSomeThing(null, null, map, null, null); }
      }
    }
    return null;
  }

  public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return new ResultCheck(true, ret);
  }

  public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return false;
  }

  public boolean rollback(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret, Exception e) throws Exception
  {
    return false;
  }
}