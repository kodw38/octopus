package com.octopus.isp.handlers;

import com.octopus.isp.ds.RequestParameters;
import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.cls.proxy.IMethodAddition;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class SVRedoHandler extends XMLDoObject
  implements IMethodAddition
{
  XMLDoObject suspendTheRequest;
  List<String> methods;
  boolean isWaitBefore;
  boolean isWaitAfter;
  boolean isWaitResult;
  boolean isNextInvoke;
  Map in = null;
  Map ids = new HashMap();

  public SVRedoHandler(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
    this.isWaitBefore = StringUtils.isTrue(xml.getProperties().getProperty("iswaitebefore"));
    this.isWaitAfter = StringUtils.isTrue(xml.getProperties().getProperty("iswaitafter"));
    this.isWaitResult = StringUtils.isTrue(xml.getProperties().getProperty("iswaitresult"));
    this.isNextInvoke = StringUtils.isTrue(xml.getProperties().getProperty("isnextinvoke"));
  }

  public Object beforeAction(Object impl, String m, Object[] args)
    throws Exception
  {
    if (((XMLObject)impl).isRedo()) {
      String s = (String)((XMLParameter)args[0]).getParameter("${requestId}");
      if ((StringUtils.isNotBlank(s)) && (!(this.ids.containsKey(s)))) {
        XMLMakeup x = (XMLMakeup)args[1];
        if (null != x)
          this.ids.put(s, x.getId());
        else
          this.ids.put(s, ((XMLObject)impl).getXML().getId());
      }
    }

    return null;
  }

  public Object afterAction(Object impl, String m, Object[] args, boolean isInvoke, boolean isSuccess, Throwable e, Object result)
  {
    String s;
    try
    {
      s = ((RequestParameters)args[0]).getRequestId();
      String id = null;
      if (null == (XMLMakeup)args[1])
        id = ((XMLObject)impl).getXML().getId();
      else
        id = ((XMLMakeup)args[1]).getId();

      if ((StringUtils.isNotBlank(s)) && (impl instanceof XMLObject) && 
        (this.ids.containsKey(s)) && (this.ids.get(s).equals(id))) {
        this.ids.remove(s);
        if (null != e) {
          if (null == this.suspendTheRequest)
            this.suspendTheRequest = ((XMLDoObject)getObjectById("suspendTheRequest"));

          ((XMLParameter)args[0]).setSuspendXMlId(id);
          ((XMLObject)impl).getXML().getProperties().put("nodeid", id);
          this.suspendTheRequest.doThing((XMLParameter)args[0], (XMLMakeup)args[1]);
        }
      }
    }
    catch (Exception ex)
    {
    }

    return null;
  }

  public Object resultAction(Object impl, String m, Object[] args, Object result)
  {
    return null;
  }

  public int getLevel()
  {
    return 0;
  }

  public boolean isWaiteBefore()
  {
    return false;
  }

  public boolean isWaiteAfter()
  {
    return false;
  }

  public boolean isWaiteResult()
  {
    return false;
  }

  public boolean isNextInvoke()
  {
    return false;
  }

  public void setMethods(List<String> methods)
  {
    this.methods = methods;
  }

  public List<String> getMethods()
  {
    return this.methods;
  }

  public void doInitial()
    throws Exception
  {
  }

  public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    return false;
  }

  public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    return null;
  }

  public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return null;
  }

  public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return false;
  }

  public boolean rollback(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret, Exception e) throws Exception
  {
    return false;
  }
}