package com.octopus.isp.handlers;

import com.octopus.utils.alone.ArrayUtils;
import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.cls.proxy.IMethodAddition;
import com.octopus.utils.exception.ExceptionUtil;
import com.octopus.utils.exception.Logger;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.ResultCheck;
import com.octopus.utils.xml.auto.XMLDoObject;
import com.octopus.utils.xml.auto.XMLParameter;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.apache.commons.logging.Log;

public class FileLogHandler extends XMLDoObject
  implements IMethodAddition
{
  XMLDoObject logger;
  List<String> methods;
  boolean isWaitBefore;
  boolean isWaitAfter;
  boolean isWaitResult;
  boolean isNextInvoke;
  Map in = null;

  public FileLogHandler(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
    this.isWaitBefore = StringUtils.isTrue(xml.getProperties().getProperty("iswaitebefore"));
    this.isWaitAfter = StringUtils.isTrue(xml.getProperties().getProperty("iswaitafter"));
    this.isWaitResult = StringUtils.isTrue(xml.getProperties().getProperty("iswaitresult"));
    this.isNextInvoke = StringUtils.isTrue(xml.getProperties().getProperty("isnextinvoke"));
  }

  public Object beforeAction(Object impl, String m, Object[] args) throws Exception {
    HashMap in;
    try {
      in = new HashMap();
      in.put("code", "DETAIL_LOG");
      in.put("op", "exist");
      Object o = this.logger.doSomeThing(null, null, in, null, null);
      if ((null != o) && (o instanceof Boolean) && (((Boolean)o).booleanValue())) {
        in.remove("op");
        String head = null;
        XMLMakeup cur = null;
        String reqid = null;
        String pars = null;
        if ((args.length == 2) && (null != args[1]))
          cur = (XMLMakeup)args[1];
        else
          cur = ((XMLObject)impl).getXML();

        if ((args.length == 2) && (null != args[0])) {
          synchronized (args[0]) {
            reqid = (String)((XMLParameter)args[0]).get("${requestId}");
            pars = new StringBuilder().append(" - input parameters: ").append(((Map)args[0]).get("${input_data}")).toString();
            Object ns = ((XMLParameter)args[0]).get("${targetNames}");
            if (null != ns)
              if (Collection.class.isAssignableFrom(ns.getClass()))
                in.put("subFileName", ArrayUtils.toJoinString((Collection)ns));
              else if (ns.getClass().isArray())
                in.put("subFileName", ArrayUtils.toJoinString((Object[])(Object[])ns));

            else
              in.put("subFileName", cur.getId());
          }
        }
        else {
          reqid = "";
          in.put("subFileName", cur.getId());
        }

        head = Logger.getString((XMLParameter)args[0], (String)in.get("subFileName"), "", getClass().getName(), null);
        in.put("data", new StringBuilder().append(head).append(" - Type: Input ").append(pars).toString());

        this.logger.doSomeThing(null, null, in, null, null);
      }
    } catch (Exception ex) {
      log.error("", ex);
    }

    return null;
  }

  public Object afterAction(Object impl, String m, Object[] args, boolean isInvoke, boolean isSuccess, Throwable e, Object result)
  {
    if ((null != e) && (impl instanceof XMLObject) && (null != this.logger))
      try {
        HashMap in = new HashMap();
        in.put("code", "DETAIL_LOG");
        in.put("op", "exist");
        String head = null;
        XMLMakeup cur = null;
        String reqid = null;
        String pars = null;
        Object ns = null;
        if ((args.length == 2) && (null != args[1]))
          cur = (XMLMakeup)args[1];
        else
          cur = ((XMLObject)impl).getXML();

        if ((args.length == 2) && (null != args[0])) {
          reqid = (String)((XMLParameter)args[0]).get("${requestId}");
          ns = ((XMLParameter)args[0]).get("${targetNames}");
          if (null != ns)
            if (Collection.class.isAssignableFrom(ns.getClass()))
              in.put("subFileName", ArrayUtils.toJoinString((Collection)ns));
            else if (ns.getClass().isArray())
              in.put("subFileName", ArrayUtils.toJoinString((Object[])(Object[])ns));

          else
            in.put("subFileName", cur.getId());
        }
        else {
          reqid = "";
          in.put("subFileName", cur.getId());
        }

        Object o = this.logger.doSomeThing(null, null, in, null, null);
        if ((null != o) && (o instanceof Boolean) && (((Boolean)o).booleanValue())) {
          in.remove("op");

          head = Logger.getString((XMLParameter)args[0], ((XMLObject)impl).getXML().getId(), "", getClass().getName(), e);
          in.put("data", new StringBuilder().append(head).append(" - Type: Output").append("").toString());

          this.logger.doSomeThing(null, null, in, null, null);
        }
        if (null == ((XMLParameter)args[0]).get("^isPrintThrowError")) {
          in.put("code", "SERVICE_ERROR_LOG");
          in.put("op", "exist");
          o = this.logger.doSomeThing(null, null, in, null, null);
          if ((null != o) && (o instanceof Boolean) && (((Boolean)o).booleanValue())) {
            in.remove("op");

            head = Logger.getString((XMLParameter)args[0], ((XMLObject)impl).getXML().getId(), "", getClass().getName(), e);
            in.put("data", new StringBuilder().append(head).append("\n - Type Output \n").append(" - input parameter:").append(((Map)args[0]).get("${input_data}")).append("\n").append(ExceptionUtil.getString(e)).toString());
            this.logger.doSomeThing(null, null, in, null, null);
            ((XMLParameter)args[0]).putGlobal("^isPrintThrowError", "Y");
          }

        }

      }
      catch (Exception ex)
      {
        log.error("", ex);
      }

    return null;
  }

  public Object resultAction(Object impl, String m, Object[] args, Object result)
  {
    return null;
  }

  public int getLevel()
  {
    return 0;
  }

  public boolean isWaiteBefore()
  {
    return false;
  }

  public boolean isWaiteAfter()
  {
    return false;
  }

  public boolean isWaiteResult()
  {
    return false;
  }

  public boolean isNextInvoke()
  {
    return true;
  }

  public void setMethods(List<String> methods)
  {
    this.methods = methods;
  }

  public List<String> getMethods()
  {
    return this.methods;
  }

  public void doInitial()
    throws Exception
  {
  }

  public boolean checkInput(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    return false;
  }

  public Object doSomeThing(String xmlid, XMLParameter env, Map input, Map output, Map config) throws Exception
  {
    return null;
  }

  public ResultCheck checkReturn(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return null;
  }

  public boolean commit(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret) throws Exception
  {
    return false;
  }

  public boolean rollback(String xmlid, XMLParameter env, Map input, Map output, Map config, Object ret, Exception e) throws Exception
  {
    return false;
  }
}