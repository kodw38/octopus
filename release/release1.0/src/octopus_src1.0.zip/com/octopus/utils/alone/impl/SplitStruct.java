package com.octopus.utils.alone.impl;

import java.util.LinkedList;
import java.util.List;

public class SplitStruct
{
  String supplus;
  List points;

  public SplitStruct()
  {
    this.points = new LinkedList(); }

  public String getSupplus() {
    return this.supplus;
  }

  public void setSupplus(String supplus) {
    this.supplus = supplus;
  }

  public List getPoints() {
    return this.points;
  }

  public void setPoints(List points) {
    this.points = points;
  }
}