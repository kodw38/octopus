package com.octopus.utils.cachebatch;

import java.util.Date;

public class AmortizeFactory
{
  private static final AmortizeFlush flush = new AmortizeFlush();

  public static void addAmortizeContainer(String key, int timespace, int fullRecCount, Class workTaskClass)
    throws Exception
  {
    if (null == workTaskClass) {
      throw new Exception("Amortize Task Class dot not set.");
    }

    if (!(AbstractAmortizeTask.class.isAssignableFrom(workTaskClass)))
      throw new Exception(workTaskClass + " is not extends " + AbstractAmortizeTask.class);

    AmortizeContainer amortizeContainer = new AmortizeContainer(key, timespace, fullRecCount, workTaskClass);
    amortizeContainer.setStartTime(new Date());
    flush.addAmortizeContainer(key, amortizeContainer);
  }

  public static void addData(String key, Object data)
    throws Exception
  {
    AmortizeContainer container = flush.getAmortizeContainer(key.trim());
    if (null != container)
      container.addObject(data);
  }

  public static boolean isAmortizeExist(String key)
    throws Exception
  {
    AmortizeContainer container = flush.getAmortizeContainer(key.trim());

    return (null != container);
  }

  public static AmortizeContainer getAmortizeContainer(String key)
    throws Exception
  {
    return flush.getAmortizeContainer(key);
  }

  public static void flushData(String key) throws Exception {
    flush.flushData(key);
  }

  public static Date getStartDate(String key) throws Exception {
    AmortizeContainer container = flush.getAmortizeContainer(key.trim());
    if (null != container)
      return container.getStartTime();

    return null;
  }

  public static int flushAllData()
    throws Exception
  {
    return flush.flushAll();
  }

  static
  {
    flush.start();
  }
}