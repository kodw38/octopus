package com.octopus.utils.cachebatch;

public abstract interface AsynContainerMBean
{
  public abstract long getTotalCount();
}