package com.octopus.utils.cachebatch;

import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public abstract class FlushWorkTask
  implements Runnable
{
  private static transient Log log = LogFactory.getLog(FlushWorkTask.class);
  protected Map data;
  String name;
  Object other;

  public FlushWorkTask()
  {
    this.data = null;
  }

  public String getName()
  {
    return this.name;
  }

  public void setName(String name) {
    this.name = name; }

  public void setOther(Object other) {
    this.other = other;
  }

  public Object getOther() {
    return this.other;
  }

  public void setData(Map data)
  {
    this.data = data;
  }

  public void run()
  {
    try
    {
      work(this.data);
    }
    catch (Throwable ex) {
      log.error("FlushWorkTask error", ex);
    }
  }

  public abstract void work(Map paramMap)
    throws Exception;
}