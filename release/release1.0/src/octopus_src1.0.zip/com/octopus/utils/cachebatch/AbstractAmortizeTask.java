package com.octopus.utils.cachebatch;

import java.util.List;

public abstract class AbstractAmortizeTask extends Thread
{
  private List li;
  String taskName = null;

  public AbstractAmortizeTask()
  {
    setDaemon(true); }

  public void setTaskName(String name) {
    this.taskName = name; }

  public String getTaskName() {
    return this.taskName;
  }

  public void doTask(List datas)
  {
    this.li = datas;
    start();
  }

  public void run()
  {
    work(this.li);
    this.li = null;
  }

  public abstract void work(List paramList);
}