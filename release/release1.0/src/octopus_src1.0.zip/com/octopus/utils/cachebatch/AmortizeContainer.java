package com.octopus.utils.cachebatch;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AmortizeContainer
{
  int timespace;
  int fullRecCount;
  Class workTaskClass;
  List datas = new ArrayList();
  Date startTime;
  String name;

  public AmortizeContainer(String name, int timespace, int fullRecCount, Class workTaskClass)
  {
    this.timespace = timespace;
    this.fullRecCount = fullRecCount;
    this.workTaskClass = workTaskClass;
    this.name = name;
  }

  public boolean isAddData()
  {
    return (this.datas.size() < this.fullRecCount * 2);
  }

  public Date getStartTime()
  {
    return this.startTime;
  }

  public void setStartTime(Date startTime) {
    this.startTime = startTime;
  }

  public void addObject(Object data)
  {
    synchronized (this) {
      if (isAddData()) {
        this.datas.add(data);
        if (this.datas.size() >= getFullRecCount())
          AmortizeFlush.doData(this.name, this);
      }
    }
  }

  public void clearDatas()
  {
    this.datas.clear();
  }

  public List getDatas()
  {
    return this.datas;
  }

  public void setDatas(List datas) {
    this.datas = datas;
  }

  public int getFullRecCount() {
    return this.fullRecCount;
  }

  public void setFullRecCount(int fullRecCount) {
    this.fullRecCount = fullRecCount;
  }

  public int getTimespace() {
    return this.timespace;
  }

  public void setTimespace(int timespace) {
    this.timespace = timespace;
  }

  public Class getWorkTaskClass() {
    return this.workTaskClass;
  }

  public void setWorkTaskClass(Class workTaskClass) {
    this.workTaskClass = workTaskClass;
  }
}