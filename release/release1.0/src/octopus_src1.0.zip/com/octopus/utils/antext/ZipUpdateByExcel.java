package com.octopus.utils.antext;

import com.octopus.utils.file.FileUtils;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;

public class ZipUpdateByExcel extends Task
{
  String zipfile;
  String chgexcelfilename;
  String sheetname;
  String fieldnameforchangeid;
  String changeidvalues;
  String filednameforfilenameinzip;
  String fieldnameforoldvalue;
  String fieldnamefornewvalue;
  String encode;

  public void setZipfile(String zipfile)
  {
    this.zipfile = zipfile;
  }

  public void setChgexcelfilename(String chgexcelfilename) {
    this.chgexcelfilename = chgexcelfilename;
  }

  public void setSheetname(String sheetname) {
    this.sheetname = sheetname;
  }

  public void setFieldnameforchangeid(String fieldnameforchangeid) {
    this.fieldnameforchangeid = fieldnameforchangeid;
  }

  public void setChangeidvalues(String changeidvalues) {
    this.changeidvalues = changeidvalues;
  }

  public void setFilednameforfilenameinzip(String filednameforfilenameinzip) {
    this.filednameforfilenameinzip = filednameforfilenameinzip;
  }

  public void setFieldnameforoldvalue(String fieldnameforoldvalue) {
    this.fieldnameforoldvalue = fieldnameforoldvalue;
  }

  public void setFieldnamefornewvalue(String fieldnamefornewvalue) {
    this.fieldnamefornewvalue = fieldnamefornewvalue;
  }

  public void setEncode(String encode) {
    this.encode = encode;
  }

  public void execute()
    throws BuildException
  {
    try
    {
      FileUtils.replaceZipFileContentByExcel(this.zipfile, this.chgexcelfilename, this.sheetname, this.fieldnameforchangeid, this.changeidvalues.split(","), this.filednameforfilenameinzip, this.fieldnameforoldvalue, this.fieldnamefornewvalue, this.encode);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}