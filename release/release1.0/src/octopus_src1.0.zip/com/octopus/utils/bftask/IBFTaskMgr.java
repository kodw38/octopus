package com.octopus.utils.bftask;

public abstract interface IBFTaskMgr
{
  public abstract boolean isExist(String paramString);

  public abstract void doTask(String paramString, BFParameters paramBFParameters)
    throws Exception;
}