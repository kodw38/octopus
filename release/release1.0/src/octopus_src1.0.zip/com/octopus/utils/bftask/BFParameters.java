package com.octopus.utils.bftask;

import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.auto.XMLParameter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class BFParameters extends XMLParameter
  implements Serializable
{
  protected boolean isStop = false;
  protected StringBuffer taskPath = new StringBuffer();
  protected boolean isInterrupt;
  protected List<String> jumpTaskList = new ArrayList();
  protected double nextTask = 0D;
  boolean cycleused;

  public BFParameters()
  {
    this.cycleused = false;
  }

  public BFParameters(boolean cycleused) {
    this.cycleused = cycleused; }

  public void clearStatus() {
    this.isStop = false;
    put("^isstop", "false");
    this.isInterrupt = false;
    put("^isinterrupt", "false");
    this.jumpTaskList.clear();
    this.nextTask = 0D;
    put("^nexttask", "0");
  }

  public double getNextTask()
  {
    return this.nextTask;
  }

  public void setNextTask(double nextTask) {
    this.nextTask = nextTask;
    put("^nexttask", String.valueOf(nextTask));
  }

  public Throwable getException()
  {
    if ((null == this.exception) && (isError()) && (StringUtils.isNotBlank(get("^exception"))))
      this.exception = new Exception((String)get("^exception"));

    return this.exception;
  }

  public boolean isStop() {
    if (StringUtils.isNotBlank(get("^isstop")))
      this.isStop = Boolean.valueOf((String)get("^isstop")).booleanValue();

    return this.isStop;
  }

  public void setStop() {
    this.isStop = true;
    put("^isstop", "true");
  }

  public void setParameter(Object parameter) {
    put("parameter", parameter);
  }

  public Object getParameter() {
    return get("parameter");
  }

  public void setInterrupt() {
    this.isInterrupt = true;
    put("^isinterrupt", "true"); }

  public boolean isInterrupt() {
    if (StringUtils.isNotBlank(get("^isinterrupt")))
      this.isInterrupt = Boolean.valueOf((String)get("^isinterrupt")).booleanValue();

    return this.isInterrupt; }

  public void setContinue() {
    this.isInterrupt = false;
    put("^isinterrupt", "false"); }

  public synchronized String getTaskPath() {
    if (!(this.cycleused)) {
      if ((this.taskPath.length() == 0) && (StringUtils.isNotBlank(get("^trace"))))
        this.taskPath.append(get("^trace"));

      return this.taskPath.toString();
    }

    return null;
  }

  public void setCycleused(boolean cycleused) {
    this.cycleused = cycleused;
  }

  public synchronized void addTaskCode(String taskCode)
  {
  }

  public Object get(String key)
  {
    return getParameter(key);
  }

  public void put(String key, Object value)
  {
    addParameter(key, value);
  }

  public boolean containsKey(String key)
  {
    return super.containsParameter(key);
  }

  public Map getData()
  {
    return getReadOnlyParameter();
  }

  public List<String> getJumpTaskList() {
    if ((this.jumpTaskList.size() == 0) && (StringUtils.isNotBlank(get("^jumps")))) {
      String jumps = (String)get("^jumps");
      String[] ss = jumps.split(",");
      String[] arr$ = ss; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String s = arr$[i$];
        this.jumpTaskList.add(s.trim()); }
    }
    return this.jumpTaskList;
  }

  public void setJumpTaskList(List<String> jumpTaskList) {
    this.jumpTaskList = jumpTaskList;
    if (null != jumpTaskList) {
      StringBuffer sb = new StringBuffer();
      for (Iterator i$ = jumpTaskList.iterator(); i$.hasNext(); ) { String s = (String)i$.next();
        if (sb.length() != 0)
          sb.append(",");
        sb.append(s);
      }

      put("^jumps", sb.toString());
    }
  }

  void initmap(XMLMakeup data, Map map)
  {
    List ls = data.getChildren();
  }

  void putdata(XMLMakeup data, Object key, Object value, boolean isexist)
  {
    List ls;
    XMLMakeup t = null;
    if (isexist) {
      ls = data.getChildren();
    }
    else
    {
      t = new XMLMakeup();
      t.setName("d");
    }

    if (!(isexist))
      data.addChild(t);
  }
}