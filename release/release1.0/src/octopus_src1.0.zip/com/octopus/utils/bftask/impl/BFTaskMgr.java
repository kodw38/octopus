package com.octopus.utils.bftask.impl;

import com.octopus.utils.bftask.BFParameters;
import com.octopus.utils.bftask.IBFExecutor;
import com.octopus.utils.bftask.IBFTaskMgr;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import java.util.HashMap;
import java.util.Map;

public class BFTaskMgr extends XMLObject
  implements IBFTaskMgr
{
  IBFExecutor executor = null;
  Map<String, BFTask> tasks = new HashMap();

  public BFTaskMgr(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void notifyObject(String op, Object obj)
    throws Exception
  {
  }

  public void destroy()
    throws Exception
  {
  }

  public void initial() throws Exception
  {
  }

  public boolean isExist(String taskkey)
  {
    return this.tasks.containsKey(taskkey);
  }

  public void doTask(String taskkey, BFParameters parameters) throws Exception {
    ((BFTask)this.tasks.get(taskkey)).doTask(parameters);
  }
}