package com.octopus.utils.bftask;

import com.octopus.utils.xml.XMLMakeup;

public abstract interface IBFExecutor
{
  public abstract void execute(XMLMakeup paramXMLMakeup, String paramString, BFParameters paramBFParameters, Throwable paramThrowable)
    throws Exception;
}