package com.octopus.utils.bftask.impl;

import com.octopus.utils.alone.ArrayUtils;
import com.octopus.utils.alone.ObjectUtils;
import com.octopus.utils.alone.StringUtils;
import com.octopus.utils.bftask.BFParameters;
import com.octopus.utils.bftask.IBFExecutor;
import com.octopus.utils.bftask.IBFTask;
import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.XMLObject;
import com.octopus.utils.xml.auto.XMLDoObject;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class BFTask extends XMLObject
  implements IBFTask
{
  static transient Log log = LogFactory.getLog(BFTask.class);
  XMLDoObject executor;

  public BFTask(XMLMakeup xml, XMLObject parent, Object[] containers)
    throws Exception
  {
    super(xml, parent, containers);
  }

  public void notifyObject(String op, Object obj)
    throws Exception
  {
  }

  public void destroy()
    throws Exception
  {
  }

  public void initial() throws Exception
  {
  }

  public void doTask(BFParameters parameters) throws Exception
  {
    XMLDoObject exe = null;
    try {
      exe = (XMLDoObject)getPropertyObject("executor");
      execute(exe, "before", parameters, null);
      parameters.setError(false);
    }
    catch (Exception e)
    {
      parameters.setError(true);

      throw e;
    } finally {
      execute(exe, "after", parameters, null);
    }
  }

  void execute(XMLDoObject exe, String steptype, BFParameters parameters, Throwable error) throws Exception
  {
    XMLMakeup x = (XMLMakeup)ArrayUtils.getFirst(getXML().getChild(steptype));
    if (null != x) {
      List steps = x.getChildren();
      Iterator i$ = steps.iterator();
      while (true) { XMLMakeup step;
        String id;
        while (true) { while (true) { while (true) { if (!(i$.hasNext())) return; step = (XMLMakeup)i$.next();
              if (parameters.isStop()) { return;
              }

              id = step.getProperties().getProperty("action");
              if (null == id)
                id = step.getId();
              if (id.startsWith("${"))
              {
                step = step.clone();
                id = (String)ObjectUtils.getValueByPath(parameters, id);
                step.getProperties().setProperty("action", id);
                step.getProperties().setProperty("key", id);
              }

              if (!(StringUtils.isBlank(id))) break;
            }
            if ((null == step.getProperties().getProperty("isenable")) || (StringUtils.isTrue(step.getProperties().getProperty("isenable")))) break;
          }
          if (!(parameters.getJumpTaskList().contains(id))) break;
        }
        if (log.isDebugEnabled())
          System.out.println("begin to do BFtask:" + id);

        parameters.addTaskCode(id);
        if (exe instanceof IBFExecutor) {
          ((IBFExecutor)exe).execute(step, id, parameters, error);
        } else {
          Map in = (Map)parameters.get("^${input}");
          if (null == in)
            in = new HashMap();

          in.put("exe_id", id);
          in.put("exe_xml", step);
          in.put("exe_error", error);
          parameters.put("^${input}", in);

          in.put("exe_xml", step);
          exe.doThing(parameters, step);
        }
      }
    }
  }
}