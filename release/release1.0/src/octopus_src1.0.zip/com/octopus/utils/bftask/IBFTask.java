package com.octopus.utils.bftask;

public abstract interface IBFTask
{
  public abstract void doTask(BFParameters paramBFParameters)
    throws Exception;
}