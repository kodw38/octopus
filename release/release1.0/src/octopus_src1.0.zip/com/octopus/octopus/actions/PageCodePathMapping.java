package com.octopus.octopus.actions;

import com.octopus.isp.bridge.launchers.impl.pageframe.channel.IPageCodePathMapping;

public class PageCodePathMapping
  implements IPageCodePathMapping
{
  public String getRealPathByCode(String code)
  {
    return null;
  }
}