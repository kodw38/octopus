package com.octopus.isp.tools;

/**
 * User: Administrator
 * Date: 14-10-25
 * Time: 下午2:43
 */
public interface IDataGet {
    public Object getData(String condkey,Object parameters) throws Exception;
}
