package com.octopus.isp.listeners;

/**
 * User: wfgao_000
 * Date: 15-9-15
 * Time: 下午1:07
 */
public interface IBodyCreator {
    public String createBody(String s);
}
