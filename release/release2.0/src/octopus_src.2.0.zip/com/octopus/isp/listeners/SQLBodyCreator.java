package com.octopus.isp.listeners;

/**
 * User: wfgao_000
 * Date: 15-9-15
 * Time: 下午1:13
 */
public class SQLBodyCreator implements IBodyCreator {
    @Override
    public String createBody(String s) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
