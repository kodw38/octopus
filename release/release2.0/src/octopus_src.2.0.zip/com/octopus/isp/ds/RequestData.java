package com.octopus.isp.ds;

import com.octopus.utils.xml.XMLMakeup;
import com.octopus.utils.xml.auto.XMLParameter;

/**
 * User: Administrator
 * Date: 14-9-3
 * Time: 下午5:25
 */
public class RequestData extends XMLParameter {
    XMLMakeup client;

}
