package com.octopus.isp.ds;

import com.octopus.utils.xml.auto.XMLParameter;

/**
 * User: wfgao_000
 * Date: 15-8-12
 * Time: 上午10:24
 */
public class Header extends XMLParameter{

}
