package com.octopus.isp.ds;

import com.octopus.utils.flow.FlowParameters;

/**
 * User: Administrator
 * Date: 14-9-3
 * Time: 下午5:42
 */
public class Env extends FlowParameters {
    public  static String KEY_HOME= "Home";

}
