package com.octopus.isp.cell;

/**
 * User: Administrator
 * Date: 14-9-2
 * Time: 下午5:39
 */
public interface ICell {

}
