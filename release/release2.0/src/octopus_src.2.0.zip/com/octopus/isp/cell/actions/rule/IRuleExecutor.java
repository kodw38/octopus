package com.octopus.isp.cell.actions.rule;

import java.util.Map;

/**
 * User: wfgao_000
 * Date: 15-4-23
 * Time: 上午10:07
 */
public interface IRuleExecutor {
    public void setEnv(Map map);
}
