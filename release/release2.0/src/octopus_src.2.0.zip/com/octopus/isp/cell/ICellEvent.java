package com.octopus.isp.cell;

/**
 * User: Administrator
 * Date: 14-11-16
 * Time: 上午9:37
 */
public interface ICellEvent {

}
