package com.octopus.isp.bridge.launchers.impl.pageframe.channel;

/**
 * User: wfgao_000
 * Date: 15-9-1
 * Time: 下午12:46
 */
public interface IPageCodePathMapping {
    public String getRealPathByCode(String code);
}
