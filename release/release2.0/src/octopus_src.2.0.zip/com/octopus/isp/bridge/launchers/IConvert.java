package com.octopus.isp.bridge.launchers;

/**
 * User: Administrator
 * Date: 14-9-29
 * Time: 上午11:11
 */
public interface IConvert {
    public Object convert(Object par) throws Exception;
}
