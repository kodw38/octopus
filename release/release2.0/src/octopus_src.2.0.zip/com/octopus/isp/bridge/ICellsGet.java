package com.octopus.isp.bridge;

import com.octopus.utils.xml.XMLMakeup;

/**
 * User: Administrator
 * Date: 14-9-29
 * Time: 下午8:09
 */
public interface ICellsGet {
    public XMLMakeup getCell(XMLMakeup xmlMakeup);
}
