package com.octopus.isp.bridge.launchers.impl.pageframe;

/**
 * User: wfgao_000
 * Date: 15-9-1
 * Time: 上午9:48
 */
public interface ISessionDataGet {
    public String getData(Object o);
}
