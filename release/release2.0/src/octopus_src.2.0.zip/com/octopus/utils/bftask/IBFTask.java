package com.octopus.utils.bftask;


/**
 * User: Administrator
 * Date: 14-8-25
 * Time: 下午8:45
 */
public interface IBFTask {
    public void doTask(BFParameters parameters) throws Exception;

}