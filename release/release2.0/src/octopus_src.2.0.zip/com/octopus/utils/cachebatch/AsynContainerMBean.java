package com.octopus.utils.cachebatch;

/**
 * User: Administrator
 * Date: 15-3-5
 * Time: 上午9:49
 */
public interface AsynContainerMBean {
    public long getTotalCount();
}
