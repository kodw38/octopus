package com.octopus.utils.balance.qps;

/**
 * Created by Administrator on 2018/11/8.
 */
public interface IProcess {
    public Object process(Object o)throws Exception;
}
