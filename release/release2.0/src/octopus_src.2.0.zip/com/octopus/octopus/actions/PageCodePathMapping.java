package com.octopus.octopus.actions;

import com.octopus.isp.bridge.launchers.impl.pageframe.channel.IPageCodePathMapping;

/**
 * User: wfgao_000
 * Date: 15-9-1
 * Time: 下午5:14
 */
public class PageCodePathMapping implements IPageCodePathMapping {
    @Override
    public String getRealPathByCode(String code) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
