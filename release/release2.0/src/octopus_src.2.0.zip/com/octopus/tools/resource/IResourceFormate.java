package com.octopus.tools.resource;

/**
 * User: Administrator
 * Date: 14-8-25
 * Time: 下午2:38
 */
public interface IResourceFormate {
}
