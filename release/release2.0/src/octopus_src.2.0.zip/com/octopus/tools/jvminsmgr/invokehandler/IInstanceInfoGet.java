package com.octopus.tools.jvminsmgr.invokehandler;

/**
 * User: Administrator
 * Date: 14-9-28
 * Time: 下午12:46
 */
public interface IInstanceInfoGet {
}
