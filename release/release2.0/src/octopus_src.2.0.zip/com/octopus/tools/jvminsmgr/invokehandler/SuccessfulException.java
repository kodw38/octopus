package com.octopus.tools.jvminsmgr.invokehandler;

/**
 * User: Administrator
 * Date: 14-9-18
 * Time: 下午6:57
 */
public class SuccessfulException extends Exception {
}
