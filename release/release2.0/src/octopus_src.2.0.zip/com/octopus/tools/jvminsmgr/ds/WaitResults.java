package com.octopus.tools.jvminsmgr.ds;

/**
 * User: Administrator
 * Date: 14-9-18
 * Time: 下午7:19
 */
public class WaitResults {
    Object[] results;

    public Object[] getResults() {
        return results;
    }

    public void setResults(Object[] results) {
        this.results = results;
    }
}
