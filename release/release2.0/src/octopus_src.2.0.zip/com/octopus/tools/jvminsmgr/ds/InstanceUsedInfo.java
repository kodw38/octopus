package com.octopus.tools.jvminsmgr.ds;

/**
 * User: Administrator
 * Date: 14-9-28
 * Time: 下午2:31
 */
public class InstanceUsedInfo {
}
