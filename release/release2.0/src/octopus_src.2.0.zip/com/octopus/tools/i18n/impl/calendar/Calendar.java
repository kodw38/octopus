package com.octopus.tools.i18n.impl.calendar;

/**
 * 某种具体的日历计算工具类
 * User: wangfeng2
 * Date: 14-8-21
 * Time: 下午5:34
 */
public class Calendar {
}
