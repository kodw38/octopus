package com.octopus.tools.i18n.impl.calendar;

/**
 * 某个具体时间的日历
 * User: wangfeng2
 * Date: 14-8-21
 * Time: 下午5:35
 */
public class CalendarDateTime {
}
