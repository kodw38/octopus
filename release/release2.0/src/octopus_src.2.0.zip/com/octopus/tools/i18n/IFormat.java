package com.octopus.tools.i18n;

/**
 * User: wangfeng2
 * Date: 14-8-18
 * Time: 下午5:16
 */
public interface IFormat {
    public Object formate(Object o);

    public Object formate2System(Object o);
}
