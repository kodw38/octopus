package com.octopus.tools.i18n;

import java.util.Properties;

/**
 * User: wangfeng2
 * Date: 14-8-18
 * Time: 下午5:49
 */
public interface IGetter {

    public Object get(Properties locale);
}
