package com.octopus.tools.cache;

/**
 * User: Administrator
 * Date: 14-8-25
 * Time: 上午10:12
 */
public interface ICacheListener{

    public void doListener(Object store);

}
