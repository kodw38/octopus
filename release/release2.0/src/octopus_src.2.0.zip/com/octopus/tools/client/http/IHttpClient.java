package com.octopus.tools.client.http;

/**
 * User: Administrator
 * Date: 14-10-25
 * Time: 上午10:32
 */
public interface IHttpClient {
    public void httpInvoke(HttpDS parameters)throws Exception;
}
