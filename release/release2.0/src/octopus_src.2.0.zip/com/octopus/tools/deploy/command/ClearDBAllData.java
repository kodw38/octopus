package com.octopus.tools.deploy.command;

import com.octopus.tools.deploy.CommandMgr;
import com.octopus.tools.deploy.ICommand;

import java.util.Properties;

/**
 * User: Administrator
 * Date: 15-1-21
 * Time: 上午10:14
 */
public class ClearDBAllData implements ICommand {
    @Override
    public String exeCommand(CommandMgr commandMgr,Properties properties) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
