package com.octopus.tools.dataclient.impl.engines;

/**
 * User: Administrator
 * Date: 14-9-24
 * Time: 下午5:01
 */
public interface ITyper {

    public Object typer(Object o);
}
