package com.octopus.tools.dataclient;

/**
 * User: Administrator
 * Date: 14-8-25
 * Time: 下午2:10
 */
public interface IDataListener {
}
