package com.octopus.tools.dataclient.impl.engines;

/**
 * User: Administrator
 * Date: 14-9-24
 * Time: 上午11:32
 */
public interface IDCS {

    public DC getDC(String opid);
}
