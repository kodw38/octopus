package com.octopus.tools.dataclient.v2.ds;

import java.util.Map;

/**
 * User: wfgao_000
 * Date: 15-11-14
 * Time: 下午7:23
 */
public class DataDefines {
    public String getTableName(Map data){
        return null;
    }

    public String getDataSource(Map data,Map env){
        return null;
    }

    public String getStoreTableName(Map data,Map env){
        return null;
    }

}
