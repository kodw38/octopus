package com.octopus.tools.statistic;

/**
 * User: Administrator
 * Date: 14-8-27
 * Time: 下午4:15
 */
public class StatisticMgr {
}
