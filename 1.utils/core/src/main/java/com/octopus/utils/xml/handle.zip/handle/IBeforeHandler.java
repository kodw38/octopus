package com.asiainfo.utils.xml.handle;

import java.lang.reflect.Method;

/**
 * User: Administrator
 * Date: 14-8-26
 * Time: 下午8:27
 */
public interface IBeforeHandler {
    public void doBefore(Object impl, String m, Object[] args);
}
