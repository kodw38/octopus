package com.asiainfo.utils.xml.handle;

import java.lang.reflect.Method;

/**
 * User: Administrator
 * Date: 14-8-26
 * Time: 下午8:28
 */
public interface IAfterHandler {
    public void doAfter(Object impl, String m, Object[] args, boolean isSuccess, Throwable e, Object result);
}
