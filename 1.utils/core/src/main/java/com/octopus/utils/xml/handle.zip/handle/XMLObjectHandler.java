package com.asiainfo.utils.xml.handle;

import com.asiainfo.utils.xml.XMLMakeup;
import com.asiainfo.utils.xml.XMLObject;
import com.asiainfo.utils.cls.proxy.IMethodAddition;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.List;

/**
 * User: Administrator
 * Date: 14-8-26
 * Time: 下午4:40
 */
public class XMLObjectHandler extends XMLObject implements IMethodAddition {
    static transient Log log = LogFactory.getLog(XMLObjectHandler.class);

    public XMLObjectHandler(XMLMakeup xml, XMLObject parent) throws Exception {
        super(xml, parent);
    }

    @Override
    public Object beforeAction(Object impl, String m, Object[] args) throws Exception {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Object afterAction(Object impl, String m, Object[] args, boolean isInvoke, boolean isSuccess, Throwable e, Object result) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Object resultAction(Object impl, String m, Object[] args, Object result) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public int getLevel() {
        return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean isWaiteBefore() {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean isNextInvoke() {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void setMethods(List<String> methods) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public List<String> getMethods() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
